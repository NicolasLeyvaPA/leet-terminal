# Polymarket Edge Detection System

A production-ready ML pipeline for identifying statistical edges in Polymarket prediction markets.

> **Disclaimer**: This is for research and educational purposes only. Prediction market trading involves substantial risk. This is not financial, legal, or tax advice. Past performance does not guarantee future results.

## Overview

This system provides:
- **Data Acquisition**: Real-time and historical data from Polymarket's CLOB API
- **Feature Engineering**: 16+ market microstructure and sentiment features
- **ML Models**: Ensemble of calibrated probability models (Isotonic, Platt, LightGBM, XGBoost)
- **Edge Detection**: Statistical edge calculation with Kelly criterion sizing
- **Risk Management**: Position limits, correlation tracking, drawdown controls
- **Production Infrastructure**: PostgreSQL persistence, WebSocket streaming, monitoring, alerting

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Polymarket Edge System                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                   │
│  │  Polymarket  │    │  News APIs   │    │   Social     │                   │
│  │    CLOB      │    │  (NewsAPI,   │    │  (Reddit)    │                   │
│  │              │    │   GDELT)     │    │              │                   │
│  └──────┬───────┘    └──────┬───────┘    └──────┬───────┘                   │
│         │                   │                   │                            │
│         └───────────────────┼───────────────────┘                            │
│                             ▼                                                │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      Data Ingestion Layer                            │    │
│  │  • WebSocket streaming (prices, trades, order books)                 │    │
│  │  • REST API polling (market metadata, historical)                    │    │
│  │  • External data aggregation (news, social, sentiment)               │    │
│  └─────────────────────────────┬───────────────────────────────────────┘    │
│                                │                                             │
│                                ▼                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      Feature Engineering                             │    │
│  │  • Price momentum (returns, volatility, trend)                       │    │
│  │  • Liquidity metrics (spread, depth, imbalance)                      │    │
│  │  • Market dynamics (time decay, volume profile)                      │    │
│  │  • Sentiment features (news, social, aggregate)                      │    │
│  └─────────────────────────────┬───────────────────────────────────────┘    │
│                                │                                             │
│                                ▼                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      Model Ensemble                                  │    │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐                 │    │
│  │  │Isotonic │  │ Platt   │  │LightGBM │  │ XGBoost │                 │    │
│  │  │  Reg    │  │ Scaling │  │         │  │         │                 │    │
│  │  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘                 │    │
│  │       └────────────┼───────────┼───────────┘                        │    │
│  │                    ▼                                                 │    │
│  │            Weighted Average Ensemble                                 │    │
│  └─────────────────────────────┬───────────────────────────────────────┘    │
│                                │                                             │
│                                ▼                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      Edge Detection                                  │    │
│  │  • Edge = Model P - Market P (adjusted for fees)                     │    │
│  │  • Kelly fraction sizing with fractional Kelly (0.25x)               │    │
│  │  • Confluence scoring (model agreement + signal strength)            │    │
│  │  • Signal classification (STRONG/MODERATE/WEAK)                      │    │
│  └─────────────────────────────┬───────────────────────────────────────┘    │
│                                │                                             │
│                                ▼                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      Risk & Portfolio                                │    │
│  │  • Position tracking with entry/exit management                      │    │
│  │  • Real-time P&L calculation                                         │    │
│  │  • Exposure limits (per market, category, total)                     │    │
│  │  • Correlation monitoring                                            │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

## Quick Start

### Prerequisites

- Python 3.11+
- PostgreSQL 15+
- Docker & Docker Compose (for deployment)
- Redis (for caching/queues)

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/polymarket-edge.git
cd polymarket-edge

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -e .
# Or with poetry:
poetry install
```

### Configuration

Create a `.env` file:

```bash
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=polymarket_edge
DB_USER=polymarket
DB_PASSWORD=your_secure_password

# API Rate Limiting
POLYMARKET_REQUESTS_PER_SECOND=5
POLYMARKET_BURST_LIMIT=10

# Risk Parameters
RISK_MAX_POSITION_PCT=0.05
RISK_KELLY_FRACTION=0.25
RISK_MAX_TOTAL_EXPOSURE=0.5

# Monitoring (optional)
SLACK_WEBHOOK_URL=https://hooks.slack.com/...
NEWSAPI_KEY=your_newsapi_key

# Logging
LOG_LEVEL=INFO
```

### Running Locally

```bash
# Quick market scan (no database required)
python -m src.app scan --limit 20

# Analyze a specific market
python -m src.app analyze --market-id "your-market-id"

# Start the full application (requires PostgreSQL)
python -m src.app run

# Start the API server
uvicorn src.api.routes:create_app --factory --reload
```

### Docker Deployment

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f api worker

# Stop services
docker-compose down
```

## Project Structure

```
polymarket_edge/
├── config/
│   └── settings.py          # Configuration management
├── src/
│   ├── api/
│   │   └── routes.py        # FastAPI REST endpoints
│   ├── backtest/
│   │   └── engine.py        # Walk-forward backtesting
│   ├── data/
│   │   ├── client.py        # Polymarket API client
│   │   ├── database.py      # SQLAlchemy ORM models
│   │   ├── external.py      # News/social data sources
│   │   ├── models.py        # Pydantic data models
│   │   └── streaming.py     # WebSocket client
│   ├── features/
│   │   └── engineering.py   # Feature computation
│   ├── models/
│   │   ├── probability.py   # ML models
│   │   └── registry.py      # Model versioning
│   ├── monitoring/
│   │   └── alerts.py        # Alerts, health, metrics
│   ├── portfolio/
│   │   └── manager.py       # Position & P&L tracking
│   ├── scheduler/
│   │   └── jobs.py          # Periodic task scheduling
│   ├── signals/
│   │   └── edge.py          # Edge detection logic
│   ├── app.py               # Main application
│   ├── cli.py               # Command-line interface
│   └── demo.py              # Demo scripts
├── monitoring/
│   ├── prometheus.yml       # Prometheus config
│   ├── loki-config.yml      # Loki log aggregation
│   └── grafana/             # Grafana dashboards
├── scripts/
│   └── init-db.sql          # Database initialization
├── Dockerfile
├── docker-compose.yml
├── pyproject.toml
└── README.md
```

## API Reference

### REST Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/metrics` | GET | Prometheus metrics |
| `/api/v1/markets` | GET | List active markets |
| `/api/v1/markets/{id}` | GET | Get market details |
| `/api/v1/markets/{id}/analyze` | POST | Analyze market |
| `/api/v1/signals` | GET | List recent signals |
| `/api/v1/signals/actionable` | GET | Actionable signals only |
| `/api/v1/portfolio` | GET | Portfolio summary |
| `/api/v1/portfolio/positions` | GET | Open positions |

### Example: Scan for Opportunities

```python
import httpx

async def scan_markets():
    async with httpx.AsyncClient() as client:
        # Get actionable signals
        resp = await client.get(
            "http://localhost:8000/api/v1/signals/actionable",
            params={"min_edge": 0.05, "min_confluence": 0.6}
        )
        signals = resp.json()
        
        for signal in signals:
            print(f"Market: {signal['market_question']}")
            print(f"Edge: {signal['edge']:.1%}")
            print(f"Kelly: {signal['kelly_fraction']:.1%}")
            print(f"Confidence: {signal['confluence_score']:.2f}")
            print("---")
```

## Models

### Probability Calibration

The system uses an ensemble of four models:

1. **Isotonic Regression**: Non-parametric, monotonic calibration
2. **Platt Scaling**: Logistic calibration with temperature
3. **LightGBM**: Gradient boosting with market features
4. **XGBoost**: Alternative gradient boosting implementation

Ensemble weights are determined by validation Brier scores.

### Features

| Category | Features |
|----------|----------|
| Price | `return_1h`, `return_24h`, `volatility_24h`, `price_momentum` |
| Liquidity | `bid_ask_spread`, `depth_imbalance`, `volume_24h`, `volume_ratio` |
| Time | `time_to_expiry`, `market_age_days`, `days_since_volume_peak` |
| Market | `open_interest`, `trade_count_24h`, `avg_trade_size` |
| Sentiment | `news_sentiment`, `social_sentiment`, `sentiment_momentum` |

### Edge Calculation

```
Raw Edge = Model_Probability - Market_Probability
Adjusted Edge = Raw_Edge - Fees (typically 1-2%)
Kelly Fraction = Edge / Odds (capped at 25% of full Kelly)
```

A signal is considered actionable when:
- `adjusted_edge > 5%`
- `confluence_score > 0.6`
- `kelly_fraction > 1%`

## Backtesting

```python
from src.backtest.engine import BacktestEngine

# Configure backtest
engine = BacktestEngine(
    initial_capital=10000,
    max_position_size=0.05,
    kelly_fraction=0.25,
)

# Run walk-forward validation
results = await engine.run_walk_forward(
    markets=markets,
    train_days=30,
    test_days=7,
    step_days=7,
)

# Print results
print(f"Total Return: {results.total_return:.1%}")
print(f"Sharpe Ratio: {results.sharpe_ratio:.2f}")
print(f"Max Drawdown: {results.max_drawdown:.1%}")
print(f"Win Rate: {results.win_rate:.1%}")
```

## Monitoring

### Grafana Dashboards

Access Grafana at `http://localhost:3000` (admin/admin) with pre-configured dashboards:

- **System Overview**: API latency, error rates, resource usage
- **Trading Performance**: Signals, P&L, win rate
- **Model Metrics**: Brier scores, calibration curves

### Alerting

Configure alerts via environment variables:

```bash
# Slack alerts
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/...

# Email alerts
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@email.com
SMTP_PASSWORD=app_password
ALERT_EMAIL=alerts@yourcompany.com
```

Alert types:
- **CRITICAL**: System down, database connection lost
- **HIGH**: Model performance degradation, large drawdown
- **MEDIUM**: New high-edge signals, position updates
- **LOW**: Daily summary, backtest completion

## Risk Management

### Position Limits

| Parameter | Default | Description |
|-----------|---------|-------------|
| `max_position_pct` | 5% | Max allocation per market |
| `max_category_exposure` | 20% | Max exposure per category |
| `max_total_exposure` | 50% | Max total portfolio exposure |
| `kelly_fraction` | 25% | Fraction of full Kelly |

### Correlation Monitoring

The system tracks correlation between positions to avoid concentrated risk:

```python
# Positions with >0.5 correlation are flagged
correlation_matrix = portfolio.get_correlation_matrix()
high_correlation_pairs = portfolio.get_high_correlation_pairs(threshold=0.5)
```

## Development

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=src --cov-report=html

# Run specific test file
pytest tests/test_edge.py -v
```

### Code Style

```bash
# Format code
black src/ tests/
isort src/ tests/

# Lint
ruff check src/
mypy src/
```

### Adding a New Model

1. Create model class in `src/models/`:
```python
class CustomModel(ProbabilityModel):
    def fit(self, X, y): ...
    def predict_proba(self, X): ...
```

2. Register in ensemble:
```python
ensemble.add_model("custom", CustomModel(), weight=0.2)
```

3. Add to model registry for versioning:
```python
registry.create_version(
    model_name="custom",
    model_obj=model,
    model_type=ModelType.CUSTOM,
    training_metrics=metrics,
)
```

## Troubleshooting

### Common Issues

**Database connection errors**:
```bash
# Check PostgreSQL is running
docker-compose ps postgres

# Check connection
psql -h localhost -U polymarket -d polymarket_edge
```

**Rate limiting**:
```bash
# Reduce request rate in .env
POLYMARKET_REQUESTS_PER_SECOND=2
```

**WebSocket disconnections**:
The streaming client auto-reconnects with exponential backoff. Check logs for connection issues.

### Logs

```bash
# Application logs
docker-compose logs -f api worker

# Query logs in Grafana/Loki
{job="polymarket-edge"} |= "error"
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

MIT License - see LICENSE file for details.

## Disclaimer

This software is provided for educational and research purposes only. Trading prediction markets involves substantial risk of loss. The authors and contributors are not responsible for any financial losses incurred from using this software. This is not financial, legal, or tax advice. Always do your own research and consult with qualified professionals before making any trading decisions.
