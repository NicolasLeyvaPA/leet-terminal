"""
Configuration settings for the Polymarket Edge system.
Uses Pydantic Settings for environment variable management.
"""

from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class PolymarketConfig(BaseSettings):
    """Polymarket API configuration."""
    
    model_config = SettingsConfigDict(env_prefix="POLYMARKET_")
    
    # API endpoints
    clob_api_url: str = "https://clob.polymarket.com"
    gamma_api_url: str = "https://gamma-api.polymarket.com"
    
    # Rate limiting
    requests_per_second: float = 5.0
    burst_limit: int = 10
    
    # Retry settings
    max_retries: int = 3
    retry_backoff_base: float = 2.0
    retry_backoff_max: float = 60.0


class DatabaseConfig(BaseSettings):
    """Database configuration."""
    
    model_config = SettingsConfigDict(env_prefix="DB_")
    
    host: str = "localhost"
    port: int = 5432
    name: str = "polymarket_edge"
    user: str = "postgres"
    password: str = ""
    
    # Connection pool
    pool_size: int = 5
    max_overflow: int = 10
    
    @property
    def url(self) -> str:
        """Generate database URL."""
        return f"postgresql+asyncpg://{self.user}:{self.password}@{self.host}:{self.port}/{self.name}"
    
    @property
    def sync_url(self) -> str:
        """Generate synchronous database URL."""
        return f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.name}"


class ModelConfig(BaseSettings):
    """ML model configuration."""
    
    model_config = SettingsConfigDict(env_prefix="MODEL_")
    
    # Training
    train_window_days: int = 90
    test_window_days: int = 7
    min_train_samples: int = 100
    
    # Prediction
    default_ensemble_weights: dict = Field(
        default={
            "lightgbm": 0.4,
            "xgboost": 0.3,
            "logistic": 0.2,
            "isotonic_calibrator": 0.1,
        }
    )
    
    # Calibration
    calibration_bins: int = 10
    min_samples_per_bin: int = 20


class RiskConfig(BaseSettings):
    """Risk management configuration."""
    
    model_config = SettingsConfigDict(env_prefix="RISK_")
    
    # Position limits
    max_position_pct: float = 0.05  # 5% of bankroll per position
    max_category_pct: float = 0.20  # 20% in one category
    max_correlated_pct: float = 0.15  # 15% in correlated markets
    max_daily_loss_pct: float = 0.10  # Stop if down 10%
    
    # Liquidity
    min_liquidity_usd: float = 10000.0
    max_market_impact_pct: float = 0.02  # Don't move price >2%
    
    # Kelly
    kelly_fraction: float = 0.25  # Use 25% Kelly (fractional)
    
    # Edge thresholds
    min_edge_strong: float = 0.05
    min_edge_moderate: float = 0.03
    min_edge_weak: float = 0.02
    
    # Fees
    trading_fee_pct: float = 0.02  # 2% fee assumption


class SignalConfig(BaseSettings):
    """Signal generation configuration."""
    
    model_config = SettingsConfigDict(env_prefix="SIGNAL_")
    
    # Confluence weights
    model_edge_weight: float = 0.35
    model_agreement_weight: float = 0.25
    news_sentiment_weight: float = 0.15
    volume_confirmation_weight: float = 0.15
    smart_money_weight: float = 0.10
    
    # Thresholds
    min_confluence_strong: float = 0.70
    min_confluence_moderate: float = 0.50
    min_confluence_weak: float = 0.30


class Settings(BaseSettings):
    """Main settings aggregating all configs."""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )
    
    # Environment
    env: Literal["development", "staging", "production"] = "development"
    debug: bool = True
    log_level: str = "INFO"
    
    # Paths
    data_dir: Path = Path("data")
    models_dir: Path = Path("models")
    logs_dir: Path = Path("logs")
    
    # Sub-configs
    polymarket: PolymarketConfig = Field(default_factory=PolymarketConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    model: ModelConfig = Field(default_factory=ModelConfig)
    risk: RiskConfig = Field(default_factory=RiskConfig)
    signal: SignalConfig = Field(default_factory=SignalConfig)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Ensure directories exist
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)


# Global settings instance
settings = Settings()
