-- Polymarket Edge System - Database Initialization
-- This script runs automatically when PostgreSQL container starts

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For text search

-- Create indexes for common queries (tables created by SQLAlchemy)
-- These are additional performance indexes beyond what the ORM creates

-- Note: Run these after the application creates the tables
-- You can run these manually or via a migration script

-- Example additional indexes:
-- CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_price_snapshots_outcome_time 
--     ON price_snapshots(outcome_id, timestamp DESC);
-- CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_signals_actionable_strength 
--     ON signals(is_actionable, signal_strength) WHERE is_actionable = true;
-- CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_news_sentiment_date 
--     ON news_articles(published_at DESC, sentiment_score);

-- Create read-only user for analytics (optional)
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'analytics_readonly') THEN
        CREATE ROLE analytics_readonly WITH LOGIN PASSWORD 'readonly_password';
    END IF;
END
$$;

-- Grant read access to analytics user
-- These grants should be run after tables are created
-- GRANT SELECT ON ALL TABLES IN SCHEMA public TO analytics_readonly;
-- ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO analytics_readonly;

-- Create schema for partitioned data (optional, for high-volume deployments)
-- CREATE SCHEMA IF NOT EXISTS partitions;

-- Function to create monthly partitions for price_snapshots (optional)
CREATE OR REPLACE FUNCTION create_monthly_partition(
    table_name TEXT,
    partition_date DATE
) RETURNS VOID AS $$
DECLARE
    partition_name TEXT;
    start_date DATE;
    end_date DATE;
BEGIN
    start_date := date_trunc('month', partition_date);
    end_date := start_date + interval '1 month';
    partition_name := table_name || '_' || to_char(start_date, 'YYYY_MM');
    
    EXECUTE format(
        'CREATE TABLE IF NOT EXISTS partitions.%I PARTITION OF %I 
         FOR VALUES FROM (%L) TO (%L)',
        partition_name, table_name, start_date, end_date
    );
END;
$$ LANGUAGE plpgsql;

-- Function to clean up old data (retention policy)
CREATE OR REPLACE FUNCTION cleanup_old_data(
    retention_days INTEGER DEFAULT 90
) RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER := 0;
    cutoff_date TIMESTAMP;
BEGIN
    cutoff_date := NOW() - (retention_days || ' days')::INTERVAL;
    
    -- Delete old price snapshots
    DELETE FROM price_snapshots WHERE timestamp < cutoff_date;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RAISE NOTICE 'Deleted % price snapshots older than %', deleted_count, cutoff_date;
    
    -- Delete old trades
    DELETE FROM trades WHERE timestamp < cutoff_date;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RAISE NOTICE 'Deleted % trades older than %', deleted_count, cutoff_date;
    
    -- Delete old news articles
    DELETE FROM news_articles WHERE published_at < cutoff_date;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RAISE NOTICE 'Deleted % news articles older than %', deleted_count, cutoff_date;
    
    -- Delete old social mentions
    DELETE FROM social_mentions WHERE timestamp < cutoff_date;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RAISE NOTICE 'Deleted % social mentions older than %', deleted_count, cutoff_date;
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Create a scheduled cleanup job (requires pg_cron extension)
-- Uncomment if pg_cron is available:
-- SELECT cron.schedule('cleanup-old-data', '0 3 * * *', 'SELECT cleanup_old_data(90)');

COMMENT ON FUNCTION cleanup_old_data IS 'Removes data older than specified retention period';
COMMENT ON FUNCTION create_monthly_partition IS 'Creates monthly partitions for time-series tables';
