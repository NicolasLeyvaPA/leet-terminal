#!/usr/bin/env python3
"""
Start the Polymarket Edge system with both API and frontend.

Usage:
    python start.py              # Start API server only
    python start.py --frontend   # Start with frontend server
    python start.py --dev        # Start with hot-reload
"""

import argparse
import asyncio
import subprocess
import sys
import os
from pathlib import Path
import webbrowser
import time
import threading
import http.server
import socketserver

# Get the project root
PROJECT_ROOT = Path(__file__).parent.absolute()
FRONTEND_DIR = PROJECT_ROOT / "frontend"


def start_frontend_server(port: int = 3000):
    """Start a simple HTTP server for the frontend."""
    os.chdir(FRONTEND_DIR)
    
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format, *args):
            pass  # Suppress logs
        
        def end_headers(self):
            # Add CORS headers
            self.send_header('Access-Control-Allow-Origin', '*')
            super().end_headers()
    
    with socketserver.TCPServer(("", port), Handler) as httpd:
        print(f"✨ Frontend running at http://localhost:{port}")
        httpd.serve_forever()


def start_backend_server(port: int = 8000, reload: bool = False):
    """Start the FastAPI backend server."""
    cmd = [
        sys.executable, "-m", "uvicorn",
        "src.api.routes:create_app",
        "--factory",
        "--host", "0.0.0.0",
        "--port", str(port),
    ]
    if reload:
        cmd.append("--reload")
    
    subprocess.run(cmd, cwd=PROJECT_ROOT)


def main():
    parser = argparse.ArgumentParser(description="Start Polymarket Edge System")
    parser.add_argument("--frontend", action="store_true", help="Also serve frontend")
    parser.add_argument("--dev", action="store_true", help="Enable hot-reload")
    parser.add_argument("--api-port", type=int, default=8000, help="API server port")
    parser.add_argument("--frontend-port", type=int, default=3000, help="Frontend server port")
    parser.add_argument("--open", action="store_true", help="Open browser automatically")
    
    args = parser.parse_args()
    
    print("""
╔══════════════════════════════════════════════════════════════════╗
║                    POLYMARKET EDGE SYSTEM                        ║
║               AI-Powered Trading Intelligence                    ║
╚══════════════════════════════════════════════════════════════════╝
    """)
    
    if args.frontend:
        # Start frontend in a separate thread
        frontend_thread = threading.Thread(
            target=start_frontend_server,
            args=(args.frontend_port,),
            daemon=True
        )
        frontend_thread.start()
        time.sleep(1)  # Give frontend time to start
        
        if args.open:
            webbrowser.open(f"http://localhost:{args.frontend_port}")
    
    print(f"🚀 Starting API server on port {args.api_port}...")
    print(f"📊 API Docs: http://localhost:{args.api_port}/docs")
    
    if args.frontend:
        print(f"🎨 Frontend: http://localhost:{args.frontend_port}")
    
    print("\nPress Ctrl+C to stop.\n")
    
    start_backend_server(args.api_port, args.dev)


if __name__ == "__main__":
    main()
