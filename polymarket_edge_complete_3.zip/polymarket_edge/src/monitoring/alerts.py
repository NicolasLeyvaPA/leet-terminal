"""
Monitoring, alerting, and health check system for Polymarket Edge.

Provides:
- System health monitoring
- Signal alerts (Slack, email, webhooks)
- Performance metrics tracking
- Dashboard data aggregation
"""

import asyncio
import json
import smtplib
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from enum import Enum
from typing import Optional, Any, Callable, Awaitable
from collections import deque

import httpx
import structlog

logger = structlog.get_logger(__name__)


# =============================================================================
# Data Models
# =============================================================================

class AlertPriority(Enum):
    """Alert priority levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class AlertType(Enum):
    """Types of alerts."""
    SIGNAL = "signal"  # Trading signal
    RISK = "risk"  # Risk threshold breach
    SYSTEM = "system"  # System health issue
    PERFORMANCE = "performance"  # Performance metric
    ERROR = "error"  # Application error


@dataclass
class Alert:
    """
    An alert to be sent through notification channels.
    
    Attributes:
        alert_id: Unique identifier
        alert_type: Type of alert
        priority: Priority level
        title: Short title
        message: Detailed message
        timestamp: When alert was generated
        metadata: Additional context
    """
    alert_id: str
    alert_type: AlertType
    priority: AlertPriority
    title: str
    message: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = field(default_factory=dict)
    acknowledged: bool = False
    acknowledged_at: Optional[datetime] = None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "alert_id": self.alert_id,
            "alert_type": self.alert_type.value,
            "priority": self.priority.value,
            "title": self.title,
            "message": self.message,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
            "acknowledged": self.acknowledged,
        }


@dataclass
class HealthStatus:
    """
    Health status of a system component.
    
    Attributes:
        component: Component name
        status: healthy, degraded, or unhealthy
        message: Status description
        last_check: When last checked
        metrics: Component-specific metrics
    """
    component: str
    status: str  # "healthy", "degraded", "unhealthy"
    message: str
    last_check: datetime
    metrics: dict[str, Any] = field(default_factory=dict)
    
    @property
    def is_healthy(self) -> bool:
        return self.status == "healthy"


@dataclass
class PerformanceMetrics:
    """
    Performance metrics snapshot.
    
    Attributes:
        timestamp: Snapshot time
        total_signals: Total signals generated
        actionable_signals: Signals above threshold
        active_positions: Current open positions
        daily_pnl: Today's P&L
        cumulative_return: Total return
        sharpe_ratio: Rolling Sharpe
        max_drawdown: Maximum drawdown
    """
    timestamp: datetime
    total_signals: int = 0
    actionable_signals: int = 0
    active_positions: int = 0
    daily_pnl: Decimal = Decimal("0")
    cumulative_return: Decimal = Decimal("0")
    sharpe_ratio: float = 0.0
    max_drawdown: Decimal = Decimal("0")
    win_rate: float = 0.0
    avg_edge: Decimal = Decimal("0")


# =============================================================================
# Alert Channels (Abstract)
# =============================================================================

class AlertChannel(ABC):
    """Abstract base class for alert notification channels."""
    
    @abstractmethod
    async def send(self, alert: Alert) -> bool:
        """
        Send alert through this channel.
        
        Args:
            alert: Alert to send
            
        Returns:
            True if sent successfully
        """
        pass
    
    @abstractmethod
    def should_send(self, alert: Alert) -> bool:
        """
        Check if alert should be sent through this channel.
        
        Args:
            alert: Alert to check
            
        Returns:
            True if alert should be sent
        """
        pass


# =============================================================================
# Slack Integration
# =============================================================================

class SlackChannel(AlertChannel):
    """
    Slack webhook notification channel.
    
    Sends formatted messages to Slack channels via incoming webhooks.
    """
    
    # Emoji mappings for priorities
    PRIORITY_EMOJI = {
        AlertPriority.CRITICAL: "🚨",
        AlertPriority.HIGH: "⚠️",
        AlertPriority.MEDIUM: "📊",
        AlertPriority.LOW: "ℹ️",
        AlertPriority.INFO: "📝",
    }
    
    def __init__(
        self,
        webhook_url: str,
        min_priority: AlertPriority = AlertPriority.LOW,
        alert_types: Optional[list[AlertType]] = None,
        channel_override: Optional[str] = None,
    ):
        """
        Initialize Slack channel.
        
        Args:
            webhook_url: Slack incoming webhook URL
            min_priority: Minimum priority to send
            alert_types: Types to send (all if None)
            channel_override: Override default channel
        """
        self.webhook_url = webhook_url
        self.min_priority = min_priority
        self.alert_types = alert_types
        self.channel_override = channel_override
        self._client = httpx.AsyncClient(timeout=10.0)
    
    def should_send(self, alert: Alert) -> bool:
        """Check if alert meets criteria."""
        priority_order = list(AlertPriority)
        if priority_order.index(alert.priority) > priority_order.index(self.min_priority):
            return False
        
        if self.alert_types and alert.alert_type not in self.alert_types:
            return False
        
        return True
    
    async def send(self, alert: Alert) -> bool:
        """Send alert to Slack."""
        if not self.should_send(alert):
            return False
        
        emoji = self.PRIORITY_EMOJI.get(alert.priority, "📋")
        
        # Build Slack message
        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"{emoji} {alert.title}",
                }
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": alert.message,
                }
            },
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": f"*Type:* {alert.alert_type.value} | *Priority:* {alert.priority.value} | *Time:* {alert.timestamp.strftime('%Y-%m-%d %H:%M UTC')}"
                    }
                ]
            }
        ]
        
        # Add metadata if present
        if alert.metadata:
            fields = []
            for key, value in list(alert.metadata.items())[:10]:
                fields.append({
                    "type": "mrkdwn",
                    "text": f"*{key}:* {value}"
                })
            
            if fields:
                blocks.append({
                    "type": "section",
                    "fields": fields[:10]  # Slack limit
                })
        
        payload = {"blocks": blocks}
        
        if self.channel_override:
            payload["channel"] = self.channel_override
        
        try:
            response = await self._client.post(
                self.webhook_url,
                json=payload,
            )
            response.raise_for_status()
            logger.info("slack_alert_sent", alert_id=alert.alert_id)
            return True
            
        except Exception as e:
            logger.error("slack_send_failed", error=str(e), alert_id=alert.alert_id)
            return False


# =============================================================================
# Email Integration
# =============================================================================

class EmailChannel(AlertChannel):
    """
    Email notification channel.
    
    Sends HTML formatted emails via SMTP.
    """
    
    def __init__(
        self,
        smtp_host: str,
        smtp_port: int,
        username: str,
        password: str,
        from_address: str,
        to_addresses: list[str],
        min_priority: AlertPriority = AlertPriority.HIGH,
        alert_types: Optional[list[AlertType]] = None,
        use_tls: bool = True,
    ):
        """
        Initialize email channel.
        
        Args:
            smtp_host: SMTP server hostname
            smtp_port: SMTP server port
            username: SMTP username
            password: SMTP password
            from_address: Sender email
            to_addresses: Recipient emails
            min_priority: Minimum priority to send
            alert_types: Types to send
            use_tls: Use TLS connection
        """
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
        self.from_address = from_address
        self.to_addresses = to_addresses
        self.min_priority = min_priority
        self.alert_types = alert_types
        self.use_tls = use_tls
    
    def should_send(self, alert: Alert) -> bool:
        """Check if alert meets criteria."""
        priority_order = list(AlertPriority)
        if priority_order.index(alert.priority) > priority_order.index(self.min_priority):
            return False
        
        if self.alert_types and alert.alert_type not in self.alert_types:
            return False
        
        return True
    
    async def send(self, alert: Alert) -> bool:
        """Send alert via email."""
        if not self.should_send(alert):
            return False
        
        # Build HTML email
        html_content = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .alert-box {{ 
                    padding: 20px; 
                    border-radius: 5px; 
                    margin: 20px 0;
                }}
                .critical {{ background-color: #ffebee; border-left: 4px solid #f44336; }}
                .high {{ background-color: #fff3e0; border-left: 4px solid #ff9800; }}
                .medium {{ background-color: #e3f2fd; border-left: 4px solid #2196f3; }}
                .low {{ background-color: #f5f5f5; border-left: 4px solid #9e9e9e; }}
                .info {{ background-color: #e8f5e9; border-left: 4px solid #4caf50; }}
                .metadata {{ margin-top: 15px; padding: 10px; background: #fafafa; }}
                .metadata th {{ text-align: left; padding-right: 20px; }}
            </style>
        </head>
        <body>
            <h2>Polymarket Edge Alert</h2>
            <div class="alert-box {alert.priority.value}">
                <h3>{alert.title}</h3>
                <p>{alert.message}</p>
                <p><small>
                    <strong>Type:</strong> {alert.alert_type.value} | 
                    <strong>Priority:</strong> {alert.priority.value} | 
                    <strong>Time:</strong> {alert.timestamp.strftime('%Y-%m-%d %H:%M UTC')}
                </small></p>
            </div>
        """
        
        if alert.metadata:
            html_content += """
            <div class="metadata">
                <h4>Details</h4>
                <table>
            """
            for key, value in alert.metadata.items():
                html_content += f"<tr><th>{key}</th><td>{value}</td></tr>"
            html_content += "</table></div>"
        
        html_content += """
        </body>
        </html>
        """
        
        # Create message
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"[{alert.priority.value.upper()}] {alert.title}"
        msg["From"] = self.from_address
        msg["To"] = ", ".join(self.to_addresses)
        
        msg.attach(MIMEText(alert.message, "plain"))
        msg.attach(MIMEText(html_content, "html"))
        
        # Send in thread pool to avoid blocking
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(None, self._send_sync, msg)
            logger.info("email_alert_sent", alert_id=alert.alert_id)
            return True
        except Exception as e:
            logger.error("email_send_failed", error=str(e), alert_id=alert.alert_id)
            return False
    
    def _send_sync(self, msg: MIMEMultipart) -> None:
        """Synchronous email send."""
        with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
            if self.use_tls:
                server.starttls()
            server.login(self.username, self.password)
            server.send_message(msg)


# =============================================================================
# Webhook Integration
# =============================================================================

class WebhookChannel(AlertChannel):
    """
    Generic webhook notification channel.
    
    Posts JSON to any HTTP endpoint.
    """
    
    def __init__(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        min_priority: AlertPriority = AlertPriority.LOW,
        alert_types: Optional[list[AlertType]] = None,
    ):
        """
        Initialize webhook channel.
        
        Args:
            url: Webhook URL
            headers: Additional HTTP headers
            min_priority: Minimum priority
            alert_types: Types to send
        """
        self.url = url
        self.headers = headers or {}
        self.min_priority = min_priority
        self.alert_types = alert_types
        self._client = httpx.AsyncClient(timeout=10.0)
    
    def should_send(self, alert: Alert) -> bool:
        """Check if alert meets criteria."""
        priority_order = list(AlertPriority)
        if priority_order.index(alert.priority) > priority_order.index(self.min_priority):
            return False
        
        if self.alert_types and alert.alert_type not in self.alert_types:
            return False
        
        return True
    
    async def send(self, alert: Alert) -> bool:
        """Send alert to webhook."""
        if not self.should_send(alert):
            return False
        
        payload = alert.to_dict()
        
        try:
            response = await self._client.post(
                self.url,
                json=payload,
                headers=self.headers,
            )
            response.raise_for_status()
            logger.info("webhook_alert_sent", alert_id=alert.alert_id, url=self.url)
            return True
            
        except Exception as e:
            logger.error("webhook_send_failed", error=str(e), alert_id=alert.alert_id)
            return False


# =============================================================================
# Alert Manager
# =============================================================================

class AlertManager:
    """
    Central alert management system.
    
    Routes alerts to appropriate channels and manages alert history.
    """
    
    def __init__(
        self,
        channels: Optional[list[AlertChannel]] = None,
        history_size: int = 1000,
        dedup_window_seconds: int = 300,
    ):
        """
        Initialize alert manager.
        
        Args:
            channels: Notification channels
            history_size: Max alerts to keep in history
            dedup_window_seconds: Time window for deduplication
        """
        self.channels = channels or []
        self._history: deque[Alert] = deque(maxlen=history_size)
        self._dedup_window = dedup_window_seconds
        self._alert_count = 0
        self._sent_hashes: dict[str, datetime] = {}
    
    def add_channel(self, channel: AlertChannel) -> None:
        """Add notification channel."""
        self.channels.append(channel)
    
    def _generate_alert_id(self) -> str:
        """Generate unique alert ID."""
        self._alert_count += 1
        return f"alert_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{self._alert_count:04d}"
    
    def _get_dedup_hash(self, alert: Alert) -> str:
        """Generate hash for deduplication."""
        import hashlib
        content = f"{alert.alert_type.value}:{alert.title}:{alert.priority.value}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]
    
    def _is_duplicate(self, alert: Alert) -> bool:
        """Check if alert is duplicate within window."""
        hash_key = self._get_dedup_hash(alert)
        
        if hash_key in self._sent_hashes:
            last_sent = self._sent_hashes[hash_key]
            if (alert.timestamp - last_sent).total_seconds() < self._dedup_window:
                return True
        
        self._sent_hashes[hash_key] = alert.timestamp
        return False
    
    async def send_alert(
        self,
        alert_type: AlertType,
        priority: AlertPriority,
        title: str,
        message: str,
        metadata: Optional[dict[str, Any]] = None,
        skip_dedup: bool = False,
    ) -> Alert:
        """
        Create and send an alert.
        
        Args:
            alert_type: Type of alert
            priority: Priority level
            title: Alert title
            message: Alert message
            metadata: Additional context
            skip_dedup: Skip deduplication check
            
        Returns:
            Created Alert object
        """
        alert = Alert(
            alert_id=self._generate_alert_id(),
            alert_type=alert_type,
            priority=priority,
            title=title,
            message=message,
            metadata=metadata or {},
        )
        
        # Add to history
        self._history.append(alert)
        
        # Check for duplicate
        if not skip_dedup and self._is_duplicate(alert):
            logger.debug("duplicate_alert_skipped", alert_id=alert.alert_id)
            return alert
        
        # Send to all channels
        tasks = [channel.send(alert) for channel in self.channels]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        sent_count = sum(1 for r in results if r is True)
        logger.info(
            "alert_dispatched",
            alert_id=alert.alert_id,
            channels_sent=sent_count,
            total_channels=len(self.channels),
        )
        
        return alert
    
    def get_recent_alerts(
        self,
        count: int = 50,
        alert_type: Optional[AlertType] = None,
        priority: Optional[AlertPriority] = None,
    ) -> list[Alert]:
        """Get recent alerts with optional filtering."""
        alerts = list(self._history)
        
        if alert_type:
            alerts = [a for a in alerts if a.alert_type == alert_type]
        
        if priority:
            alerts = [a for a in alerts if a.priority == priority]
        
        return alerts[-count:]
    
    def acknowledge_alert(self, alert_id: str) -> bool:
        """Mark alert as acknowledged."""
        for alert in self._history:
            if alert.alert_id == alert_id:
                alert.acknowledged = True
                alert.acknowledged_at = datetime.utcnow()
                return True
        return False


# =============================================================================
# Health Monitor
# =============================================================================

class HealthMonitor:
    """
    System health monitoring.
    
    Tracks health of various components and triggers alerts on issues.
    """
    
    def __init__(
        self,
        alert_manager: Optional[AlertManager] = None,
        check_interval: float = 60.0,
    ):
        """
        Initialize health monitor.
        
        Args:
            alert_manager: Alert manager for notifications
            check_interval: Seconds between health checks
        """
        self.alert_manager = alert_manager
        self.check_interval = check_interval
        self._checks: dict[str, Callable[[], Awaitable[HealthStatus]]] = {}
        self._status: dict[str, HealthStatus] = {}
        self._running = False
    
    def register_check(
        self,
        name: str,
        check_fn: Callable[[], Awaitable[HealthStatus]],
    ) -> None:
        """
        Register a health check.
        
        Args:
            name: Component name
            check_fn: Async function that returns HealthStatus
        """
        self._checks[name] = check_fn
    
    async def check_all(self) -> dict[str, HealthStatus]:
        """Run all health checks."""
        results = {}
        
        for name, check_fn in self._checks.items():
            try:
                status = await check_fn()
                results[name] = status
                self._status[name] = status
                
                # Alert on unhealthy
                if self.alert_manager and status.status == "unhealthy":
                    await self.alert_manager.send_alert(
                        alert_type=AlertType.SYSTEM,
                        priority=AlertPriority.HIGH,
                        title=f"Component Unhealthy: {name}",
                        message=status.message,
                        metadata=status.metrics,
                    )
                    
            except Exception as e:
                status = HealthStatus(
                    component=name,
                    status="unhealthy",
                    message=f"Health check failed: {e}",
                    last_check=datetime.utcnow(),
                )
                results[name] = status
                self._status[name] = status
                logger.error("health_check_failed", component=name, error=str(e))
        
        return results
    
    async def start(self) -> None:
        """Start continuous health monitoring."""
        self._running = True
        
        while self._running:
            await self.check_all()
            await asyncio.sleep(self.check_interval)
    
    def stop(self) -> None:
        """Stop health monitoring."""
        self._running = False
    
    def get_status(self) -> dict[str, HealthStatus]:
        """Get current health status of all components."""
        return self._status.copy()
    
    def get_overall_status(self) -> str:
        """Get overall system status."""
        if not self._status:
            return "unknown"
        
        statuses = [s.status for s in self._status.values()]
        
        if "unhealthy" in statuses:
            return "unhealthy"
        elif "degraded" in statuses:
            return "degraded"
        else:
            return "healthy"


# =============================================================================
# Metrics Collector
# =============================================================================

class MetricsCollector:
    """
    Collects and aggregates performance metrics.
    
    Provides data for dashboards and performance analysis.
    """
    
    def __init__(self, history_size: int = 10000):
        """
        Initialize metrics collector.
        
        Args:
            history_size: Max data points to retain
        """
        self._metrics: deque[PerformanceMetrics] = deque(maxlen=history_size)
        self._signal_count = 0
        self._actionable_count = 0
        self._daily_pnl = Decimal("0")
        self._cumulative_return = Decimal("0")
    
    def record_signal(self, is_actionable: bool, edge: Decimal) -> None:
        """Record a signal generation."""
        self._signal_count += 1
        if is_actionable:
            self._actionable_count += 1
    
    def record_trade_result(
        self,
        pnl: Decimal,
        is_win: bool,
    ) -> None:
        """Record a trade result."""
        self._daily_pnl += pnl
        self._cumulative_return += pnl
    
    def snapshot(self) -> PerformanceMetrics:
        """Take a metrics snapshot."""
        metrics = PerformanceMetrics(
            timestamp=datetime.utcnow(),
            total_signals=self._signal_count,
            actionable_signals=self._actionable_count,
            daily_pnl=self._daily_pnl,
            cumulative_return=self._cumulative_return,
        )
        
        self._metrics.append(metrics)
        return metrics
    
    def reset_daily(self) -> None:
        """Reset daily metrics."""
        self._daily_pnl = Decimal("0")
    
    def get_time_series(
        self,
        metric_name: str,
        hours: int = 24,
    ) -> list[tuple[datetime, Any]]:
        """Get time series for a metric."""
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        
        points = []
        for m in self._metrics:
            if m.timestamp >= cutoff:
                value = getattr(m, metric_name, None)
                if value is not None:
                    points.append((m.timestamp, value))
        
        return points
    
    def get_summary(self) -> dict[str, Any]:
        """Get metrics summary."""
        return {
            "total_signals": self._signal_count,
            "actionable_signals": self._actionable_count,
            "actionable_rate": (
                self._actionable_count / self._signal_count 
                if self._signal_count > 0 else 0
            ),
            "daily_pnl": float(self._daily_pnl),
            "cumulative_return": float(self._cumulative_return),
            "snapshots": len(self._metrics),
        }


# =============================================================================
# Dashboard Data Provider
# =============================================================================

class DashboardProvider:
    """
    Provides aggregated data for monitoring dashboards.
    
    Can be used to power Grafana, custom dashboards, or API endpoints.
    """
    
    def __init__(
        self,
        health_monitor: HealthMonitor,
        metrics_collector: MetricsCollector,
        alert_manager: AlertManager,
    ):
        """
        Initialize dashboard provider.
        
        Args:
            health_monitor: Health monitoring instance
            metrics_collector: Metrics collection instance
            alert_manager: Alert management instance
        """
        self.health = health_monitor
        self.metrics = metrics_collector
        self.alerts = alert_manager
    
    def get_dashboard_data(self) -> dict[str, Any]:
        """Get complete dashboard data."""
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "system": {
                "overall_status": self.health.get_overall_status(),
                "components": {
                    name: {
                        "status": status.status,
                        "message": status.message,
                        "last_check": status.last_check.isoformat(),
                    }
                    for name, status in self.health.get_status().items()
                },
            },
            "performance": self.metrics.get_summary(),
            "alerts": {
                "recent": [
                    alert.to_dict() 
                    for alert in self.alerts.get_recent_alerts(count=10)
                ],
                "unacknowledged": sum(
                    1 for a in self.alerts.get_recent_alerts() 
                    if not a.acknowledged
                ),
            },
        }
    
    def get_prometheus_metrics(self) -> str:
        """
        Get metrics in Prometheus format.
        
        Returns:
            Prometheus-formatted metrics string
        """
        summary = self.metrics.get_summary()
        health_status = self.health.get_status()
        
        lines = [
            "# HELP polymarket_signals_total Total signals generated",
            "# TYPE polymarket_signals_total counter",
            f"polymarket_signals_total {summary['total_signals']}",
            "",
            "# HELP polymarket_actionable_signals_total Actionable signals",
            "# TYPE polymarket_actionable_signals_total counter",
            f"polymarket_actionable_signals_total {summary['actionable_signals']}",
            "",
            "# HELP polymarket_cumulative_return_usd Cumulative return in USD",
            "# TYPE polymarket_cumulative_return_usd gauge",
            f"polymarket_cumulative_return_usd {summary['cumulative_return']}",
            "",
            "# HELP polymarket_component_healthy Component health (1=healthy, 0=unhealthy)",
            "# TYPE polymarket_component_healthy gauge",
        ]
        
        for name, status in health_status.items():
            value = 1 if status.is_healthy else 0
            lines.append(f'polymarket_component_healthy{{component="{name}"}} {value}')
        
        return "\n".join(lines)


# =============================================================================
# Built-in Health Checks
# =============================================================================

async def check_api_health(client) -> HealthStatus:
    """Check Polymarket API health."""
    try:
        start = datetime.utcnow()
        # Attempt a simple API call
        markets = await client.get_markets(limit=1)
        latency = (datetime.utcnow() - start).total_seconds()
        
        if markets:
            return HealthStatus(
                component="polymarket_api",
                status="healthy",
                message="API responding normally",
                last_check=datetime.utcnow(),
                metrics={"latency_seconds": latency},
            )
        else:
            return HealthStatus(
                component="polymarket_api",
                status="degraded",
                message="API returned empty response",
                last_check=datetime.utcnow(),
            )
    except Exception as e:
        return HealthStatus(
            component="polymarket_api",
            status="unhealthy",
            message=f"API error: {str(e)}",
            last_check=datetime.utcnow(),
        )


async def check_database_health(db) -> HealthStatus:
    """Check database connection health."""
    try:
        start = datetime.utcnow()
        # Execute simple query
        async with db.get_session() as session:
            await session.execute("SELECT 1")
        latency = (datetime.utcnow() - start).total_seconds()
        
        return HealthStatus(
            component="database",
            status="healthy",
            message="Database connected",
            last_check=datetime.utcnow(),
            metrics={"latency_seconds": latency},
        )
    except Exception as e:
        return HealthStatus(
            component="database",
            status="unhealthy",
            message=f"Database error: {str(e)}",
            last_check=datetime.utcnow(),
        )


if __name__ == "__main__":
    async def demo():
        print("Monitoring System Demo")
        print("=" * 50)
        
        # Create alert manager
        alert_manager = AlertManager()
        
        # Create metrics collector
        metrics = MetricsCollector()
        
        # Create health monitor
        health = HealthMonitor(alert_manager)
        
        # Register a sample health check
        async def sample_check() -> HealthStatus:
            return HealthStatus(
                component="sample",
                status="healthy",
                message="Sample component is working",
                last_check=datetime.utcnow(),
                metrics={"sample_metric": 42},
            )
        
        health.register_check("sample", sample_check)
        
        # Run health checks
        print("\nRunning health checks...")
        results = await health.check_all()
        
        for name, status in results.items():
            print(f"  {name}: {status.status} - {status.message}")
        
        # Record some metrics
        print("\nRecording metrics...")
        for i in range(10):
            metrics.record_signal(is_actionable=(i % 3 == 0), edge=Decimal("0.05"))
        
        metrics.record_trade_result(pnl=Decimal("100"), is_win=True)
        metrics.record_trade_result(pnl=Decimal("-50"), is_win=False)
        
        summary = metrics.get_summary()
        print(f"  Total signals: {summary['total_signals']}")
        print(f"  Actionable: {summary['actionable_signals']}")
        print(f"  Cumulative return: ${summary['cumulative_return']}")
        
        # Create dashboard provider
        dashboard = DashboardProvider(health, metrics, alert_manager)
        
        print("\nDashboard Data:")
        data = dashboard.get_dashboard_data()
        print(f"  System status: {data['system']['overall_status']}")
        print(f"  Performance: {data['performance']}")
        
        print("\nPrometheus Metrics:")
        print(dashboard.get_prometheus_metrics()[:500] + "...")
        
        # Send test alert
        print("\nSending test alert...")
        alert = await alert_manager.send_alert(
            alert_type=AlertType.SIGNAL,
            priority=AlertPriority.MEDIUM,
            title="Test Signal Alert",
            message="This is a test alert from the monitoring demo",
            metadata={"market_id": "test123", "edge": "5.2%"},
        )
        print(f"  Created alert: {alert.alert_id}")
        
        print("\nDemo complete!")
    
    asyncio.run(demo())
