"""
Portfolio Management & P&L Tracking for Polymarket Edge System.

Provides:
- Position tracking with entry/exit management
- Real-time P&L calculation
- Portfolio analytics and risk metrics
- Trade journaling and performance attribution
"""

import uuid
from datetime import datetime, timedelta
from decimal import Decimal
from enum import Enum
from typing import Optional
from dataclasses import dataclass, field

import numpy as np
from pydantic import BaseModel, Field


# =============================================================================
# Enums and Constants
# =============================================================================

class PositionSide(str, Enum):
    """Position side."""
    LONG = "LONG"
    SHORT = "SHORT"
    

class PositionStatus(str, Enum):
    """Position status."""
    OPEN = "OPEN"
    CLOSED = "CLOSED"
    PARTIAL = "PARTIAL"  # Partially closed
    EXPIRED = "EXPIRED"  # Market resolved
    

class TradeType(str, Enum):
    """Type of trade."""
    ENTRY = "ENTRY"
    EXIT = "EXIT"
    ADD = "ADD"  # Adding to position
    REDUCE = "REDUCE"  # Partial close
    

# Fee structure (Polymarket)
MAKER_FEE = 0.0  # 0% maker fee
TAKER_FEE = 0.01  # 1% taker fee (simplified)


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class Trade:
    """Individual trade record."""
    trade_id: str
    position_id: str
    market_id: str
    outcome_id: str
    trade_type: TradeType
    side: PositionSide
    size: float
    price: float
    fee: float
    timestamp: datetime
    signal_id: Optional[str] = None
    notes: Optional[str] = None
    
    @property
    def gross_value(self) -> float:
        """Trade value before fees."""
        return self.size * self.price
    
    @property
    def net_value(self) -> float:
        """Trade value after fees."""
        return self.gross_value - self.fee
        

@dataclass
class Position:
    """Trading position."""
    position_id: str
    market_id: str
    outcome_id: str
    outcome_name: str
    market_question: str
    side: PositionSide
    status: PositionStatus
    
    # Position sizing
    entry_size: float
    current_size: float
    avg_entry_price: float
    
    # P&L tracking
    realized_pnl: float = 0.0
    total_fees: float = 0.0
    
    # Timestamps
    opened_at: datetime = field(default_factory=datetime.utcnow)
    closed_at: Optional[datetime] = None
    last_updated: datetime = field(default_factory=datetime.utcnow)
    
    # Trade history
    trades: list[Trade] = field(default_factory=list)
    
    # Signal attribution
    signal_id: Optional[str] = None
    entry_edge: Optional[float] = None
    entry_confluence: Optional[float] = None
    
    def calculate_unrealized_pnl(self, current_price: float) -> float:
        """Calculate unrealized P&L at current price."""
        if self.current_size == 0:
            return 0.0
            
        if self.side == PositionSide.LONG:
            return (current_price - self.avg_entry_price) * self.current_size
        else:
            return (self.avg_entry_price - current_price) * self.current_size
    
    def calculate_total_pnl(self, current_price: float) -> float:
        """Calculate total P&L (realized + unrealized)."""
        return self.realized_pnl + self.calculate_unrealized_pnl(current_price)
    
    def calculate_return_pct(self, current_price: float) -> float:
        """Calculate return percentage."""
        initial_value = self.entry_size * self.avg_entry_price
        if initial_value == 0:
            return 0.0
        return self.calculate_total_pnl(current_price) / initial_value * 100
    
    def add_trade(self, trade: Trade):
        """Record a trade and update position."""
        self.trades.append(trade)
        self.total_fees += trade.fee
        self.last_updated = datetime.utcnow()
        
        if trade.trade_type == TradeType.ENTRY:
            # Initial entry
            self.current_size = trade.size
            self.avg_entry_price = trade.price
            
        elif trade.trade_type == TradeType.ADD:
            # Adding to position - weighted average entry
            total_cost = (self.avg_entry_price * self.current_size) + (trade.price * trade.size)
            self.current_size += trade.size
            self.avg_entry_price = total_cost / self.current_size
            
        elif trade.trade_type in [TradeType.EXIT, TradeType.REDUCE]:
            # Closing or reducing position
            if self.side == PositionSide.LONG:
                pnl = (trade.price - self.avg_entry_price) * trade.size
            else:
                pnl = (self.avg_entry_price - trade.price) * trade.size
                
            self.realized_pnl += pnl - trade.fee
            self.current_size -= trade.size
            
            if self.current_size <= 0:
                self.status = PositionStatus.CLOSED
                self.closed_at = datetime.utcnow()
            else:
                self.status = PositionStatus.PARTIAL


@dataclass
class PortfolioSnapshot:
    """Point-in-time portfolio snapshot."""
    timestamp: datetime
    total_value: float
    cash_balance: float
    positions_value: float
    unrealized_pnl: float
    realized_pnl: float
    total_pnl: float
    position_count: int
    

class PerformanceMetrics(BaseModel):
    """Portfolio performance metrics."""
    # Returns
    total_return: float = 0.0
    total_return_pct: float = 0.0
    daily_returns: list[float] = Field(default_factory=list)
    
    # Risk metrics
    sharpe_ratio: Optional[float] = None
    sortino_ratio: Optional[float] = None
    max_drawdown: float = 0.0
    max_drawdown_duration_days: int = 0
    volatility: Optional[float] = None
    
    # Trade statistics
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate: float = 0.0
    avg_win: float = 0.0
    avg_loss: float = 0.0
    profit_factor: Optional[float] = None
    expectancy: float = 0.0
    
    # Time metrics
    avg_hold_time_hours: float = 0.0
    best_trade_pnl: float = 0.0
    worst_trade_pnl: float = 0.0


# =============================================================================
# Portfolio Manager
# =============================================================================

class PortfolioManager:
    """
    Manages portfolio state, positions, and P&L calculations.
    """
    
    def __init__(
        self,
        initial_capital: float = 10000.0,
        max_position_pct: float = 0.1,
        max_total_exposure: float = 0.8,
    ):
        self.initial_capital = initial_capital
        self.cash_balance = initial_capital
        self.max_position_pct = max_position_pct
        self.max_total_exposure = max_total_exposure
        
        # Position tracking
        self.positions: dict[str, Position] = {}
        self.closed_positions: list[Position] = []
        
        # Historical snapshots
        self.snapshots: list[PortfolioSnapshot] = []
        self.daily_values: list[tuple[datetime, float]] = []
        
        # Trade journal
        self.all_trades: list[Trade] = []
        
    # -------------------------------------------------------------------------
    # Position Management
    # -------------------------------------------------------------------------
    
    def open_position(
        self,
        market_id: str,
        outcome_id: str,
        outcome_name: str,
        market_question: str,
        side: PositionSide,
        size: float,
        price: float,
        signal_id: Optional[str] = None,
        entry_edge: Optional[float] = None,
        entry_confluence: Optional[float] = None,
        is_maker: bool = False,
    ) -> Position:
        """Open a new position."""
        # Validate
        cost = size * price
        fee = cost * (MAKER_FEE if is_maker else TAKER_FEE)
        total_cost = cost + fee
        
        if total_cost > self.cash_balance:
            raise ValueError(f"Insufficient funds: need {total_cost:.2f}, have {self.cash_balance:.2f}")
        
        # Check position limits
        if cost > self.initial_capital * self.max_position_pct:
            raise ValueError(f"Position exceeds max size: {cost:.2f} > {self.initial_capital * self.max_position_pct:.2f}")
        
        # Check total exposure
        current_exposure = sum(p.current_size * p.avg_entry_price for p in self.positions.values())
        if (current_exposure + cost) > self.initial_capital * self.max_total_exposure:
            raise ValueError("Total exposure would exceed limit")
        
        # Create position
        position_id = str(uuid.uuid4())[:12]
        position = Position(
            position_id=position_id,
            market_id=market_id,
            outcome_id=outcome_id,
            outcome_name=outcome_name,
            market_question=market_question,
            side=side,
            status=PositionStatus.OPEN,
            entry_size=size,
            current_size=0,  # Will be set by add_trade
            avg_entry_price=0,
            signal_id=signal_id,
            entry_edge=entry_edge,
            entry_confluence=entry_confluence,
        )
        
        # Create entry trade
        trade = Trade(
            trade_id=str(uuid.uuid4())[:12],
            position_id=position_id,
            market_id=market_id,
            outcome_id=outcome_id,
            trade_type=TradeType.ENTRY,
            side=side,
            size=size,
            price=price,
            fee=fee,
            timestamp=datetime.utcnow(),
            signal_id=signal_id,
        )
        
        position.add_trade(trade)
        self.positions[position_id] = position
        self.all_trades.append(trade)
        
        # Deduct cash
        self.cash_balance -= total_cost
        
        return position
    
    def add_to_position(
        self,
        position_id: str,
        size: float,
        price: float,
        is_maker: bool = False,
    ) -> Position:
        """Add to an existing position."""
        if position_id not in self.positions:
            raise ValueError(f"Position {position_id} not found")
        
        position = self.positions[position_id]
        if position.status != PositionStatus.OPEN:
            raise ValueError(f"Position is {position.status.value}")
        
        cost = size * price
        fee = cost * (MAKER_FEE if is_maker else TAKER_FEE)
        total_cost = cost + fee
        
        if total_cost > self.cash_balance:
            raise ValueError(f"Insufficient funds")
        
        trade = Trade(
            trade_id=str(uuid.uuid4())[:12],
            position_id=position_id,
            market_id=position.market_id,
            outcome_id=position.outcome_id,
            trade_type=TradeType.ADD,
            side=position.side,
            size=size,
            price=price,
            fee=fee,
            timestamp=datetime.utcnow(),
        )
        
        position.add_trade(trade)
        self.all_trades.append(trade)
        self.cash_balance -= total_cost
        
        return position
    
    def close_position(
        self,
        position_id: str,
        price: float,
        size: Optional[float] = None,
        is_maker: bool = False,
        reason: Optional[str] = None,
    ) -> tuple[Position, float]:
        """Close or partially close a position. Returns (position, realized_pnl)."""
        if position_id not in self.positions:
            raise ValueError(f"Position {position_id} not found")
        
        position = self.positions[position_id]
        if position.status == PositionStatus.CLOSED:
            raise ValueError("Position already closed")
        
        close_size = size if size else position.current_size
        if close_size > position.current_size:
            raise ValueError(f"Close size {close_size} exceeds position size {position.current_size}")
        
        # Calculate trade
        proceeds = close_size * price
        fee = proceeds * (MAKER_FEE if is_maker else TAKER_FEE)
        
        trade = Trade(
            trade_id=str(uuid.uuid4())[:12],
            position_id=position_id,
            market_id=position.market_id,
            outcome_id=position.outcome_id,
            trade_type=TradeType.EXIT if close_size == position.current_size else TradeType.REDUCE,
            side=position.side,
            size=close_size,
            price=price,
            fee=fee,
            timestamp=datetime.utcnow(),
            notes=reason,
        )
        
        # Calculate P&L before adding trade
        if position.side == PositionSide.LONG:
            pnl = (price - position.avg_entry_price) * close_size - fee
        else:
            pnl = (position.avg_entry_price - price) * close_size - fee
        
        position.add_trade(trade)
        self.all_trades.append(trade)
        
        # Add proceeds to cash
        self.cash_balance += proceeds - fee
        
        # Move to closed if fully closed
        if position.status == PositionStatus.CLOSED:
            self.closed_positions.append(position)
            del self.positions[position_id]
        
        return position, pnl
    
    def handle_resolution(
        self,
        market_id: str,
        outcome_id: str,
        resolved_price: float,  # 1.0 for winning outcome, 0.0 for losing
    ) -> list[tuple[Position, float]]:
        """Handle market resolution for affected positions."""
        results = []
        
        positions_to_close = [
            (pid, pos) for pid, pos in self.positions.items()
            if pos.market_id == market_id and pos.outcome_id == outcome_id
        ]
        
        for position_id, position in positions_to_close:
            position, pnl = self.close_position(
                position_id=position_id,
                price=resolved_price,
                is_maker=True,  # No fees on resolution
                reason="Market resolved",
            )
            position.status = PositionStatus.EXPIRED
            results.append((position, pnl))
        
        return results
    
    # -------------------------------------------------------------------------
    # Portfolio Calculations
    # -------------------------------------------------------------------------
    
    def get_portfolio_value(
        self,
        current_prices: dict[str, float],
    ) -> float:
        """Calculate total portfolio value given current prices."""
        positions_value = 0.0
        
        for position in self.positions.values():
            price = current_prices.get(position.outcome_id, position.avg_entry_price)
            positions_value += position.current_size * price
        
        return self.cash_balance + positions_value
    
    def get_total_pnl(
        self,
        current_prices: dict[str, float],
    ) -> tuple[float, float, float]:
        """Calculate total P&L. Returns (unrealized, realized, total)."""
        unrealized = 0.0
        realized = sum(p.realized_pnl for p in self.closed_positions)
        
        for position in self.positions.values():
            price = current_prices.get(position.outcome_id, position.avg_entry_price)
            unrealized += position.calculate_unrealized_pnl(price)
            realized += position.realized_pnl
        
        return unrealized, realized, unrealized + realized
    
    def take_snapshot(
        self,
        current_prices: dict[str, float],
    ) -> PortfolioSnapshot:
        """Take a point-in-time snapshot."""
        unrealized, realized, total_pnl = self.get_total_pnl(current_prices)
        portfolio_value = self.get_portfolio_value(current_prices)
        positions_value = portfolio_value - self.cash_balance
        
        snapshot = PortfolioSnapshot(
            timestamp=datetime.utcnow(),
            total_value=portfolio_value,
            cash_balance=self.cash_balance,
            positions_value=positions_value,
            unrealized_pnl=unrealized,
            realized_pnl=realized,
            total_pnl=total_pnl,
            position_count=len(self.positions),
        )
        
        self.snapshots.append(snapshot)
        self.daily_values.append((snapshot.timestamp, portfolio_value))
        
        return snapshot
    
    # -------------------------------------------------------------------------
    # Performance Analytics
    # -------------------------------------------------------------------------
    
    def calculate_performance_metrics(self) -> PerformanceMetrics:
        """Calculate comprehensive performance metrics."""
        metrics = PerformanceMetrics()
        
        # Return calculations
        if self.daily_values:
            start_value = self.initial_capital
            end_value = self.daily_values[-1][1]
            metrics.total_return = end_value - start_value
            metrics.total_return_pct = (end_value / start_value - 1) * 100
            
            # Daily returns
            if len(self.daily_values) > 1:
                values = [v for _, v in self.daily_values]
                metrics.daily_returns = [
                    (values[i] / values[i-1] - 1) for i in range(1, len(values))
                ]
        
        # Trade statistics
        all_closed = self.closed_positions + [
            p for p in self.positions.values() if p.status == PositionStatus.CLOSED
        ]
        
        if all_closed:
            metrics.total_trades = len(all_closed)
            
            wins = [p.realized_pnl for p in all_closed if p.realized_pnl > 0]
            losses = [p.realized_pnl for p in all_closed if p.realized_pnl <= 0]
            
            metrics.winning_trades = len(wins)
            metrics.losing_trades = len(losses)
            metrics.win_rate = len(wins) / len(all_closed) if all_closed else 0
            
            metrics.avg_win = np.mean(wins) if wins else 0
            metrics.avg_loss = np.mean(losses) if losses else 0
            
            metrics.best_trade_pnl = max(wins) if wins else 0
            metrics.worst_trade_pnl = min(losses) if losses else 0
            
            # Profit factor
            total_wins = sum(wins)
            total_losses = abs(sum(losses))
            if total_losses > 0:
                metrics.profit_factor = total_wins / total_losses
            
            # Expectancy
            metrics.expectancy = (
                metrics.win_rate * metrics.avg_win + 
                (1 - metrics.win_rate) * metrics.avg_loss
            )
            
            # Average hold time
            hold_times = []
            for p in all_closed:
                if p.closed_at and p.opened_at:
                    hold_times.append((p.closed_at - p.opened_at).total_seconds() / 3600)
            if hold_times:
                metrics.avg_hold_time_hours = np.mean(hold_times)
        
        # Risk metrics
        if metrics.daily_returns:
            returns = np.array(metrics.daily_returns)
            
            # Volatility (annualized)
            metrics.volatility = np.std(returns) * np.sqrt(365)
            
            # Sharpe ratio (assuming 0% risk-free rate)
            if metrics.volatility > 0:
                avg_daily_return = np.mean(returns)
                metrics.sharpe_ratio = (avg_daily_return * 365) / metrics.volatility
            
            # Sortino ratio (downside deviation)
            downside_returns = returns[returns < 0]
            if len(downside_returns) > 0:
                downside_vol = np.std(downside_returns) * np.sqrt(365)
                if downside_vol > 0:
                    metrics.sortino_ratio = (np.mean(returns) * 365) / downside_vol
            
            # Maximum drawdown
            if self.daily_values:
                values = np.array([v for _, v in self.daily_values])
                peak = np.maximum.accumulate(values)
                drawdown = (peak - values) / peak
                metrics.max_drawdown = np.max(drawdown)
                
                # Drawdown duration
                if metrics.max_drawdown > 0:
                    in_drawdown = drawdown > 0
                    drawdown_lengths = []
                    current_length = 0
                    for dd in in_drawdown:
                        if dd:
                            current_length += 1
                        else:
                            if current_length > 0:
                                drawdown_lengths.append(current_length)
                            current_length = 0
                    if drawdown_lengths:
                        metrics.max_drawdown_duration_days = max(drawdown_lengths)
        
        return metrics
    
    # -------------------------------------------------------------------------
    # Risk Management
    # -------------------------------------------------------------------------
    
    def get_exposure_by_category(self) -> dict[str, float]:
        """Get exposure breakdown by market category."""
        exposure = {}
        for position in self.positions.values():
            # Note: Would need market category from database
            category = "unknown"  # Placeholder
            current_value = position.current_size * position.avg_entry_price
            exposure[category] = exposure.get(category, 0) + current_value
        return exposure
    
    def get_position_sizes_pct(self) -> dict[str, float]:
        """Get position sizes as percentage of portfolio."""
        portfolio_value = self.cash_balance + sum(
            p.current_size * p.avg_entry_price for p in self.positions.values()
        )
        
        if portfolio_value == 0:
            return {}
        
        return {
            p.position_id: (p.current_size * p.avg_entry_price) / portfolio_value
            for p in self.positions.values()
        }
    
    def check_risk_limits(self) -> list[str]:
        """Check for risk limit violations. Returns list of warnings."""
        warnings = []
        
        portfolio_value = self.cash_balance + sum(
            p.current_size * p.avg_entry_price for p in self.positions.values()
        )
        
        for position in self.positions.values():
            position_value = position.current_size * position.avg_entry_price
            position_pct = position_value / portfolio_value if portfolio_value > 0 else 0
            
            if position_pct > self.max_position_pct:
                warnings.append(
                    f"Position {position.position_id} exceeds max size: "
                    f"{position_pct:.1%} > {self.max_position_pct:.1%}"
                )
        
        total_exposure = sum(
            p.current_size * p.avg_entry_price for p in self.positions.values()
        )
        exposure_pct = total_exposure / self.initial_capital
        
        if exposure_pct > self.max_total_exposure:
            warnings.append(
                f"Total exposure exceeds limit: {exposure_pct:.1%} > {self.max_total_exposure:.1%}"
            )
        
        return warnings
    
    # -------------------------------------------------------------------------
    # Reporting
    # -------------------------------------------------------------------------
    
    def generate_report(
        self,
        current_prices: dict[str, float],
    ) -> dict:
        """Generate comprehensive portfolio report."""
        snapshot = self.take_snapshot(current_prices)
        metrics = self.calculate_performance_metrics()
        warnings = self.check_risk_limits()
        
        return {
            "summary": {
                "total_value": snapshot.total_value,
                "cash_balance": snapshot.cash_balance,
                "positions_value": snapshot.positions_value,
                "total_pnl": snapshot.total_pnl,
                "total_return_pct": metrics.total_return_pct,
            },
            "positions": [
                {
                    "position_id": p.position_id,
                    "market_question": p.market_question,
                    "outcome_name": p.outcome_name,
                    "side": p.side.value,
                    "size": p.current_size,
                    "entry_price": p.avg_entry_price,
                    "current_price": current_prices.get(p.outcome_id, p.avg_entry_price),
                    "unrealized_pnl": p.calculate_unrealized_pnl(
                        current_prices.get(p.outcome_id, p.avg_entry_price)
                    ),
                    "return_pct": p.calculate_return_pct(
                        current_prices.get(p.outcome_id, p.avg_entry_price)
                    ),
                }
                for p in self.positions.values()
            ],
            "performance": metrics.model_dump(),
            "risk_warnings": warnings,
            "recent_trades": [
                {
                    "trade_id": t.trade_id,
                    "type": t.trade_type.value,
                    "side": t.side.value,
                    "size": t.size,
                    "price": t.price,
                    "timestamp": t.timestamp.isoformat(),
                }
                for t in sorted(self.all_trades, key=lambda x: x.timestamp, reverse=True)[:10]
            ],
        }
    
    def export_trades(self) -> list[dict]:
        """Export all trades for analysis."""
        return [
            {
                "trade_id": t.trade_id,
                "position_id": t.position_id,
                "market_id": t.market_id,
                "outcome_id": t.outcome_id,
                "type": t.trade_type.value,
                "side": t.side.value,
                "size": t.size,
                "price": t.price,
                "fee": t.fee,
                "gross_value": t.gross_value,
                "net_value": t.net_value,
                "timestamp": t.timestamp.isoformat(),
                "signal_id": t.signal_id,
                "notes": t.notes,
            }
            for t in self.all_trades
        ]


# =============================================================================
# Kelly Criterion Position Sizer
# =============================================================================

class KellyPositionSizer:
    """
    Position sizing using Kelly Criterion.
    
    Kelly formula: f* = (p * b - q) / b
    where:
        f* = optimal fraction to bet
        p = probability of winning
        q = probability of losing (1 - p)
        b = odds received on the bet
    
    For prediction markets:
        b = (1 - market_price) / market_price  (for buying YES)
    """
    
    def __init__(
        self,
        kelly_fraction: float = 0.25,  # Use fractional Kelly for safety
        max_position_pct: float = 0.1,
        min_edge_threshold: float = 0.02,
    ):
        self.kelly_fraction = kelly_fraction
        self.max_position_pct = max_position_pct
        self.min_edge_threshold = min_edge_threshold
    
    def calculate_optimal_size(
        self,
        model_probability: float,
        market_price: float,
        bankroll: float,
        confidence: float = 1.0,
    ) -> tuple[float, str]:
        """
        Calculate optimal position size.
        
        Args:
            model_probability: Our estimated probability
            market_price: Current market price
            bankroll: Available capital
            confidence: Confidence multiplier (0-1)
            
        Returns:
            (optimal_size_in_dollars, reasoning)
        """
        # Calculate edge
        edge = model_probability - market_price
        
        if abs(edge) < self.min_edge_threshold:
            return 0.0, f"Edge {edge:.2%} below threshold {self.min_edge_threshold:.2%}"
        
        # Determine direction
        if edge > 0:
            # Buy YES (we think it's underpriced)
            p = model_probability
            b = (1 - market_price) / market_price
        else:
            # Buy NO (we think YES is overpriced)
            p = 1 - model_probability
            b = market_price / (1 - market_price)
        
        q = 1 - p
        
        # Full Kelly
        full_kelly = (p * b - q) / b
        
        if full_kelly <= 0:
            return 0.0, f"Kelly fraction is negative ({full_kelly:.4f}), no bet"
        
        # Apply fractional Kelly and confidence
        adjusted_kelly = full_kelly * self.kelly_fraction * confidence
        
        # Apply max position constraint
        final_fraction = min(adjusted_kelly, self.max_position_pct)
        
        # Calculate dollar amount
        optimal_size = bankroll * final_fraction
        
        reasoning = (
            f"Full Kelly: {full_kelly:.2%}, "
            f"Fractional ({self.kelly_fraction}x): {full_kelly * self.kelly_fraction:.2%}, "
            f"With confidence ({confidence:.0%}): {adjusted_kelly:.2%}, "
            f"Capped at: {final_fraction:.2%}"
        )
        
        return optimal_size, reasoning
    
    def calculate_for_portfolio(
        self,
        opportunities: list[dict],
        bankroll: float,
        max_total_allocation: float = 0.5,
    ) -> list[dict]:
        """
        Calculate position sizes for multiple opportunities.
        
        Uses diversified Kelly to handle correlation.
        """
        # Sort by edge
        sorted_opps = sorted(opportunities, key=lambda x: abs(x["edge"]), reverse=True)
        
        allocations = []
        total_allocated = 0.0
        
        for opp in sorted_opps:
            remaining_budget = bankroll * max_total_allocation - total_allocated
            if remaining_budget <= 0:
                break
            
            size, reasoning = self.calculate_optimal_size(
                model_probability=opp["model_probability"],
                market_price=opp["market_price"],
                bankroll=remaining_budget,
                confidence=opp.get("confidence", 1.0),
            )
            
            if size > 0:
                allocations.append({
                    **opp,
                    "recommended_size": size,
                    "sizing_reasoning": reasoning,
                })
                total_allocated += size
        
        return allocations


# =============================================================================
# Trade Journal
# =============================================================================

class TradeJournal:
    """
    Trade journaling for performance review and improvement.
    """
    
    def __init__(self):
        self.entries: list[dict] = []
    
    def record_trade(
        self,
        trade: Trade,
        position: Position,
        market_context: dict,
        rationale: str,
        emotions: Optional[str] = None,
    ):
        """Record a trade with context."""
        self.entries.append({
            "timestamp": datetime.utcnow().isoformat(),
            "trade": {
                "trade_id": trade.trade_id,
                "type": trade.trade_type.value,
                "side": trade.side.value,
                "size": trade.size,
                "price": trade.price,
            },
            "position": {
                "position_id": position.position_id,
                "entry_price": position.avg_entry_price,
                "entry_edge": position.entry_edge,
                "entry_confluence": position.entry_confluence,
            },
            "context": market_context,
            "rationale": rationale,
            "emotions": emotions,
        })
    
    def record_outcome(
        self,
        position_id: str,
        exit_price: float,
        pnl: float,
        lessons_learned: Optional[str] = None,
    ):
        """Record trade outcome."""
        self.entries.append({
            "timestamp": datetime.utcnow().isoformat(),
            "type": "outcome",
            "position_id": position_id,
            "exit_price": exit_price,
            "pnl": pnl,
            "lessons_learned": lessons_learned,
        })
    
    def analyze_by_signal_strength(self) -> dict:
        """Analyze performance by signal strength."""
        # Group trades by signal strength
        by_strength = {}
        for entry in self.entries:
            if entry.get("type") == "outcome":
                continue
            strength = entry.get("position", {}).get("entry_confluence", 0)
            bucket = "strong" if strength > 0.7 else "moderate" if strength > 0.4 else "weak"
            if bucket not in by_strength:
                by_strength[bucket] = {"count": 0, "total_pnl": 0}
            by_strength[bucket]["count"] += 1
        
        # Match outcomes
        for entry in self.entries:
            if entry.get("type") != "outcome":
                continue
            # Would need to look up original trade...
        
        return by_strength
    
    def export(self) -> list[dict]:
        """Export journal entries."""
        return self.entries
