"""
Demo script showing how to use the Polymarket Edge system.

This demonstrates:
1. Fetching market data
2. Engineering features
3. Training models
4. Generating signals
5. Running backtests

Run with: python -m src.demo
"""

import asyncio
from datetime import datetime, timedelta
from decimal import Decimal
import numpy as np
import pandas as pd

# =============================================================================
# Example 1: Basic Edge Calculation
# =============================================================================

def demo_edge_calculation():
    """Demonstrate edge and Kelly fraction calculations."""
    print("\n" + "="*60)
    print("DEMO 1: Edge Calculation")
    print("="*60)
    
    from src.signals.edge import (
        calculate_edge,
        calculate_kelly_fraction,
        fractional_kelly,
    )
    
    # Scenario: Model estimates 65% probability, market price is 55%
    model_prob = 0.65
    market_prob = 0.55
    fees = 0.02
    
    edge, direction = calculate_edge(model_prob, market_prob, fees)
    full_kelly = calculate_kelly_fraction(model_prob, market_prob, fees)
    conservative_kelly = fractional_kelly(full_kelly, fraction=0.25)
    
    print(f"\nScenario:")
    print(f"  Model probability: {model_prob:.0%}")
    print(f"  Market price: {market_prob:.0%}")
    print(f"  Trading fees: {fees:.0%}")
    
    print(f"\nResults:")
    print(f"  Edge: {edge:.2%}")
    print(f"  Direction: {direction}")
    print(f"  Full Kelly fraction: {full_kelly:.2%}")
    print(f"  Conservative Kelly (25%): {conservative_kelly:.2%}")
    
    # Calculate expected return per $100 bet
    if direction == "YES":
        expected_profit = 100 * conservative_kelly * edge
        print(f"\n  Expected profit on ${100*conservative_kelly:.2f} bet: ${expected_profit:.2f}")


# =============================================================================
# Example 2: Signal Generation
# =============================================================================

def demo_signal_generation():
    """Demonstrate generating trading signals."""
    print("\n" + "="*60)
    print("DEMO 2: Signal Generation")
    print("="*60)
    
    from src.signals.edge import SignalGenerator, EdgeConfig
    
    # Create signal generator with custom config
    config = EdgeConfig(
        trading_fee_pct=0.02,
        kelly_fraction=0.25,
        min_edge_strong=0.05,
        min_edge_moderate=0.03,
    )
    generator = SignalGenerator(config)
    
    # Generate signals for different scenarios
    scenarios = [
        {
            "name": "Strong Signal",
            "model_prob": 0.70,
            "market_prob": 0.55,
            "model_agreement": 0.9,
        },
        {
            "name": "Moderate Signal",
            "model_prob": 0.62,
            "market_prob": 0.55,
            "model_agreement": 0.7,
        },
        {
            "name": "Weak Signal",
            "model_prob": 0.58,
            "market_prob": 0.55,
            "model_agreement": 0.5,
        },
        {
            "name": "No Edge",
            "model_prob": 0.56,
            "market_prob": 0.55,
            "model_agreement": 0.5,
        },
    ]
    
    print("\nSignal Generation Results:")
    print("-" * 80)
    print(f"{'Scenario':<20} {'Model':<8} {'Market':<8} {'Edge':<8} {'Kelly':<8} {'Strength':<10}")
    print("-" * 80)
    
    for s in scenarios:
        signal = generator.generate_signal(
            outcome_id="demo_outcome",
            model_prob=s["model_prob"],
            market_prob=s["market_prob"],
            model_agreement=s["model_agreement"],
        )
        
        print(
            f"{s['name']:<20} "
            f"{s['model_prob']:<8.0%} "
            f"{s['market_prob']:<8.0%} "
            f"{float(signal.edge):<8.2%} "
            f"{float(signal.kelly_fraction):<8.2%} "
            f"{signal.signal_strength.value:<10}"
        )


# =============================================================================
# Example 3: Feature Engineering
# =============================================================================

def demo_feature_engineering():
    """Demonstrate feature engineering from market data."""
    print("\n" + "="*60)
    print("DEMO 3: Feature Engineering")
    print("="*60)
    
    from src.data.models import Market, Outcome, PriceSnapshot, Trade, TradeSide
    from src.features.engineering import FeatureEngineer, FeatureSet
    
    # Create sample market data
    market = Market(
        market_id="demo_market",
        condition_id="0x123",
        question="Will it rain tomorrow?",
        category="Weather",
        end_date=datetime.utcnow() + timedelta(days=1),
        created_at=datetime.utcnow() - timedelta(days=7),
    )
    
    outcome = Outcome(
        outcome_id="demo_yes",
        market_id="demo_market",
        token_id="0x456",
        outcome_name="Yes",
    )
    
    current_price = PriceSnapshot(
        ts=datetime.utcnow(),
        outcome_id="demo_yes",
        mid_price=Decimal("0.65"),
        bid_price=Decimal("0.64"),
        ask_price=Decimal("0.66"),
        spread=Decimal("0.02"),
        bid_depth_1pct=Decimal("5000"),
        ask_depth_1pct=Decimal("4000"),
        volume_24h=Decimal("50000"),
        open_interest=Decimal("100000"),
    )
    
    # Generate historical prices (simulated)
    price_history = []
    base_price = 0.60
    for i in range(48):  # 48 hours of history
        noise = np.random.normal(0, 0.02)
        trend = 0.001 * i  # Slight upward trend
        price = max(0.01, min(0.99, base_price + trend + noise))
        
        price_history.append(PriceSnapshot(
            ts=datetime.utcnow() - timedelta(hours=48-i),
            outcome_id="demo_yes",
            mid_price=Decimal(str(round(price, 4))),
            bid_price=Decimal(str(round(price - 0.01, 4))),
            ask_price=Decimal(str(round(price + 0.01, 4))),
            spread=Decimal("0.02"),
            bid_depth_1pct=Decimal("5000"),
            ask_depth_1pct=Decimal("4000"),
            volume_24h=Decimal(str(np.random.randint(30000, 70000))),
            open_interest=Decimal("100000"),
        ))
    
    # Engineer features
    engineer = FeatureEngineer()
    features = engineer.compute_features(
        market=market,
        outcome=outcome,
        current_price=current_price,
        price_history=price_history,
    )
    
    print("\nEngineered Features:")
    print("-" * 50)
    for name in FeatureSet.feature_names()[:12]:
        value = getattr(features, name)
        if value is not None:
            print(f"  {name:<30}: {value:.4f}")
        else:
            print(f"  {name:<30}: None")


# =============================================================================
# Example 4: Model Training and Evaluation
# =============================================================================

def demo_model_training():
    """Demonstrate model training and calibration evaluation."""
    print("\n" + "="*60)
    print("DEMO 4: Model Training & Evaluation")
    print("="*60)
    
    from src.models.probability import (
        LightGBMModel,
        IsotonicCalibrator,
        EnsembleModel,
        compute_calibration_metrics,
        calibration_curve,
    )
    
    # Generate synthetic training data
    np.random.seed(42)
    n_samples = 1000
    
    # Features
    X = pd.DataFrame({
        "implied_prob": np.random.beta(2, 2, n_samples),  # Market prices
        "spread_bps": np.random.exponential(50, n_samples),
        "depth_imbalance": np.random.normal(0, 0.3, n_samples),
        "liquidity_score": np.random.normal(10, 2, n_samples),
        "time_to_resolution_hours": np.random.exponential(100, n_samples),
        "market_age_days": np.random.exponential(30, n_samples),
        "hour_of_day": np.random.randint(0, 24, n_samples),
        "day_of_week": np.random.randint(0, 7, n_samples),
        "price_momentum_1h": np.random.normal(0, 0.02, n_samples),
        "price_momentum_24h": np.random.normal(0, 0.05, n_samples),
        "price_volatility_24h": np.abs(np.random.normal(0.03, 0.02, n_samples)),
        "volume_zscore": np.random.normal(0, 1, n_samples),
        "category_avg_price": np.random.beta(2, 2, n_samples),
        "overround": np.random.normal(1.02, 0.02, n_samples),
        "buy_sell_ratio_1h": np.random.beta(5, 5, n_samples),
        "large_trade_indicator": np.random.beta(2, 8, n_samples),
    })
    
    # Generate labels (with some signal from features)
    true_prob = X["implied_prob"] + 0.1 * X["depth_imbalance"] + np.random.normal(0, 0.1, n_samples)
    true_prob = np.clip(true_prob, 0.01, 0.99)
    y = (np.random.random(n_samples) < true_prob).astype(float)
    y = pd.Series(y)
    
    # Split data
    split_idx = int(0.8 * n_samples)
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]
    
    print(f"\nTraining data: {len(X_train)} samples")
    print(f"Test data: {len(X_test)} samples")
    
    # Train models
    print("\nTraining models...")
    
    # 1. Isotonic calibrator (on market probabilities)
    isotonic = IsotonicCalibrator()
    isotonic.fit(X_train[["implied_prob"]], y_train)
    
    # 2. LightGBM
    try:
        lgbm = LightGBMModel(n_estimators=50, max_depth=4)
        lgbm.fit(X_train, y_train)
    except ImportError:
        print("  LightGBM not installed, using placeholder")
        lgbm = None
    
    # Evaluate
    print("\nModel Evaluation:")
    print("-" * 60)
    
    # Baseline: raw market prices
    baseline_preds = X_test["implied_prob"].values
    baseline_metrics = compute_calibration_metrics(y_test.values, baseline_preds)
    print(f"\nBaseline (market prices):")
    print(f"  Brier Score: {baseline_metrics.brier_score:.4f}")
    print(f"  Log Loss: {baseline_metrics.log_loss:.4f}")
    print(f"  Calibration Error (ECE): {baseline_metrics.calibration_error:.4f}")
    
    # Isotonic calibrated
    isotonic_preds = isotonic.predict_proba(X_test[["implied_prob"]])
    isotonic_metrics = compute_calibration_metrics(y_test.values, isotonic_preds)
    print(f"\nIsotonic Calibrated:")
    print(f"  Brier Score: {isotonic_metrics.brier_score:.4f}")
    print(f"  Log Loss: {isotonic_metrics.log_loss:.4f}")
    print(f"  Calibration Error (ECE): {isotonic_metrics.calibration_error:.4f}")
    
    if lgbm:
        lgbm_preds = lgbm.predict_proba(X_test)
        lgbm_metrics = compute_calibration_metrics(y_test.values, lgbm_preds)
        print(f"\nLightGBM:")
        print(f"  Brier Score: {lgbm_metrics.brier_score:.4f}")
        print(f"  Log Loss: {lgbm_metrics.log_loss:.4f}")
        print(f"  Calibration Error (ECE): {lgbm_metrics.calibration_error:.4f}")


# =============================================================================
# Example 5: Backtest Simulation
# =============================================================================

def demo_backtest():
    """Demonstrate backtesting framework."""
    print("\n" + "="*60)
    print("DEMO 5: Backtesting")
    print("="*60)
    
    from src.backtest.engine import BacktestEngine, Trade
    from src.models.probability import IsotonicCalibrator
    from src.features.engineering import FeatureSet
    
    # Generate synthetic historical data
    np.random.seed(42)
    n_days = 180
    n_outcomes_per_day = 5
    
    data = []
    for day in range(n_days):
        date = datetime(2024, 1, 1) + timedelta(days=day)
        
        for outcome_idx in range(n_outcomes_per_day):
            outcome_id = f"outcome_{day}_{outcome_idx}"
            
            # Random features
            implied_prob = np.random.beta(2, 2)
            
            # True outcome (slightly correlated with implied prob)
            true_prob = implied_prob + np.random.normal(0, 0.15)
            true_prob = np.clip(true_prob, 0.05, 0.95)
            resolved_yes = np.random.random() < true_prob
            
            data.append({
                "timestamp": date,
                "outcome_id": outcome_id,
                "implied_prob": implied_prob,
                "spread_bps": np.random.exponential(50),
                "depth_imbalance": np.random.normal(0, 0.3),
                "liquidity_score": np.random.normal(10, 2),
                "time_to_resolution_hours": np.random.exponential(100),
                "market_age_days": day,
                "hour_of_day": 12,
                "day_of_week": day % 7,
                "price_momentum_1h": np.random.normal(0, 0.02),
                "price_momentum_24h": np.random.normal(0, 0.05),
                "price_volatility_24h": np.abs(np.random.normal(0.03, 0.02)),
                "volume_zscore": np.random.normal(0, 1),
                "category_avg_price": np.random.beta(2, 2),
                "overround": np.random.normal(1.02, 0.02),
                "buy_sell_ratio_1h": np.random.beta(5, 5),
                "large_trade_indicator": np.random.beta(2, 8),
                "y": 1.0 if resolved_yes else 0.0,
            })
    
    df = pd.DataFrame(data)
    
    print(f"\nSimulated data: {len(df)} rows over {n_days} days")
    print(f"Base rate: {df['y'].mean():.2%}")
    
    # Run backtest
    print("\nRunning walk-forward backtest...")
    
    engine = BacktestEngine(
        initial_capital=10000,
        train_window_days=60,
        test_window_days=7,
        min_train_samples=50,
        min_edge_threshold=0.02,
    )
    
    def model_factory():
        return IsotonicCalibrator()
    
    result = engine.run_walk_forward(
        data=df,
        model_factory=model_factory,
        feature_cols=["implied_prob"],  # Simple: just calibrate market probs
        target_col="y",
        time_col="timestamp",
        outcome_col="outcome_id",
    )
    
    # Display results
    metrics = result.metrics
    
    print("\n" + "-" * 50)
    print("BACKTEST RESULTS")
    print("-" * 50)
    print(f"  Period: {metrics.start_date} to {metrics.end_date}")
    print(f"\n  Return Metrics:")
    print(f"    Total Return: {metrics.total_return:.2%}")
    print(f"    Annualized Return: {metrics.annualized_return:.2%}")
    print(f"    Sharpe Ratio: {metrics.sharpe_ratio:.2f}")
    print(f"    Max Drawdown: {metrics.max_drawdown:.2%}")
    print(f"\n  Trading Metrics:")
    print(f"    Total Trades: {metrics.total_trades}")
    print(f"    Win Rate: {metrics.win_rate:.2%}")
    print(f"    Profit Factor: {metrics.profit_factor:.2f}")
    print(f"    Avg Position Size: ${metrics.avg_position_size:.2f}")


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Run all demos."""
    print("\n" + "="*60)
    print(" POLYMARKET EDGE SYSTEM - DEMONSTRATION")
    print("="*60)
    print("\nThis demo shows the key components of the edge detection system.")
    print("Each example builds on the previous one.\n")
    
    # Run demos
    demo_edge_calculation()
    demo_signal_generation()
    demo_feature_engineering()
    demo_model_training()
    demo_backtest()
    
    print("\n" + "="*60)
    print(" DEMO COMPLETE")
    print("="*60)
    print("\nNext steps:")
    print("  1. Set up real data pipeline with: polyedge fetch-markets")
    print("  2. Analyze specific markets with: polyedge analyze-market <ID>")
    print("  3. Run live scans with: polyedge scan")
    print("\nReminder: This is for research only. Not financial advice.")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
