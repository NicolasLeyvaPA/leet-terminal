"""
Task scheduler for periodic data collection and analysis.

Provides:
- Scheduled market scanning
- Periodic model retraining
- Data collection jobs
- Signal generation pipelines
"""

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta, time
from enum import Enum
from typing import Optional, Callable, Awaitable, Any
from collections import defaultdict
import uuid

import structlog

logger = structlog.get_logger(__name__)


# =============================================================================
# Data Models
# =============================================================================

class JobStatus(Enum):
    """Job execution status."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    SKIPPED = "skipped"


class ScheduleType(Enum):
    """Types of schedules."""
    INTERVAL = "interval"  # Run every N seconds
    CRON = "cron"  # Cron-like schedule
    ONCE = "once"  # Run once at specific time
    ON_DEMAND = "on_demand"  # Manual trigger only


@dataclass
class JobResult:
    """
    Result of a job execution.
    
    Attributes:
        job_id: Unique job identifier
        status: Final status
        started_at: Start time
        completed_at: Completion time
        result: Return value if successful
        error: Error message if failed
        duration_seconds: Execution duration
    """
    job_id: str
    job_name: str
    status: JobStatus
    started_at: datetime
    completed_at: Optional[datetime] = None
    result: Any = None
    error: Optional[str] = None
    
    @property
    def duration_seconds(self) -> Optional[float]:
        if self.completed_at and self.started_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None


@dataclass
class JobConfig:
    """
    Job configuration.
    
    Attributes:
        name: Job name
        schedule_type: Type of schedule
        interval_seconds: Interval for INTERVAL type
        cron_expression: Cron expression for CRON type
        run_at: Specific time for ONCE type
        max_instances: Max concurrent instances
        timeout_seconds: Execution timeout
        retry_count: Number of retries on failure
        retry_delay_seconds: Delay between retries
        enabled: Whether job is active
    """
    name: str
    schedule_type: ScheduleType
    interval_seconds: Optional[float] = None
    cron_expression: Optional[str] = None
    run_at: Optional[datetime] = None
    max_instances: int = 1
    timeout_seconds: Optional[float] = None
    retry_count: int = 0
    retry_delay_seconds: float = 60.0
    enabled: bool = True
    tags: list[str] = field(default_factory=list)


# =============================================================================
# Job Registry
# =============================================================================

JobFunction = Callable[..., Awaitable[Any]]


@dataclass
class RegisteredJob:
    """A registered job with its configuration and function."""
    config: JobConfig
    func: JobFunction
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    run_count: int = 0
    fail_count: int = 0
    running_instances: int = 0


class JobRegistry:
    """
    Registry of scheduled jobs.
    
    Manages job registration, scheduling, and execution history.
    """
    
    def __init__(self):
        self._jobs: dict[str, RegisteredJob] = {}
        self._history: dict[str, list[JobResult]] = defaultdict(list)
        self._max_history = 100
    
    def register(
        self,
        config: JobConfig,
        func: JobFunction,
    ) -> None:
        """
        Register a job.
        
        Args:
            config: Job configuration
            func: Async function to execute
        """
        job = RegisteredJob(
            config=config,
            func=func,
            next_run=self._calculate_next_run(config),
        )
        self._jobs[config.name] = job
        logger.info("job_registered", name=config.name, schedule=config.schedule_type.value)
    
    def unregister(self, name: str) -> bool:
        """Unregister a job."""
        if name in self._jobs:
            del self._jobs[name]
            return True
        return False
    
    def get(self, name: str) -> Optional[RegisteredJob]:
        """Get a registered job."""
        return self._jobs.get(name)
    
    def list_jobs(self) -> list[RegisteredJob]:
        """List all registered jobs."""
        return list(self._jobs.values())
    
    def record_result(self, name: str, result: JobResult) -> None:
        """Record a job execution result."""
        self._history[name].append(result)
        
        # Trim history
        if len(self._history[name]) > self._max_history:
            self._history[name] = self._history[name][-self._max_history:]
        
        # Update job stats
        if name in self._jobs:
            job = self._jobs[name]
            job.last_run = result.completed_at or result.started_at
            job.run_count += 1
            if result.status == JobStatus.FAILED:
                job.fail_count += 1
            job.next_run = self._calculate_next_run(job.config)
    
    def get_history(
        self,
        name: str,
        limit: int = 10,
    ) -> list[JobResult]:
        """Get execution history for a job."""
        return self._history[name][-limit:]
    
    def _calculate_next_run(self, config: JobConfig) -> Optional[datetime]:
        """Calculate next run time for a job."""
        now = datetime.utcnow()
        
        if config.schedule_type == ScheduleType.INTERVAL:
            return now + timedelta(seconds=config.interval_seconds or 60)
        
        elif config.schedule_type == ScheduleType.ONCE:
            return config.run_at
        
        elif config.schedule_type == ScheduleType.CRON:
            return self._parse_cron_next(config.cron_expression, now)
        
        return None
    
    def _parse_cron_next(
        self,
        expression: Optional[str],
        after: datetime,
    ) -> Optional[datetime]:
        """
        Parse cron expression and return next run time.
        
        Simplified cron parsing. For production, use croniter library.
        """
        if not expression:
            return None
        
        # Simplified: just handle basic cases
        parts = expression.split()
        
        if len(parts) != 5:
            return None
        
        minute, hour, day, month, dow = parts
        
        # Handle simple cases
        if minute == "*" and hour == "*":
            # Every minute
            return after + timedelta(minutes=1)
        
        if minute.isdigit() and hour == "*":
            # Every hour at minute X
            next_time = after.replace(minute=int(minute), second=0, microsecond=0)
            if next_time <= after:
                next_time += timedelta(hours=1)
            return next_time
        
        if minute.isdigit() and hour.isdigit():
            # Daily at specific time
            next_time = after.replace(
                hour=int(hour),
                minute=int(minute),
                second=0,
                microsecond=0,
            )
            if next_time <= after:
                next_time += timedelta(days=1)
            return next_time
        
        # Default: next hour
        return after + timedelta(hours=1)


# =============================================================================
# Scheduler
# =============================================================================

class Scheduler:
    """
    Task scheduler for running periodic jobs.
    
    Features:
    - Interval-based scheduling
    - Cron-like scheduling
    - Concurrent job management
    - Retry handling
    - Job execution history
    """
    
    def __init__(
        self,
        registry: Optional[JobRegistry] = None,
        tick_interval: float = 1.0,
    ):
        """
        Initialize scheduler.
        
        Args:
            registry: Job registry (creates new if None)
            tick_interval: Seconds between schedule checks
        """
        self.registry = registry or JobRegistry()
        self.tick_interval = tick_interval
        self._running = False
        self._tasks: dict[str, asyncio.Task] = {}
        self._lock = asyncio.Lock()
    
    def job(
        self,
        name: str,
        schedule_type: ScheduleType = ScheduleType.INTERVAL,
        interval_seconds: Optional[float] = None,
        cron: Optional[str] = None,
        **kwargs,
    ) -> Callable[[JobFunction], JobFunction]:
        """
        Decorator to register a job.
        
        Example:
            @scheduler.job("fetch_markets", interval_seconds=300)
            async def fetch_markets():
                ...
        """
        def decorator(func: JobFunction) -> JobFunction:
            config = JobConfig(
                name=name,
                schedule_type=schedule_type,
                interval_seconds=interval_seconds,
                cron_expression=cron,
                **kwargs,
            )
            self.registry.register(config, func)
            return func
        return decorator
    
    async def start(self) -> None:
        """Start the scheduler."""
        if self._running:
            logger.warning("scheduler_already_running")
            return
        
        self._running = True
        logger.info("scheduler_started")
        
        while self._running:
            await self._tick()
            await asyncio.sleep(self.tick_interval)
    
    async def stop(self, timeout: float = 30.0) -> None:
        """
        Stop the scheduler gracefully.
        
        Args:
            timeout: Max seconds to wait for running jobs
        """
        self._running = False
        
        # Cancel pending tasks
        for name, task in list(self._tasks.items()):
            if not task.done():
                task.cancel()
        
        # Wait for completion
        if self._tasks:
            try:
                await asyncio.wait_for(
                    asyncio.gather(*self._tasks.values(), return_exceptions=True),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                logger.warning("scheduler_stop_timeout")
        
        self._tasks.clear()
        logger.info("scheduler_stopped")
    
    async def run_now(
        self,
        name: str,
        **kwargs,
    ) -> JobResult:
        """
        Run a job immediately.
        
        Args:
            name: Job name
            **kwargs: Arguments to pass to job function
            
        Returns:
            Job execution result
        """
        job = self.registry.get(name)
        if not job:
            raise ValueError(f"Job not found: {name}")
        
        return await self._execute_job(job, **kwargs)
    
    async def _tick(self) -> None:
        """Process one scheduler tick."""
        now = datetime.utcnow()
        
        for job in self.registry.list_jobs():
            if not job.config.enabled:
                continue
            
            # Check if job should run
            if job.next_run and job.next_run <= now:
                # Check max instances
                if job.running_instances >= job.config.max_instances:
                    logger.debug(
                        "job_skipped_max_instances",
                        name=job.config.name,
                        running=job.running_instances,
                    )
                    continue
                
                # Schedule execution
                task = asyncio.create_task(
                    self._execute_job_with_retry(job)
                )
                self._tasks[f"{job.config.name}_{uuid.uuid4().hex[:8]}"] = task
    
    async def _execute_job(
        self,
        job: RegisteredJob,
        **kwargs,
    ) -> JobResult:
        """Execute a single job."""
        job_id = f"{job.config.name}_{uuid.uuid4().hex[:8]}"
        started_at = datetime.utcnow()
        
        logger.info("job_started", name=job.config.name, job_id=job_id)
        
        async with self._lock:
            job.running_instances += 1
        
        try:
            # Apply timeout if configured
            if job.config.timeout_seconds:
                result = await asyncio.wait_for(
                    job.func(**kwargs),
                    timeout=job.config.timeout_seconds,
                )
            else:
                result = await job.func(**kwargs)
            
            completed_at = datetime.utcnow()
            
            job_result = JobResult(
                job_id=job_id,
                job_name=job.config.name,
                status=JobStatus.COMPLETED,
                started_at=started_at,
                completed_at=completed_at,
                result=result,
            )
            
            logger.info(
                "job_completed",
                name=job.config.name,
                job_id=job_id,
                duration=job_result.duration_seconds,
            )
            
        except asyncio.TimeoutError:
            job_result = JobResult(
                job_id=job_id,
                job_name=job.config.name,
                status=JobStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                error="Job timed out",
            )
            logger.error("job_timeout", name=job.config.name, job_id=job_id)
            
        except asyncio.CancelledError:
            job_result = JobResult(
                job_id=job_id,
                job_name=job.config.name,
                status=JobStatus.CANCELLED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
            )
            logger.info("job_cancelled", name=job.config.name, job_id=job_id)
            raise
            
        except Exception as e:
            job_result = JobResult(
                job_id=job_id,
                job_name=job.config.name,
                status=JobStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                error=str(e),
            )
            logger.error("job_failed", name=job.config.name, job_id=job_id, error=str(e))
            
        finally:
            async with self._lock:
                job.running_instances -= 1
            
            self.registry.record_result(job.config.name, job_result)
        
        return job_result
    
    async def _execute_job_with_retry(
        self,
        job: RegisteredJob,
    ) -> JobResult:
        """Execute job with retry logic."""
        last_result = None
        
        for attempt in range(job.config.retry_count + 1):
            result = await self._execute_job(job)
            last_result = result
            
            if result.status == JobStatus.COMPLETED:
                return result
            
            if attempt < job.config.retry_count:
                logger.info(
                    "job_retry_scheduled",
                    name=job.config.name,
                    attempt=attempt + 1,
                    delay=job.config.retry_delay_seconds,
                )
                await asyncio.sleep(job.config.retry_delay_seconds)
        
        return last_result or JobResult(
            job_id="unknown",
            job_name=job.config.name,
            status=JobStatus.FAILED,
            started_at=datetime.utcnow(),
            error="All retries exhausted",
        )
    
    def get_status(self) -> dict[str, Any]:
        """Get scheduler status."""
        jobs_status = []
        
        for job in self.registry.list_jobs():
            jobs_status.append({
                "name": job.config.name,
                "enabled": job.config.enabled,
                "schedule": job.config.schedule_type.value,
                "running_instances": job.running_instances,
                "run_count": job.run_count,
                "fail_count": job.fail_count,
                "last_run": job.last_run.isoformat() if job.last_run else None,
                "next_run": job.next_run.isoformat() if job.next_run else None,
            })
        
        return {
            "running": self._running,
            "active_tasks": len([t for t in self._tasks.values() if not t.done()]),
            "jobs": jobs_status,
        }


# =============================================================================
# Pre-built Jobs
# =============================================================================

def create_market_scanner_job(
    scheduler: Scheduler,
    client,
    signal_generator,
    alert_manager,
    interval_seconds: float = 300,
):
    """
    Create a market scanning job.
    
    Scans all active markets for trading opportunities.
    """
    @scheduler.job(
        "market_scanner",
        schedule_type=ScheduleType.INTERVAL,
        interval_seconds=interval_seconds,
        timeout_seconds=120,
        retry_count=1,
    )
    async def scan_markets():
        logger.info("market_scan_started")
        
        markets = await client.get_markets(limit=100)
        signals_found = 0
        
        for market in markets:
            try:
                outcomes = await client.get_market_outcomes(market.market_id)
                
                for outcome in outcomes:
                    price = await client.get_price(outcome.token_id)
                    
                    # Generate signal
                    signal = signal_generator.generate_signal(
                        outcome_id=outcome.outcome_id,
                        model_prob=float(price.mid_price),  # Placeholder
                        market_prob=float(price.mid_price),
                    )
                    
                    if signal.is_actionable:
                        signals_found += 1
                        
                        # Send alert
                        if alert_manager:
                            await alert_manager.send_alert(
                                alert_type="signal",
                                priority="medium",
                                title=f"Signal: {market.question[:50]}",
                                message=f"Edge: {signal.edge:.2%}, Direction: {signal.direction}",
                            )
                            
            except Exception as e:
                logger.warning("market_scan_error", market=market.market_id, error=str(e))
        
        logger.info("market_scan_completed", markets=len(markets), signals=signals_found)
        return {"markets_scanned": len(markets), "signals_found": signals_found}


def create_data_collection_job(
    scheduler: Scheduler,
    client,
    database,
    interval_seconds: float = 60,
):
    """
    Create a data collection job.
    
    Collects price snapshots for all active markets.
    """
    @scheduler.job(
        "data_collector",
        schedule_type=ScheduleType.INTERVAL,
        interval_seconds=interval_seconds,
        timeout_seconds=60,
        retry_count=2,
    )
    async def collect_data():
        logger.info("data_collection_started")
        
        markets = await client.get_markets(limit=50)
        snapshots_collected = 0
        
        async with database.get_session() as session:
            for market in markets:
                try:
                    outcomes = await client.get_market_outcomes(market.market_id)
                    
                    for outcome in outcomes:
                        price = await client.get_price(outcome.token_id)
                        
                        # Save snapshot to database
                        # (Implementation depends on ORM setup)
                        snapshots_collected += 1
                        
                except Exception as e:
                    logger.warning("snapshot_error", market=market.market_id, error=str(e))
            
            await session.commit()
        
        logger.info("data_collection_completed", snapshots=snapshots_collected)
        return {"snapshots_collected": snapshots_collected}


def create_model_training_job(
    scheduler: Scheduler,
    database,
    model_registry,
    cron: str = "0 3 * * *",  # Daily at 3 AM
):
    """
    Create a model retraining job.
    
    Retrains prediction models daily with latest data.
    """
    @scheduler.job(
        "model_trainer",
        schedule_type=ScheduleType.CRON,
        cron=cron,
        timeout_seconds=3600,  # 1 hour
        retry_count=1,
    )
    async def train_models():
        logger.info("model_training_started")
        
        # Load training data from database
        # Train models
        # Save to model registry
        
        logger.info("model_training_completed")
        return {"status": "completed"}


def create_health_check_job(
    scheduler: Scheduler,
    health_monitor,
    interval_seconds: float = 60,
):
    """
    Create a health check job.
    
    Runs all registered health checks periodically.
    """
    @scheduler.job(
        "health_checker",
        schedule_type=ScheduleType.INTERVAL,
        interval_seconds=interval_seconds,
        timeout_seconds=30,
    )
    async def check_health():
        results = await health_monitor.check_all()
        
        unhealthy = [
            name for name, status in results.items()
            if status.status == "unhealthy"
        ]
        
        if unhealthy:
            logger.warning("unhealthy_components", components=unhealthy)
        
        return {"checked": len(results), "unhealthy": len(unhealthy)}


# =============================================================================
# Pipeline Orchestration
# =============================================================================

class Pipeline:
    """
    Orchestrates a sequence of jobs as a pipeline.
    
    Jobs are executed in order, with optional parallel stages.
    """
    
    def __init__(self, name: str):
        """
        Initialize pipeline.
        
        Args:
            name: Pipeline name
        """
        self.name = name
        self._stages: list[list[tuple[str, JobFunction, dict]]] = []
    
    def add_stage(
        self,
        *jobs: tuple[str, JobFunction],
        parallel: bool = False,
    ) -> "Pipeline":
        """
        Add a stage to the pipeline.
        
        Args:
            *jobs: Tuples of (name, function) to execute
            parallel: Run jobs in this stage in parallel
            
        Returns:
            Self for chaining
        """
        stage = [(name, func, {}) for name, func in jobs]
        self._stages.append(stage)
        return self
    
    async def run(
        self,
        context: Optional[dict] = None,
    ) -> dict[str, JobResult]:
        """
        Execute the pipeline.
        
        Args:
            context: Shared context passed to all jobs
            
        Returns:
            Dictionary of job results
        """
        results: dict[str, JobResult] = {}
        ctx = context or {}
        
        logger.info("pipeline_started", name=self.name, stages=len(self._stages))
        pipeline_start = datetime.utcnow()
        
        for i, stage in enumerate(self._stages):
            logger.info("pipeline_stage_started", name=self.name, stage=i)
            
            tasks = []
            job_names = []
            
            for name, func, kwargs in stage:
                job_names.append(name)
                tasks.append(self._execute_stage_job(name, func, ctx, kwargs))
            
            stage_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Process results
            for name, result in zip(job_names, stage_results):
                if isinstance(result, Exception):
                    results[name] = JobResult(
                        job_id=f"{name}_{uuid.uuid4().hex[:8]}",
                        job_name=name,
                        status=JobStatus.FAILED,
                        started_at=datetime.utcnow(),
                        completed_at=datetime.utcnow(),
                        error=str(result),
                    )
                else:
                    results[name] = result
                    
                    # Pass result to context for next stage
                    if result.status == JobStatus.COMPLETED:
                        ctx[name] = result.result
            
            # Check for failures
            failed = [
                name for name, result in results.items()
                if result.status == JobStatus.FAILED
            ]
            
            if failed:
                logger.error("pipeline_stage_failed", name=self.name, stage=i, failed=failed)
                break
        
        duration = (datetime.utcnow() - pipeline_start).total_seconds()
        logger.info(
            "pipeline_completed",
            name=self.name,
            duration=duration,
            jobs=len(results),
            failed=len([r for r in results.values() if r.status == JobStatus.FAILED]),
        )
        
        return results
    
    async def _execute_stage_job(
        self,
        name: str,
        func: JobFunction,
        context: dict,
        kwargs: dict,
    ) -> JobResult:
        """Execute a single job in a pipeline stage."""
        job_id = f"{name}_{uuid.uuid4().hex[:8]}"
        started_at = datetime.utcnow()
        
        try:
            # Inject context
            result = await func(context=context, **kwargs)
            
            return JobResult(
                job_id=job_id,
                job_name=name,
                status=JobStatus.COMPLETED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                result=result,
            )
        except Exception as e:
            return JobResult(
                job_id=job_id,
                job_name=name,
                status=JobStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                error=str(e),
            )


if __name__ == "__main__":
    async def demo():
        print("Scheduler Demo")
        print("=" * 50)
        
        # Create scheduler
        scheduler = Scheduler()
        
        # Register some jobs
        @scheduler.job("hello", interval_seconds=5)
        async def hello_job():
            print(f"  Hello at {datetime.utcnow()}")
            return {"message": "hello"}
        
        @scheduler.job("counter", interval_seconds=3)
        async def counter_job():
            counter_job.count = getattr(counter_job, "count", 0) + 1
            print(f"  Count: {counter_job.count}")
            return {"count": counter_job.count}
        
        @scheduler.job("slow", interval_seconds=10, timeout_seconds=2)
        async def slow_job():
            await asyncio.sleep(5)  # Will timeout
            return {"status": "done"}
        
        print("\nRegistered jobs:")
        for job in scheduler.registry.list_jobs():
            print(f"  - {job.config.name}: every {job.config.interval_seconds}s")
        
        print("\nRunning scheduler for 15 seconds...")
        
        # Run scheduler in background
        scheduler_task = asyncio.create_task(scheduler.start())
        
        await asyncio.sleep(15)
        
        await scheduler.stop()
        
        print("\nFinal status:")
        status = scheduler.get_status()
        for job in status["jobs"]:
            print(f"  {job['name']}: runs={job['run_count']}, fails={job['fail_count']}")
        
        # Pipeline demo
        print("\n" + "=" * 50)
        print("Pipeline Demo")
        
        async def step1(context, **kwargs):
            print("  Step 1: Loading data")
            return {"data": [1, 2, 3, 4, 5]}
        
        async def step2(context, **kwargs):
            data = context.get("step1", {}).get("data", [])
            print(f"  Step 2: Processing {len(data)} items")
            return {"processed": sum(data)}
        
        async def step3(context, **kwargs):
            total = context.get("step2", {}).get("processed", 0)
            print(f"  Step 3: Final result = {total}")
            return {"result": total}
        
        pipeline = Pipeline("demo_pipeline")
        pipeline.add_stage(("step1", step1))
        pipeline.add_stage(("step2", step2))
        pipeline.add_stage(("step3", step3))
        
        results = await pipeline.run()
        
        print("\nPipeline results:")
        for name, result in results.items():
            print(f"  {name}: {result.status.value} - {result.result}")
        
        print("\nDemo complete!")
    
    asyncio.run(demo())
