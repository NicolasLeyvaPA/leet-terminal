"""
Main application entry point for Polymarket Edge.

Provides:
- Application lifecycle management
- Component initialization
- Graceful shutdown handling
- Configuration loading
"""

import asyncio
import signal
import sys
from typing import Optional

import structlog

from config.settings import settings

# Configure logging
import logging
logging.basicConfig(format="%(message)s", level=logging.INFO)

structlog.configure(
    processors=[
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer(),
    ],
    context_class=dict,
    logger_factory=structlog.PrintLoggerFactory(),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger(__name__)


class Application:
    """
    Main application controller.
    
    Manages initialization, running, and shutdown of all components.
    """
    
    def __init__(self):
        """Initialize application state."""
        self._running = False
        self._shutdown_event = asyncio.Event()
        
        # Components (initialized lazily)
        self._client = None
        self._database = None
        self._scheduler = None
        self._health_monitor = None
        self._alert_manager = None
        self._metrics = None
        self._streaming = None
    
    async def initialize(self) -> None:
        """Initialize all application components."""
        logger.info("application_initializing")
        
        # Initialize database
        logger.info("initializing_database")
        from src.data.database import Database
        self._database = Database()
        await self._database.create_tables()
        
        # Initialize API client
        logger.info("initializing_api_client")
        from src.data.client import PolymarketClient
        self._client = PolymarketClient()
        
        # Initialize alert manager
        logger.info("initializing_alerts")
        from src.monitoring.alerts import AlertManager
        self._alert_manager = AlertManager()
        
        # Add notification channels from config
        if settings.slack_webhook_url:
            from src.monitoring.alerts import SlackChannel
            self._alert_manager.add_channel(
                SlackChannel(settings.slack_webhook_url)
            )
        
        # Initialize metrics collector
        from src.monitoring.alerts import MetricsCollector
        self._metrics = MetricsCollector()
        
        # Initialize health monitor
        logger.info("initializing_health_monitor")
        from src.monitoring.alerts import HealthMonitor
        self._health_monitor = HealthMonitor(self._alert_manager)
        
        # Register health checks
        from src.monitoring.alerts import check_api_health, check_database_health
        self._health_monitor.register_check(
            "api",
            lambda: check_api_health(self._client)
        )
        self._health_monitor.register_check(
            "database", 
            lambda: check_database_health(self._database)
        )
        
        # Initialize scheduler
        logger.info("initializing_scheduler")
        from src.scheduler.jobs import Scheduler
        self._scheduler = Scheduler()
        
        # Register scheduled jobs
        self._register_jobs()
        
        logger.info("application_initialized")
    
    def _register_jobs(self) -> None:
        """Register scheduled jobs."""
        from src.signals.edge import SignalGenerator
        
        signal_generator = SignalGenerator()
        
        # Market scanner - runs every 5 minutes
        @self._scheduler.job(
            "market_scanner",
            interval_seconds=300,
            timeout_seconds=120,
        )
        async def scan_markets():
            logger.info("market_scan_started")
            
            async with self._client as client:
                markets = await client.get_markets(limit=50)
                signals = 0
                
                for market in markets:
                    try:
                        outcomes = await client.get_market_outcomes(market.market_id)
                        
                        for outcome in outcomes:
                            price = await client.get_price(outcome.token_id)
                            market_prob = float(price.mid_price)
                            
                            # Generate signal (placeholder model probability)
                            signal = signal_generator.generate_signal(
                                outcome_id=outcome.outcome_id,
                                model_prob=market_prob,
                                market_prob=market_prob,
                            )
                            
                            if signal.is_actionable:
                                signals += 1
                                self._metrics.record_signal(True, signal.edge)
                            else:
                                self._metrics.record_signal(False, signal.edge)
                                
                    except Exception as e:
                        logger.warning("scan_error", market=market.market_id, error=str(e))
                
                logger.info("market_scan_completed", markets=len(markets), signals=signals)
                return {"markets": len(markets), "signals": signals}
        
        # Data collector - runs every minute
        @self._scheduler.job(
            "data_collector",
            interval_seconds=60,
            timeout_seconds=45,
        )
        async def collect_data():
            logger.info("data_collection_started")
            count = 0
            
            async with self._client as client:
                markets = await client.get_markets(limit=20)
                
                async with self._database.get_session() as session:
                    for market in markets:
                        try:
                            outcomes = await client.get_market_outcomes(market.market_id)
                            for outcome in outcomes:
                                await client.get_price(outcome.token_id)
                                count += 1
                        except Exception:
                            pass
                    
                    # Would save to database here
            
            logger.info("data_collection_completed", snapshots=count)
            return {"snapshots": count}
        
        # Health check - runs every 30 seconds
        @self._scheduler.job(
            "health_check",
            interval_seconds=30,
            timeout_seconds=15,
        )
        async def run_health_checks():
            results = await self._health_monitor.check_all()
            unhealthy = [n for n, s in results.items() if not s.is_healthy]
            
            if unhealthy:
                logger.warning("unhealthy_components", components=unhealthy)
            
            return {"checked": len(results), "unhealthy": len(unhealthy)}
    
    async def run(self) -> None:
        """Run the application."""
        self._running = True
        logger.info("application_starting")
        
        try:
            # Start scheduler
            scheduler_task = asyncio.create_task(
                self._scheduler.start(),
                name="scheduler"
            )
            
            # Wait for shutdown signal
            await self._shutdown_event.wait()
            
            # Graceful shutdown
            logger.info("application_shutting_down")
            
            await self._scheduler.stop()
            scheduler_task.cancel()
            
            try:
                await scheduler_task
            except asyncio.CancelledError:
                pass
            
        except Exception as e:
            logger.error("application_error", error=str(e))
            raise
        finally:
            await self.cleanup()
    
    async def cleanup(self) -> None:
        """Clean up resources."""
        logger.info("application_cleanup")
        
        if self._database:
            await self._database.close()
        
        if self._client:
            await self._client.__aexit__(None, None, None)
        
        logger.info("application_stopped")
    
    def shutdown(self) -> None:
        """Signal shutdown."""
        logger.info("shutdown_requested")
        self._shutdown_event.set()
    
    # Properties for accessing components
    
    @property
    def client(self):
        """Get API client."""
        return self._client
    
    @property
    def database(self):
        """Get database."""
        return self._database
    
    @property
    def scheduler(self):
        """Get scheduler."""
        return self._scheduler
    
    @property
    def alert_manager(self):
        """Get alert manager."""
        return self._alert_manager
    
    @property
    def metrics(self):
        """Get metrics collector."""
        return self._metrics
    
    @property
    def health_monitor(self):
        """Get health monitor."""
        return self._health_monitor


# Global application instance
app: Optional[Application] = None


def get_app() -> Application:
    """Get the application instance."""
    global app
    if app is None:
        app = Application()
    return app


async def main() -> None:
    """Main entry point."""
    global app
    app = Application()
    
    # Setup signal handlers
    loop = asyncio.get_running_loop()
    
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, app.shutdown)
    
    try:
        await app.initialize()
        await app.run()
    except KeyboardInterrupt:
        logger.info("keyboard_interrupt")
    except Exception as e:
        logger.exception("fatal_error", error=str(e))
        sys.exit(1)


def run_app() -> None:
    """Run the application (blocking)."""
    asyncio.run(main())


# =============================================================================
# Quick Start Functions
# =============================================================================

async def quick_scan(limit: int = 20) -> list[dict]:
    """
    Quick market scan without full application startup.
    
    Args:
        limit: Number of markets to scan
        
    Returns:
        List of opportunities found
    """
    from src.data.client import PolymarketClient
    from src.signals.edge import SignalGenerator
    
    generator = SignalGenerator()
    opportunities = []
    
    async with PolymarketClient() as client:
        markets = await client.get_markets(limit=limit)
        
        for market in markets:
            try:
                outcomes = await client.get_market_outcomes(market.market_id)
                
                for outcome in outcomes:
                    price = await client.get_price(outcome.token_id)
                    market_prob = float(price.mid_price)
                    
                    signal = generator.generate_signal(
                        outcome_id=outcome.outcome_id,
                        model_prob=market_prob,
                        market_prob=market_prob,
                    )
                    
                    if signal.is_actionable:
                        opportunities.append({
                            "market": market.question[:60],
                            "outcome": outcome.outcome_name,
                            "market_prob": f"{market_prob:.1%}",
                            "edge": f"{signal.edge:.2%}",
                            "kelly": f"{signal.kelly_fraction:.2%}",
                            "direction": signal.direction,
                            "strength": signal.signal_strength.value,
                        })
            except Exception as e:
                logger.warning("scan_error", market=market.market_id, error=str(e))
    
    return opportunities


async def quick_analyze(market_id: str) -> dict:
    """
    Quick analysis of a specific market.
    
    Args:
        market_id: Market ID to analyze
        
    Returns:
        Analysis results
    """
    from src.data.client import PolymarketClient
    from src.features.engineering import FeatureEngineer
    from src.signals.edge import SignalGenerator
    
    engineer = FeatureEngineer()
    generator = SignalGenerator()
    
    result = {
        "market_id": market_id,
        "outcomes": [],
    }
    
    async with PolymarketClient() as client:
        market = await client.get_market(market_id)
        result["question"] = market.question
        result["category"] = market.category
        result["end_date"] = market.end_date.isoformat()
        
        outcomes = await client.get_market_outcomes(market_id)
        
        for outcome in outcomes:
            try:
                price = await client.get_price(outcome.token_id)
                order_book = await client.get_order_book(outcome.token_id)
                
                # Compute features
                features = engineer.compute_features(
                    market=market,
                    outcome=outcome,
                    price=price,
                    order_book=order_book,
                )
                
                # Generate signal
                signal = generator.generate_signal(
                    outcome_id=outcome.outcome_id,
                    model_prob=float(price.mid_price),
                    market_prob=float(price.mid_price),
                )
                
                result["outcomes"].append({
                    "name": outcome.outcome_name,
                    "price": f"{float(price.mid_price):.2%}",
                    "spread_bps": f"{price.spread_bps:.1f}",
                    "features": features.to_dict(),
                    "signal": {
                        "edge": f"{signal.edge:.2%}",
                        "kelly": f"{signal.kelly_fraction:.2%}",
                        "strength": signal.signal_strength.value,
                        "direction": signal.direction,
                    }
                })
                
            except Exception as e:
                result["outcomes"].append({
                    "name": outcome.outcome_name,
                    "error": str(e),
                })
    
    return result


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Polymarket Edge System")
    parser.add_argument(
        "command",
        choices=["run", "scan", "analyze"],
        help="Command to execute",
    )
    parser.add_argument(
        "--market-id",
        help="Market ID for analyze command",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=20,
        help="Limit for scan command",
    )
    
    args = parser.parse_args()
    
    if args.command == "run":
        run_app()
        
    elif args.command == "scan":
        async def do_scan():
            print("Scanning markets...")
            opportunities = await quick_scan(args.limit)
            
            if opportunities:
                print(f"\nFound {len(opportunities)} opportunities:\n")
                for opp in opportunities:
                    print(f"  {opp['market']}")
                    print(f"    {opp['outcome']}: {opp['direction']} ({opp['strength']})")
                    print(f"    Edge: {opp['edge']}, Kelly: {opp['kelly']}")
                    print()
            else:
                print("No opportunities found.")
        
        asyncio.run(do_scan())
        
    elif args.command == "analyze":
        if not args.market_id:
            print("Error: --market-id required for analyze command")
            sys.exit(1)
        
        async def do_analyze():
            print(f"Analyzing market {args.market_id}...")
            result = await quick_analyze(args.market_id)
            
            print(f"\n{result['question']}")
            print(f"Category: {result['category']}")
            print(f"End Date: {result['end_date']}")
            print()
            
            for outcome in result["outcomes"]:
                if "error" in outcome:
                    print(f"  {outcome['name']}: Error - {outcome['error']}")
                else:
                    print(f"  {outcome['name']}: {outcome['price']}")
                    print(f"    Spread: {outcome['spread_bps']} bps")
                    print(f"    Signal: {outcome['signal']['direction']} ({outcome['signal']['strength']})")
                    print(f"    Edge: {outcome['signal']['edge']}, Kelly: {outcome['signal']['kelly']}")
                    print()
        
        asyncio.run(do_analyze())
