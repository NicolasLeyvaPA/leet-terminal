"""
Edge detection and signal generation for trading decisions.

Computes expected value, Kelly fractions, and confluence scores
to identify potentially profitable trading opportunities.
"""

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional

import numpy as np
import structlog

from src.data.models import Signal, SignalStrength

logger = structlog.get_logger(__name__)


# =============================================================================
# Configuration
# =============================================================================

@dataclass
class EdgeConfig:
    """Configuration for edge calculations."""
    
    # Fees
    trading_fee_pct: float = 0.02  # 2% fee
    
    # Edge thresholds
    min_edge_strong: float = 0.05
    min_edge_moderate: float = 0.03
    min_edge_weak: float = 0.02
    
    # Kelly settings
    kelly_fraction: float = 0.25  # Use 25% Kelly (conservative)
    max_kelly: float = 0.20  # Cap Kelly at 20%
    
    # Confluence weights
    model_edge_weight: float = 0.35
    model_agreement_weight: float = 0.25
    news_sentiment_weight: float = 0.15
    volume_confirmation_weight: float = 0.15
    smart_money_weight: float = 0.10
    
    # Confluence thresholds
    min_confluence_strong: float = 0.70
    min_confluence_moderate: float = 0.50
    min_confluence_weak: float = 0.30


# =============================================================================
# Edge Calculations
# =============================================================================

def calculate_edge(
    model_prob: float,
    market_prob: float,
    fees: float = 0.02,
) -> tuple[float, Optional[str]]:
    """
    Calculate expected edge from probability difference.
    
    Edge = model_prob - market_prob - fees (for YES)
    
    Args:
        model_prob: Model's estimated probability
        market_prob: Current market price (implied probability)
        fees: Trading fees as decimal
        
    Returns:
        Tuple of (edge, direction) where direction is "YES", "NO", or None
    """
    # Edge for buying YES
    edge_yes = model_prob - market_prob - fees
    
    # Edge for buying NO (equivalent to selling YES)
    edge_no = (1 - model_prob) - (1 - market_prob) - fees
    
    if edge_yes > edge_no and edge_yes > 0:
        return edge_yes, "YES"
    elif edge_no > edge_yes and edge_no > 0:
        return edge_no, "NO"
    else:
        return max(edge_yes, edge_no), None


def calculate_kelly_fraction(
    model_prob: float,
    market_prob: float,
    fees: float = 0.02,
) -> float:
    """
    Calculate optimal Kelly bet size as fraction of bankroll.
    
    Kelly formula: f* = (p × b - q) / b
    where:
        p = probability of winning
        q = probability of losing (1 - p)
        b = odds (net payout per unit bet)
    
    Args:
        model_prob: Model's estimated win probability
        market_prob: Current market price
        fees: Trading fees
        
    Returns:
        Kelly fraction (0 to 1), or 0 if no edge
    """
    edge, direction = calculate_edge(model_prob, market_prob, fees)
    
    if edge <= 0 or direction is None:
        return 0.0
    
    # Calculate for the direction with edge
    if direction == "YES":
        win_prob = model_prob
        # Net odds: if we pay market_prob, we get 1 - fees if we win
        # Profit = (1 - fees) - market_prob = (1 - market_prob - fees)
        # Odds = profit / stake = (1 - market_prob - fees) / market_prob
        odds = (1 - market_prob - fees) / market_prob
    else:
        win_prob = 1 - model_prob
        odds = (market_prob - fees) / (1 - market_prob)
    
    if odds <= 0:
        return 0.0
    
    lose_prob = 1 - win_prob
    
    # Kelly formula
    kelly = (win_prob * odds - lose_prob) / odds
    
    return max(0.0, kelly)


def fractional_kelly(
    kelly: float,
    fraction: float = 0.25,
    max_kelly: float = 0.20,
) -> float:
    """
    Apply fractional Kelly and cap.
    
    Using full Kelly is too aggressive for most applications.
    Fractional Kelly (typically 25%) reduces variance significantly.
    
    Args:
        kelly: Full Kelly fraction
        fraction: Fraction of Kelly to use
        max_kelly: Maximum allowed bet size
        
    Returns:
        Conservative Kelly fraction
    """
    return min(kelly * fraction, max_kelly)


# =============================================================================
# Confluence Scoring
# =============================================================================

@dataclass
class ConfluenceSignals:
    """Container for signals used in confluence calculation."""
    
    # Primary signal: model edge
    model_edge: float  # Normalized edge (0-1 scale)
    
    # Model agreement (if using ensemble)
    model_agreement: float = 0.5  # 0-1, higher = more agreement
    
    # External signals
    news_sentiment_aligned: float = 0.5  # 0-1, 1 = news supports direction
    volume_confirmation: float = 0.5  # 0-1, 1 = volume supports direction
    smart_money_signal: float = 0.5  # 0-1, 1 = large traders support direction
    
    # Optional additional signals
    poll_alignment: Optional[float] = None
    social_sentiment: Optional[float] = None


def calculate_confluence(
    signals: ConfluenceSignals,
    config: EdgeConfig = None,
) -> float:
    """
    Calculate confluence score from multiple signal sources.
    
    Confluence measures how many independent signals agree on a direction.
    Higher confluence = higher confidence in the signal.
    
    Args:
        signals: ConfluenceSignals object with individual signals
        config: EdgeConfig with weights
        
    Returns:
        Confluence score (0 to 1)
    """
    if config is None:
        config = EdgeConfig()
    
    # Normalize model edge to 0-1 scale
    # Assume edge of 0.10+ is "full" signal
    normalized_edge = min(signals.model_edge / 0.10, 1.0) if signals.model_edge > 0 else 0
    
    # Weighted sum
    confluence = (
        normalized_edge * config.model_edge_weight +
        signals.model_agreement * config.model_agreement_weight +
        signals.news_sentiment_aligned * config.news_sentiment_weight +
        signals.volume_confirmation * config.volume_confirmation_weight +
        signals.smart_money_signal * config.smart_money_weight
    )
    
    return min(confluence, 1.0)


def classify_signal_strength(
    edge: float,
    confluence: float,
    kelly: float,
    config: EdgeConfig = None,
) -> SignalStrength:
    """
    Classify signal into strength categories.
    
    Args:
        edge: Expected edge
        confluence: Confluence score
        kelly: Kelly fraction
        config: EdgeConfig with thresholds
        
    Returns:
        SignalStrength enum value
    """
    if config is None:
        config = EdgeConfig()
    
    # Check STRONG conditions
    if (edge >= config.min_edge_strong and
        confluence >= config.min_confluence_strong and
        kelly >= 0.02):
        return SignalStrength.STRONG
    
    # Check MODERATE conditions
    if (edge >= config.min_edge_moderate and
        confluence >= config.min_confluence_moderate and
        kelly >= 0.01):
        return SignalStrength.MODERATE
    
    # Check WEAK conditions
    if (edge >= config.min_edge_weak and
        confluence >= config.min_confluence_weak and
        kelly >= 0.005):
        return SignalStrength.WEAK
    
    return SignalStrength.NONE


# =============================================================================
# Signal Generation
# =============================================================================

class SignalGenerator:
    """
    Generates trading signals from model predictions and market data.
    
    Usage:
        generator = SignalGenerator()
        signal = generator.generate_signal(
            outcome_id="abc123",
            model_prob=0.65,
            market_prob=0.55,
            model_agreement=0.8,
        )
    """
    
    def __init__(self, config: EdgeConfig = None):
        self.config = config or EdgeConfig()
    
    def generate_signal(
        self,
        outcome_id: str,
        model_prob: float,
        market_prob: float,
        model_agreement: float = 0.5,
        confidence_lower: Optional[float] = None,
        confidence_upper: Optional[float] = None,
        news_sentiment: float = 0.5,
        volume_signal: float = 0.5,
        smart_money_signal: float = 0.5,
        metadata: Optional[dict] = None,
    ) -> Signal:
        """
        Generate a trading signal.
        
        Args:
            outcome_id: ID of the outcome/token
            model_prob: Model's probability estimate
            market_prob: Current market price
            model_agreement: Agreement between ensemble models (0-1)
            confidence_lower: Lower bound of confidence interval
            confidence_upper: Upper bound of confidence interval
            news_sentiment: News sentiment alignment (0-1)
            volume_signal: Volume confirmation signal (0-1)
            smart_money_signal: Large trader flow signal (0-1)
            metadata: Additional metadata to store
            
        Returns:
            Signal object with edge and recommendations
        """
        # Calculate edge
        edge, direction = calculate_edge(
            model_prob,
            market_prob,
            self.config.trading_fee_pct,
        )
        
        # Calculate Kelly
        full_kelly = calculate_kelly_fraction(
            model_prob,
            market_prob,
            self.config.trading_fee_pct,
        )
        kelly = fractional_kelly(
            full_kelly,
            self.config.kelly_fraction,
            self.config.max_kelly,
        )
        
        # Calculate confluence
        confluence_signals = ConfluenceSignals(
            model_edge=max(edge, 0),
            model_agreement=model_agreement,
            news_sentiment_aligned=news_sentiment,
            volume_confirmation=volume_signal,
            smart_money_signal=smart_money_signal,
        )
        confluence = calculate_confluence(confluence_signals, self.config)
        
        # Classify signal strength
        strength = classify_signal_strength(
            edge, confluence, kelly, self.config
        )
        
        # Build metadata
        signal_metadata = {
            "full_kelly": full_kelly,
            "model_agreement": model_agreement,
            "confidence_lower": confidence_lower,
            "confidence_upper": confidence_upper,
            "confluence_breakdown": {
                "model_edge_contrib": max(edge, 0) / 0.10 * self.config.model_edge_weight,
                "agreement_contrib": model_agreement * self.config.model_agreement_weight,
                "news_contrib": news_sentiment * self.config.news_sentiment_weight,
                "volume_contrib": volume_signal * self.config.volume_confirmation_weight,
                "smart_money_contrib": smart_money_signal * self.config.smart_money_weight,
            },
        }
        if metadata:
            signal_metadata.update(metadata)
        
        return Signal(
            outcome_id=outcome_id,
            ts=datetime.utcnow(),
            market_prob=Decimal(str(market_prob)),
            model_prob=Decimal(str(model_prob)),
            edge=Decimal(str(edge)),
            kelly_fraction=Decimal(str(kelly)),
            confluence_score=Decimal(str(confluence)),
            signal_strength=strength,
            direction=direction,
            metadata=signal_metadata,
        )


# =============================================================================
# Portfolio-Level Analysis
# =============================================================================

@dataclass
class PortfolioSignalSummary:
    """Summary of signals across a portfolio."""
    
    total_signals: int
    strong_signals: int
    moderate_signals: int
    weak_signals: int
    
    total_edge: float  # Sum of positive edges
    avg_confluence: float
    
    recommended_positions: list[dict]  # Top signals with position sizes


def analyze_signals(
    signals: list[Signal],
    bankroll: float = 10000.0,
    max_positions: int = 10,
    max_category_exposure: float = 0.20,
) -> PortfolioSignalSummary:
    """
    Analyze signals and generate portfolio recommendations.
    
    Args:
        signals: List of Signal objects
        bankroll: Total capital available
        max_positions: Maximum number of positions
        max_category_exposure: Maximum exposure per category
        
    Returns:
        PortfolioSignalSummary with recommendations
    """
    # Count by strength
    strong = sum(1 for s in signals if s.signal_strength == SignalStrength.STRONG)
    moderate = sum(1 for s in signals if s.signal_strength == SignalStrength.MODERATE)
    weak = sum(1 for s in signals if s.signal_strength == SignalStrength.WEAK)
    
    # Calculate totals
    actionable = [s for s in signals if s.is_actionable]
    total_edge = sum(float(s.edge) for s in actionable)
    avg_confluence = (
        sum(float(s.confluence_score) for s in actionable) / len(actionable)
        if actionable else 0
    )
    
    # Rank and select top signals
    ranked = sorted(
        actionable,
        key=lambda s: (
            s.signal_strength.value,  # Prioritize strength
            float(s.edge),  # Then edge
            float(s.confluence_score),  # Then confluence
        ),
        reverse=True,
    )[:max_positions]
    
    # Calculate position sizes
    recommended = []
    for signal in ranked:
        position_size = bankroll * float(signal.kelly_fraction)
        recommended.append({
            "outcome_id": signal.outcome_id,
            "direction": signal.direction,
            "edge": float(signal.edge),
            "kelly": float(signal.kelly_fraction),
            "confluence": float(signal.confluence_score),
            "strength": signal.signal_strength.value,
            "position_size": round(position_size, 2),
            "market_prob": float(signal.market_prob),
            "model_prob": float(signal.model_prob),
        })
    
    return PortfolioSignalSummary(
        total_signals=len(signals),
        strong_signals=strong,
        moderate_signals=moderate,
        weak_signals=weak,
        total_edge=total_edge,
        avg_confluence=avg_confluence,
        recommended_positions=recommended,
    )
