"""
REST API Layer for Polymarket Edge Detection System.

Provides HTTP endpoints for:
- Market data and signals
- Portfolio management
- Model predictions
- System health and metrics
"""

import asyncio
from datetime import datetime, timedelta
from typing import Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Query, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from ..data.models import Market, Outcome, Signal, SignalStrength
from ..data.database import Database, MarketRepository, SignalRepository
from ..data.client import PolymarketClient
from ..features.engineering import FeatureEngineer
from ..models.probability import EnsembleModel
from ..signals.edge import EdgeDetector
from ..monitoring.alerts import AlertManager, MetricsCollector, HealthMonitor


# =============================================================================
# Request/Response Models
# =============================================================================

class MarketResponse(BaseModel):
    """API response for market data."""
    market_id: str
    question: str
    category: str
    status: str
    end_date: Optional[datetime]
    outcomes: list[dict]
    
class SignalResponse(BaseModel):
    """API response for trading signals."""
    signal_id: str
    market_id: str
    outcome_name: str
    market_price: float
    model_probability: float
    edge: float
    kelly_fraction: float
    confluence_score: float
    signal_strength: str
    is_actionable: bool
    created_at: datetime
    reasoning: Optional[str] = None

class AnalysisRequest(BaseModel):
    """Request for market analysis."""
    market_id: str
    include_features: bool = False
    include_reasoning: bool = True

class AnalysisResponse(BaseModel):
    """Full market analysis response."""
    market: MarketResponse
    signals: list[SignalResponse]
    features: Optional[dict] = None
    sentiment: Optional[dict] = None
    analysis_time_ms: float

class PositionRequest(BaseModel):
    """Request to open/modify a position."""
    market_id: str
    outcome_id: str
    side: str  # BUY or SELL
    size: float
    price: float
    signal_id: Optional[str] = None

class PositionResponse(BaseModel):
    """Response for position operations."""
    position_id: str
    market_id: str
    outcome_id: str
    side: str
    size: float
    entry_price: float
    current_price: float
    unrealized_pnl: float
    realized_pnl: float
    status: str
    created_at: datetime

class PortfolioResponse(BaseModel):
    """Portfolio summary response."""
    total_value: float
    cash_balance: float
    positions_value: float
    unrealized_pnl: float
    realized_pnl: float
    total_pnl: float
    positions: list[PositionResponse]
    metrics: dict

class ScanRequest(BaseModel):
    """Request for market scanning."""
    categories: Optional[list[str]] = None
    min_edge: float = 0.02
    min_confluence: float = 0.5
    limit: int = 50

class ScanResponse(BaseModel):
    """Response from market scan."""
    scan_id: str
    timestamp: datetime
    markets_scanned: int
    opportunities_found: int
    opportunities: list[SignalResponse]
    scan_time_ms: float

class HealthResponse(BaseModel):
    """System health response."""
    status: str  # healthy, degraded, unhealthy
    components: dict[str, dict]
    uptime_seconds: float
    version: str

class MetricsResponse(BaseModel):
    """Performance metrics response."""
    total_signals: int
    actionable_signals: int
    signals_today: int
    hit_rate: float
    avg_edge: float
    total_pnl: float
    sharpe_ratio: Optional[float]
    max_drawdown: Optional[float]


# =============================================================================
# Dependency Injection
# =============================================================================

class APIState:
    """Shared application state."""
    
    def __init__(self):
        self.db: Optional[Database] = None
        self.client: Optional[PolymarketClient] = None
        self.feature_engineer: Optional[FeatureEngineer] = None
        self.model: Optional[EnsembleModel] = None
        self.edge_detector: Optional[EdgeDetector] = None
        self.alert_manager: Optional[AlertManager] = None
        self.metrics: Optional[MetricsCollector] = None
        self.health_monitor: Optional[HealthMonitor] = None
        self.start_time: datetime = datetime.utcnow()
        
    async def initialize(self):
        """Initialize all components."""
        # API client (always initialize)
        self.client = PolymarketClient()
        
        # Try to initialize database
        try:
            self.db = Database()
            await self.db.create_tables()
        except Exception as e:
            print(f"Database initialization failed: {e}")
            self.db = None
        
        # ML components (don't require database)
        try:
            self.feature_engineer = FeatureEngineer()
            self.model = EnsembleModel()
            self.edge_detector = EdgeDetector()
        except Exception as e:
            print(f"ML components initialization failed: {e}")
        
        # Monitoring
        try:
            self.alert_manager = AlertManager()
            self.metrics = MetricsCollector()
            self.health_monitor = HealthMonitor(self.alert_manager)
            
            # Register health checks
            self.health_monitor.register_check("api_client", self._check_api)
            if self.db:
                self.health_monitor.register_check("database", self._check_db)
        except Exception as e:
            print(f"Monitoring initialization failed: {e}")
        
    async def cleanup(self):
        """Cleanup resources."""
        if self.client:
            await self.client.close()
        if self.db:
            await self.db.engine.dispose()
            
    async def _check_api(self) -> tuple[bool, str]:
        """Check API health."""
        try:
            markets = await self.client.get_markets(limit=1)
            return True, "API responding"
        except Exception as e:
            return False, str(e)
            
    async def _check_db(self) -> tuple[bool, str]:
        """Check database health."""
        try:
            async with self.db.get_session() as session:
                await session.execute("SELECT 1")
            return True, "Database connected"
        except Exception as e:
            return False, str(e)


# Global state
state = APIState()


async def get_state() -> APIState:
    """Dependency to get application state."""
    return state


async def get_db() -> Database:
    """Dependency to get database."""
    return state.db


async def get_client() -> PolymarketClient:
    """Dependency to get API client."""
    return state.client


# =============================================================================
# Application Factory
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management."""
    # Startup - try to initialize but don't fail if components unavailable
    try:
        await state.initialize()
    except Exception as e:
        print(f"Warning: Full initialization failed ({e}). Running in limited mode.")
        # Initialize just the API client
        state.client = PolymarketClient()
    yield
    # Shutdown
    try:
        await state.cleanup()
    except Exception:
        pass


def create_app() -> FastAPI:
    """Create FastAPI application."""
    
    app = FastAPI(
        title="Polymarket Edge API",
        description="Statistical edge detection for prediction markets",
        version="1.0.0",
        lifespan=lifespan,
    )
    
    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure appropriately for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Root level health endpoint
    @app.get("/health")
    async def root_health():
        """Simple health check endpoint."""
        return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}
    
    # Convenience GET scan endpoint
    @app.get("/api/v1/scan")
    async def quick_scan(
        limit: int = Query(default=20, le=100),
        min_edge: float = Query(default=0.02),
    ):
        """Quick market scan endpoint (GET)."""
        import time
        import uuid
        
        start = time.time()
        scan_id = str(uuid.uuid4())[:8]
        
        try:
            # Try to use initialized client, fall back to new client
            if state.client:
                client = state.client
                close_client = False
            else:
                client = PolymarketClient()
                close_client = True
            
            try:
                markets = await client.get_markets(limit=limit)
                
                opportunities = []
                for market in markets:
                    try:
                        outcomes = await client.get_market_outcomes(market.market_id)
                        
                        for outcome in outcomes:
                            try:
                                price = await client.get_price(outcome.token_id)
                                market_prob = float(price.mid_price)
                                
                                # Simple edge calculation (model_prob = market_prob for now)
                                # In production, this would use the ML model
                                model_prob = market_prob
                                edge = model_prob - market_prob
                                
                                # Calculate Kelly fraction
                                if edge > 0 and market_prob < 1:
                                    kelly = edge / (1 - market_prob) if market_prob < 1 else 0
                                else:
                                    kelly = 0
                                
                                # Determine signal strength
                                if abs(edge) >= 0.05:
                                    strength = "STRONG"
                                elif abs(edge) >= 0.03:
                                    strength = "MODERATE"
                                else:
                                    strength = "WEAK"
                                
                                direction = "BUY" if edge > 0 else "SELL" if edge < -0.02 else "HOLD"
                                
                                opportunities.append({
                                    "market_id": market.market_id,
                                    "market": market.question[:80],
                                    "question": market.question,
                                    "outcome": outcome.outcome_name,
                                    "market_prob": market_prob,
                                    "model_prob": model_prob,
                                    "edge": edge,
                                    "kelly": kelly * 0.25,  # Quarter Kelly
                                    "direction": direction,
                                    "strength": strength,
                                })
                            except Exception:
                                continue
                    except Exception:
                        continue
                
                # Sort by edge
                opportunities.sort(key=lambda x: abs(x["edge"]), reverse=True)
                
            finally:
                if close_client:
                    await client.close()
            
            elapsed = (time.time() - start) * 1000
            
            return {
                "scan_id": scan_id,
                "timestamp": datetime.utcnow().isoformat(),
                "markets_scanned": len(markets),
                "opportunities_found": len(opportunities),
                "opportunities": opportunities[:limit],
                "scan_time_ms": elapsed,
            }
            
        except Exception as e:
            return {
                "scan_id": scan_id,
                "timestamp": datetime.utcnow().isoformat(),
                "markets_scanned": 0,
                "opportunities_found": 0,
                "opportunities": [],
                "scan_time_ms": 0,
                "error": str(e),
            }
    
    # Include routers
    app.include_router(markets_router, prefix="/api/v1/markets", tags=["Markets"])
    app.include_router(signals_router, prefix="/api/v1/signals", tags=["Signals"])
    app.include_router(portfolio_router, prefix="/api/v1/portfolio", tags=["Portfolio"])
    app.include_router(system_router, prefix="/api/v1/system", tags=["System"])
    
    return app


# =============================================================================
# Market Routes
# =============================================================================

from fastapi import APIRouter

markets_router = APIRouter()


@markets_router.get("", response_model=list[MarketResponse])
async def list_markets(
    category: Optional[str] = None,
    status: str = "active",
    limit: int = Query(default=50, le=200),
    offset: int = 0,
    app_state: APIState = Depends(get_state),
):
    """List markets with optional filtering."""
    try:
        markets = await app_state.client.get_markets(
            limit=limit,
            offset=offset,
        )
        
        # Filter by category and status
        filtered = []
        for m in markets:
            if category and m.category != category:
                continue
            if status and m.status != status:
                continue
            filtered.append(MarketResponse(
                market_id=m.market_id,
                question=m.question,
                category=m.category,
                status=m.status,
                end_date=m.end_date,
                outcomes=[{
                    "outcome_id": o.outcome_id,
                    "name": o.outcome_name,
                    "price": o.current_price,
                } for o in m.outcomes]
            ))
            
        return filtered
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@markets_router.get("/{market_id}", response_model=MarketResponse)
async def get_market(
    market_id: str,
    app_state: APIState = Depends(get_state),
):
    """Get detailed market information."""
    try:
        market = await app_state.client.get_market(market_id)
        if not market:
            raise HTTPException(status_code=404, detail="Market not found")
            
        return MarketResponse(
            market_id=market.market_id,
            question=market.question,
            category=market.category,
            status=market.status,
            end_date=market.end_date,
            outcomes=[{
                "outcome_id": o.outcome_id,
                "name": o.outcome_name,
                "price": o.current_price,
                "bid": o.best_bid,
                "ask": o.best_ask,
                "volume_24h": o.volume_24h,
            } for o in market.outcomes]
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@markets_router.post("/{market_id}/analyze", response_model=AnalysisResponse)
async def analyze_market(
    market_id: str,
    request: AnalysisRequest,
    app_state: APIState = Depends(get_state),
):
    """Perform full analysis on a market."""
    import time
    start = time.time()
    
    try:
        # Fetch market data
        market = await app_state.client.get_market(market_id)
        if not market:
            raise HTTPException(status_code=404, detail="Market not found")
            
        # Get price history for features
        price_history = await app_state.client.get_price_history(market_id)
        
        signals = []
        features_dict = None
        
        for outcome in market.outcomes:
            # Compute features
            features = app_state.feature_engineer.compute_features(
                outcome=outcome,
                market=market,
                price_history=price_history,
            )
            
            if request.include_features:
                features_dict = features.to_dict()
            
            # Get model prediction
            prediction = app_state.model.predict(features)
            
            # Detect edge
            signal = app_state.edge_detector.detect(
                outcome=outcome,
                prediction=prediction,
                features=features,
            )
            
            if signal:
                signals.append(SignalResponse(
                    signal_id=signal.signal_id,
                    market_id=market_id,
                    outcome_name=outcome.outcome_name,
                    market_price=outcome.current_price,
                    model_probability=prediction.probability,
                    edge=signal.edge,
                    kelly_fraction=signal.kelly_fraction,
                    confluence_score=signal.confluence_score,
                    signal_strength=signal.signal_strength.value,
                    is_actionable=signal.is_actionable,
                    created_at=signal.created_at,
                    reasoning=signal.reasoning if request.include_reasoning else None,
                ))
                
                # Record in metrics
                app_state.metrics.record_signal(signal)
        
        elapsed = (time.time() - start) * 1000
        
        return AnalysisResponse(
            market=MarketResponse(
                market_id=market.market_id,
                question=market.question,
                category=market.category,
                status=market.status,
                end_date=market.end_date,
                outcomes=[{
                    "outcome_id": o.outcome_id,
                    "name": o.outcome_name,
                    "price": o.current_price,
                } for o in market.outcomes]
            ),
            signals=signals,
            features=features_dict,
            sentiment=None,  # TODO: Add sentiment from external sources
            analysis_time_ms=elapsed,
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# Signal Routes
# =============================================================================

signals_router = APIRouter()


@signals_router.get("", response_model=list[SignalResponse])
async def list_signals(
    actionable_only: bool = True,
    min_edge: float = 0.0,
    min_strength: Optional[str] = None,
    since: Optional[datetime] = None,
    limit: int = Query(default=50, le=200),
    app_state: APIState = Depends(get_state),
):
    """List recent signals with filtering."""
    try:
        async with app_state.db.get_session() as session:
            repo = SignalRepository(session)
            
            if actionable_only:
                signals = await repo.get_actionable_signals(limit=limit)
            else:
                # Get all recent signals
                signals = await repo.get_signals_for_outcome(
                    outcome_id=None,  # All outcomes
                    since=since or datetime.utcnow() - timedelta(days=1),
                    limit=limit,
                )
            
            # Filter
            results = []
            for s in signals:
                if s.edge < min_edge:
                    continue
                if min_strength:
                    strength_order = ["WEAK", "MODERATE", "STRONG", "VERY_STRONG"]
                    if strength_order.index(s.signal_strength.value) < strength_order.index(min_strength):
                        continue
                        
                results.append(SignalResponse(
                    signal_id=s.signal_id,
                    market_id=s.market_id,
                    outcome_name=s.outcome_name,
                    market_price=s.market_price,
                    model_probability=s.model_probability,
                    edge=s.edge,
                    kelly_fraction=s.kelly_fraction,
                    confluence_score=s.confluence_score,
                    signal_strength=s.signal_strength.value,
                    is_actionable=s.is_actionable,
                    created_at=s.created_at,
                    reasoning=s.reasoning,
                ))
                
            return results
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@signals_router.post("/scan", response_model=ScanResponse)
async def scan_markets(
    request: ScanRequest,
    background_tasks: BackgroundTasks,
    app_state: APIState = Depends(get_state),
):
    """Scan markets for opportunities."""
    import time
    import uuid
    
    start = time.time()
    scan_id = str(uuid.uuid4())[:8]
    
    try:
        # Fetch markets
        markets = await app_state.client.get_markets(limit=request.limit)
        
        # Filter by category if specified
        if request.categories:
            markets = [m for m in markets if m.category in request.categories]
        
        opportunities = []
        
        for market in markets:
            try:
                price_history = await app_state.client.get_price_history(market.market_id)
                
                for outcome in market.outcomes:
                    features = app_state.feature_engineer.compute_features(
                        outcome=outcome,
                        market=market,
                        price_history=price_history,
                    )
                    
                    prediction = app_state.model.predict(features)
                    signal = app_state.edge_detector.detect(
                        outcome=outcome,
                        prediction=prediction,
                        features=features,
                    )
                    
                    if signal and signal.edge >= request.min_edge and signal.confluence_score >= request.min_confluence:
                        opportunities.append(SignalResponse(
                            signal_id=signal.signal_id,
                            market_id=market.market_id,
                            outcome_name=outcome.outcome_name,
                            market_price=outcome.current_price,
                            model_probability=prediction.probability,
                            edge=signal.edge,
                            kelly_fraction=signal.kelly_fraction,
                            confluence_score=signal.confluence_score,
                            signal_strength=signal.signal_strength.value,
                            is_actionable=signal.is_actionable,
                            created_at=signal.created_at,
                            reasoning=signal.reasoning,
                        ))
                        
            except Exception as e:
                # Log but continue scanning
                continue
        
        # Sort by edge descending
        opportunities.sort(key=lambda x: x.edge, reverse=True)
        
        elapsed = (time.time() - start) * 1000
        
        return ScanResponse(
            scan_id=scan_id,
            timestamp=datetime.utcnow(),
            markets_scanned=len(markets),
            opportunities_found=len(opportunities),
            opportunities=opportunities,
            scan_time_ms=elapsed,
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# Portfolio Routes
# =============================================================================

portfolio_router = APIRouter()

# In-memory portfolio state (would be database in production)
_portfolio = {
    "cash": 10000.0,
    "positions": {},
}


@portfolio_router.get("", response_model=PortfolioResponse)
async def get_portfolio(
    app_state: APIState = Depends(get_state),
):
    """Get current portfolio status."""
    positions = []
    total_unrealized = 0.0
    total_realized = 0.0
    positions_value = 0.0
    
    for pos_id, pos in _portfolio["positions"].items():
        # Get current price
        try:
            market = await app_state.client.get_market(pos["market_id"])
            outcome = next((o for o in market.outcomes if o.outcome_id == pos["outcome_id"]), None)
            current_price = outcome.current_price if outcome else pos["entry_price"]
        except:
            current_price = pos["entry_price"]
            
        # Calculate P&L
        if pos["side"] == "BUY":
            unrealized = (current_price - pos["entry_price"]) * pos["size"]
        else:
            unrealized = (pos["entry_price"] - current_price) * pos["size"]
            
        total_unrealized += unrealized
        total_realized += pos.get("realized_pnl", 0)
        positions_value += pos["size"] * current_price
        
        positions.append(PositionResponse(
            position_id=pos_id,
            market_id=pos["market_id"],
            outcome_id=pos["outcome_id"],
            side=pos["side"],
            size=pos["size"],
            entry_price=pos["entry_price"],
            current_price=current_price,
            unrealized_pnl=unrealized,
            realized_pnl=pos.get("realized_pnl", 0),
            status=pos["status"],
            created_at=pos["created_at"],
        ))
    
    total_value = _portfolio["cash"] + positions_value
    
    return PortfolioResponse(
        total_value=total_value,
        cash_balance=_portfolio["cash"],
        positions_value=positions_value,
        unrealized_pnl=total_unrealized,
        realized_pnl=total_realized,
        total_pnl=total_unrealized + total_realized,
        positions=positions,
        metrics={
            "position_count": len(positions),
            "win_rate": 0.0,  # TODO: Calculate from history
            "avg_hold_time": 0.0,
        }
    )


@portfolio_router.post("/positions", response_model=PositionResponse)
async def open_position(
    request: PositionRequest,
    app_state: APIState = Depends(get_state),
):
    """Open a new position."""
    import uuid
    
    # Validate
    if request.side not in ["BUY", "SELL"]:
        raise HTTPException(status_code=400, detail="Side must be BUY or SELL")
    if request.size <= 0:
        raise HTTPException(status_code=400, detail="Size must be positive")
    if request.price <= 0 or request.price >= 1:
        raise HTTPException(status_code=400, detail="Price must be between 0 and 1")
    
    # Check cash
    cost = request.size * request.price
    if cost > _portfolio["cash"]:
        raise HTTPException(status_code=400, detail="Insufficient cash")
    
    # Create position
    pos_id = str(uuid.uuid4())[:8]
    _portfolio["positions"][pos_id] = {
        "market_id": request.market_id,
        "outcome_id": request.outcome_id,
        "side": request.side,
        "size": request.size,
        "entry_price": request.price,
        "signal_id": request.signal_id,
        "status": "OPEN",
        "realized_pnl": 0.0,
        "created_at": datetime.utcnow(),
    }
    
    # Deduct cash
    _portfolio["cash"] -= cost
    
    return PositionResponse(
        position_id=pos_id,
        market_id=request.market_id,
        outcome_id=request.outcome_id,
        side=request.side,
        size=request.size,
        entry_price=request.price,
        current_price=request.price,
        unrealized_pnl=0.0,
        realized_pnl=0.0,
        status="OPEN",
        created_at=datetime.utcnow(),
    )


@portfolio_router.delete("/positions/{position_id}")
async def close_position(
    position_id: str,
    exit_price: float = Query(..., gt=0, lt=1),
    app_state: APIState = Depends(get_state),
):
    """Close an existing position."""
    if position_id not in _portfolio["positions"]:
        raise HTTPException(status_code=404, detail="Position not found")
    
    pos = _portfolio["positions"][position_id]
    
    if pos["status"] != "OPEN":
        raise HTTPException(status_code=400, detail="Position already closed")
    
    # Calculate P&L
    if pos["side"] == "BUY":
        pnl = (exit_price - pos["entry_price"]) * pos["size"]
    else:
        pnl = (pos["entry_price"] - exit_price) * pos["size"]
    
    # Update position
    pos["status"] = "CLOSED"
    pos["realized_pnl"] = pnl
    pos["closed_at"] = datetime.utcnow()
    
    # Return cash
    _portfolio["cash"] += pos["size"] * exit_price
    
    # Record in metrics
    app_state.metrics.record_trade_result(pnl)
    
    return {"message": "Position closed", "pnl": pnl}


# =============================================================================
# System Routes
# =============================================================================

system_router = APIRouter()


@system_router.get("/health", response_model=HealthResponse)
async def health_check(
    app_state: APIState = Depends(get_state),
):
    """Get system health status."""
    results = await app_state.health_monitor.check_all()
    overall = app_state.health_monitor.get_overall_status()
    
    uptime = (datetime.utcnow() - app_state.start_time).total_seconds()
    
    return HealthResponse(
        status=overall,
        components={
            name: {"healthy": healthy, "message": msg}
            for name, (healthy, msg) in results.items()
        },
        uptime_seconds=uptime,
        version="1.0.0",
    )


@system_router.get("/metrics", response_model=MetricsResponse)
async def get_metrics(
    app_state: APIState = Depends(get_state),
):
    """Get performance metrics."""
    snapshot = app_state.metrics.snapshot()
    
    return MetricsResponse(
        total_signals=snapshot.total_signals,
        actionable_signals=snapshot.actionable_signals,
        signals_today=snapshot.signals_today,
        hit_rate=snapshot.hit_rate,
        avg_edge=snapshot.avg_edge,
        total_pnl=snapshot.cumulative_return,
        sharpe_ratio=snapshot.sharpe_ratio,
        max_drawdown=snapshot.max_drawdown,
    )


@system_router.get("/metrics/prometheus")
async def prometheus_metrics(
    app_state: APIState = Depends(get_state),
):
    """Get metrics in Prometheus format."""
    from ..monitoring.alerts import DashboardProvider
    
    provider = DashboardProvider(
        app_state.health_monitor,
        app_state.metrics,
        app_state.alert_manager,
    )
    
    return JSONResponse(
        content={"metrics": provider.get_prometheus_metrics()},
        media_type="text/plain",
    )


@system_router.get("/alerts")
async def list_alerts(
    alert_type: Optional[str] = None,
    priority: Optional[str] = None,
    limit: int = Query(default=50, le=200),
    app_state: APIState = Depends(get_state),
):
    """List recent alerts."""
    alerts = app_state.alert_manager.get_recent_alerts(
        alert_type=alert_type,
        limit=limit,
    )
    
    return [
        {
            "alert_id": a.alert_id,
            "title": a.title,
            "message": a.message,
            "priority": a.priority.value,
            "alert_type": a.alert_type.value,
            "timestamp": a.timestamp.isoformat(),
            "acknowledged": a.acknowledged,
        }
        for a in alerts
    ]


@system_router.post("/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(
    alert_id: str,
    app_state: APIState = Depends(get_state),
):
    """Acknowledge an alert."""
    success = app_state.alert_manager.acknowledge_alert(alert_id)
    if not success:
        raise HTTPException(status_code=404, detail="Alert not found")
    return {"message": "Alert acknowledged"}


# =============================================================================
# Application Instance
# =============================================================================

app = create_app()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
