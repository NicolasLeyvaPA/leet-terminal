"""
Backtesting framework for evaluating trading strategies.

Implements walk-forward validation, performance metrics, and robustness checks.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, Callable, Any
import warnings

import numpy as np
import pandas as pd
import structlog

from src.models.probability import (
    ProbabilityModel,
    compute_calibration_metrics,
    CalibrationMetrics,
)
from src.signals.edge import (
    calculate_edge,
    calculate_kelly_fraction,
    fractional_kelly,
    EdgeConfig,
)

logger = structlog.get_logger(__name__)


# =============================================================================
# Performance Metrics
# =============================================================================

@dataclass
class BacktestMetrics:
    """Performance metrics from a backtest."""
    
    # Return metrics
    total_return: float
    annualized_return: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    
    # Trading metrics
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    profit_factor: float
    
    # Risk metrics
    avg_position_size: float
    max_position_size: float
    avg_holding_period_hours: float
    
    # Calibration
    calibration: Optional[CalibrationMetrics] = None
    
    # Time info
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    
    def to_dict(self) -> dict:
        result = {
            "total_return": self.total_return,
            "annualized_return": self.annualized_return,
            "sharpe_ratio": self.sharpe_ratio,
            "sortino_ratio": self.sortino_ratio,
            "max_drawdown": self.max_drawdown,
            "total_trades": self.total_trades,
            "winning_trades": self.winning_trades,
            "losing_trades": self.losing_trades,
            "win_rate": self.win_rate,
            "profit_factor": self.profit_factor,
            "avg_position_size": self.avg_position_size,
            "max_position_size": self.max_position_size,
            "avg_holding_period_hours": self.avg_holding_period_hours,
        }
        if self.calibration:
            result["calibration"] = self.calibration.to_dict()
        return result


@dataclass
class Trade:
    """Record of a single trade."""
    
    trade_id: str
    outcome_id: str
    entry_time: datetime
    exit_time: Optional[datetime]
    
    direction: str  # "YES" or "NO"
    entry_price: float
    exit_price: Optional[float]
    position_size: float
    
    model_prob: float
    edge_at_entry: float
    kelly_at_entry: float
    
    pnl: Optional[float] = None
    return_pct: Optional[float] = None
    resolved: bool = False
    
    def calculate_pnl(self, resolution: str) -> float:
        """
        Calculate P&L based on resolution.
        
        Args:
            resolution: "YES" or "NO" - how the market resolved
        """
        if self.direction == "YES":
            if resolution == "YES":
                # Bought at entry_price, received 1.0
                self.pnl = self.position_size * (1.0 - self.entry_price)
            else:
                # Bought at entry_price, received 0
                self.pnl = -self.position_size * self.entry_price
        else:  # direction == "NO"
            if resolution == "NO":
                # Bought NO at (1 - entry_price), received 1.0
                self.pnl = self.position_size * self.entry_price
            else:
                # Bought NO, received 0
                self.pnl = -self.position_size * (1 - self.entry_price)
        
        self.return_pct = self.pnl / self.position_size if self.position_size > 0 else 0
        self.resolved = True
        return self.pnl


@dataclass
class BacktestResult:
    """Complete backtest results."""
    
    metrics: BacktestMetrics
    trades: list[Trade]
    equity_curve: pd.Series
    drawdown_curve: pd.Series
    
    # Per-period results (for walk-forward)
    period_metrics: list[dict] = field(default_factory=list)
    
    # Configuration used
    config: dict = field(default_factory=dict)


# =============================================================================
# Backtest Engine
# =============================================================================

class BacktestEngine:
    """
    Engine for backtesting trading strategies.
    
    Supports:
    - Walk-forward validation
    - Rolling window evaluation
    - Custom position sizing
    - Multiple performance metrics
    
    Usage:
        engine = BacktestEngine(
            initial_capital=10000,
            train_window_days=90,
            test_window_days=7,
        )
        result = engine.run_backtest(data, model_factory)
    """
    
    def __init__(
        self,
        initial_capital: float = 10000.0,
        train_window_days: int = 90,
        test_window_days: int = 7,
        min_train_samples: int = 100,
        edge_config: EdgeConfig = None,
        position_sizing: str = "kelly",  # "kelly", "fixed", "equal"
        fixed_position_pct: float = 0.02,
        max_positions: int = 20,
        min_edge_threshold: float = 0.02,
    ):
        self.initial_capital = initial_capital
        self.train_window_days = train_window_days
        self.test_window_days = test_window_days
        self.min_train_samples = min_train_samples
        self.edge_config = edge_config or EdgeConfig()
        self.position_sizing = position_sizing
        self.fixed_position_pct = fixed_position_pct
        self.max_positions = max_positions
        self.min_edge_threshold = min_edge_threshold
    
    def run_walk_forward(
        self,
        data: pd.DataFrame,
        model_factory: Callable[[], ProbabilityModel],
        feature_cols: list[str],
        target_col: str = "y",
        time_col: str = "timestamp",
        outcome_col: str = "outcome_id",
    ) -> BacktestResult:
        """
        Run walk-forward backtest.
        
        Args:
            data: DataFrame with features, target, and timestamps
            model_factory: Function that returns a new model instance
            feature_cols: List of feature column names
            target_col: Name of target column
            time_col: Name of timestamp column
            outcome_col: Name of outcome ID column
            
        Returns:
            BacktestResult with metrics, trades, and equity curve
        """
        # Sort by time
        data = data.sort_values(time_col).reset_index(drop=True)
        
        # Get unique dates for walk-forward
        data["_date"] = pd.to_datetime(data[time_col]).dt.date
        unique_dates = sorted(data["_date"].unique())
        
        if len(unique_dates) < self.train_window_days + self.test_window_days:
            raise ValueError(
                f"Not enough data: need {self.train_window_days + self.test_window_days} days, "
                f"have {len(unique_dates)}"
            )
        
        # Initialize tracking
        all_trades = []
        equity = self.initial_capital
        equity_curve = []
        period_metrics = []
        
        # Walk forward through time
        test_start_idx = self.train_window_days
        
        while test_start_idx + self.test_window_days <= len(unique_dates):
            train_start_date = unique_dates[test_start_idx - self.train_window_days]
            train_end_date = unique_dates[test_start_idx - 1]
            test_start_date = unique_dates[test_start_idx]
            test_end_date = unique_dates[min(
                test_start_idx + self.test_window_days - 1,
                len(unique_dates) - 1
            )]
            
            # Split data
            train_mask = (data["_date"] >= train_start_date) & (data["_date"] <= train_end_date)
            test_mask = (data["_date"] >= test_start_date) & (data["_date"] <= test_end_date)
            
            train_data = data[train_mask].copy()
            test_data = data[test_mask].copy()
            
            if len(train_data) < self.min_train_samples:
                logger.warning(
                    "insufficient_training_data",
                    train_samples=len(train_data),
                    required=self.min_train_samples,
                )
                test_start_idx += self.test_window_days
                continue
            
            # Train model
            model = model_factory()
            X_train = train_data[feature_cols]
            y_train = train_data[target_col]
            
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                model.fit(X_train, y_train)
            
            # Generate predictions for test period
            X_test = test_data[feature_cols]
            predictions = model.predict_proba(X_test)
            
            # Get confidence intervals if available
            try:
                ci_lower, ci_upper = model.get_confidence_interval(X_test)
            except Exception:
                ci_lower = predictions - 0.1
                ci_upper = predictions + 0.1
            
            # Generate trades
            test_data = test_data.copy()
            test_data["model_prob"] = predictions
            test_data["ci_lower"] = ci_lower
            test_data["ci_upper"] = ci_upper
            
            period_trades = self._generate_trades(
                test_data,
                equity,
                outcome_col,
                time_col,
            )
            
            # Calculate P&L for resolved trades
            period_pnl = 0
            for trade in period_trades:
                # Look up resolution
                resolution_rows = test_data[
                    test_data[outcome_col] == trade.outcome_id
                ]
                if not resolution_rows.empty and target_col in resolution_rows.columns:
                    resolution = "YES" if resolution_rows[target_col].iloc[0] == 1 else "NO"
                    trade.calculate_pnl(resolution)
                    period_pnl += trade.pnl or 0
            
            # Update equity
            equity += period_pnl
            equity_curve.append({
                "date": test_end_date,
                "equity": equity,
                "period_pnl": period_pnl,
                "num_trades": len(period_trades),
            })
            
            # Store period metrics
            resolved_trades = [t for t in period_trades if t.resolved]
            if resolved_trades:
                period_metrics.append({
                    "period_start": test_start_date,
                    "period_end": test_end_date,
                    "num_trades": len(resolved_trades),
                    "win_rate": sum(1 for t in resolved_trades if t.pnl > 0) / len(resolved_trades),
                    "total_pnl": period_pnl,
                    "avg_edge": np.mean([t.edge_at_entry for t in resolved_trades]),
                })
            
            all_trades.extend(period_trades)
            
            # Move forward
            test_start_idx += self.test_window_days
        
        # Calculate final metrics
        equity_df = pd.DataFrame(equity_curve)
        if len(equity_df) > 0:
            equity_series = equity_df.set_index("date")["equity"]
            drawdown_series = self._calculate_drawdown(equity_series)
        else:
            equity_series = pd.Series([self.initial_capital])
            drawdown_series = pd.Series([0.0])
        
        metrics = self._calculate_metrics(all_trades, equity_series)
        
        return BacktestResult(
            metrics=metrics,
            trades=all_trades,
            equity_curve=equity_series,
            drawdown_curve=drawdown_series,
            period_metrics=period_metrics,
            config={
                "initial_capital": self.initial_capital,
                "train_window_days": self.train_window_days,
                "test_window_days": self.test_window_days,
                "position_sizing": self.position_sizing,
                "min_edge_threshold": self.min_edge_threshold,
            },
        )
    
    def _generate_trades(
        self,
        data: pd.DataFrame,
        current_equity: float,
        outcome_col: str,
        time_col: str,
    ) -> list[Trade]:
        """Generate trades from predictions."""
        trades = []
        
        # Group by outcome
        for outcome_id, group in data.groupby(outcome_col):
            # Use latest prediction for each outcome
            row = group.iloc[-1]
            
            model_prob = row["model_prob"]
            market_prob = row.get("implied_prob", row.get("mid_price", 0.5))
            
            # Calculate edge
            edge, direction = calculate_edge(
                model_prob,
                market_prob,
                self.edge_config.trading_fee_pct,
            )
            
            # Check if edge exceeds threshold
            if edge < self.min_edge_threshold or direction is None:
                continue
            
            # Calculate position size
            kelly = calculate_kelly_fraction(
                model_prob,
                market_prob,
                self.edge_config.trading_fee_pct,
            )
            frac_kelly = fractional_kelly(
                kelly,
                self.edge_config.kelly_fraction,
                self.edge_config.max_kelly,
            )
            
            if self.position_sizing == "kelly":
                position_size = current_equity * frac_kelly
            elif self.position_sizing == "fixed":
                position_size = current_equity * self.fixed_position_pct
            else:  # equal
                position_size = current_equity / self.max_positions
            
            # Skip tiny positions
            if position_size < 1.0:
                continue
            
            trade = Trade(
                trade_id=f"{outcome_id}_{row[time_col]}",
                outcome_id=outcome_id,
                entry_time=pd.to_datetime(row[time_col]),
                exit_time=None,
                direction=direction,
                entry_price=market_prob,
                exit_price=None,
                position_size=position_size,
                model_prob=model_prob,
                edge_at_entry=edge,
                kelly_at_entry=frac_kelly,
            )
            trades.append(trade)
        
        return trades
    
    def _calculate_drawdown(self, equity_series: pd.Series) -> pd.Series:
        """Calculate drawdown series."""
        rolling_max = equity_series.cummax()
        drawdown = (equity_series - rolling_max) / rolling_max
        return drawdown
    
    def _calculate_metrics(
        self,
        trades: list[Trade],
        equity_series: pd.Series,
    ) -> BacktestMetrics:
        """Calculate performance metrics from trades and equity."""
        resolved_trades = [t for t in trades if t.resolved]
        
        if not resolved_trades:
            return BacktestMetrics(
                total_return=0,
                annualized_return=0,
                sharpe_ratio=0,
                sortino_ratio=0,
                max_drawdown=0,
                total_trades=0,
                winning_trades=0,
                losing_trades=0,
                win_rate=0,
                profit_factor=0,
                avg_position_size=0,
                max_position_size=0,
                avg_holding_period_hours=0,
            )
        
        # Return metrics
        total_return = (equity_series.iloc[-1] - self.initial_capital) / self.initial_capital
        
        # Estimate annualized return
        if len(equity_series) > 1:
            days = (equity_series.index[-1] - equity_series.index[0]).days
            if days > 0:
                annualized_return = (1 + total_return) ** (365 / days) - 1
            else:
                annualized_return = total_return
        else:
            annualized_return = total_return
        
        # Calculate returns for Sharpe/Sortino
        if len(equity_series) > 1:
            returns = equity_series.pct_change().dropna()
            if len(returns) > 0 and returns.std() > 0:
                sharpe_ratio = returns.mean() / returns.std() * np.sqrt(252)
                downside_returns = returns[returns < 0]
                if len(downside_returns) > 0 and downside_returns.std() > 0:
                    sortino_ratio = returns.mean() / downside_returns.std() * np.sqrt(252)
                else:
                    sortino_ratio = sharpe_ratio
            else:
                sharpe_ratio = 0
                sortino_ratio = 0
        else:
            sharpe_ratio = 0
            sortino_ratio = 0
        
        # Max drawdown
        drawdown = self._calculate_drawdown(equity_series)
        max_drawdown = abs(drawdown.min()) if len(drawdown) > 0 else 0
        
        # Trade metrics
        winning = [t for t in resolved_trades if t.pnl and t.pnl > 0]
        losing = [t for t in resolved_trades if t.pnl and t.pnl <= 0]
        
        total_profit = sum(t.pnl for t in winning) if winning else 0
        total_loss = abs(sum(t.pnl for t in losing)) if losing else 0
        
        profit_factor = total_profit / total_loss if total_loss > 0 else float("inf")
        win_rate = len(winning) / len(resolved_trades) if resolved_trades else 0
        
        # Position metrics
        position_sizes = [t.position_size for t in resolved_trades]
        avg_position = np.mean(position_sizes) if position_sizes else 0
        max_position = max(position_sizes) if position_sizes else 0
        
        # Holding period (placeholder - would need exit times)
        avg_holding = 24.0  # Assume 24 hours average
        
        return BacktestMetrics(
            total_return=total_return,
            annualized_return=annualized_return,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            max_drawdown=max_drawdown,
            total_trades=len(resolved_trades),
            winning_trades=len(winning),
            losing_trades=len(losing),
            win_rate=win_rate,
            profit_factor=profit_factor,
            avg_position_size=avg_position,
            max_position_size=max_position,
            avg_holding_period_hours=avg_holding,
            start_date=equity_series.index[0] if len(equity_series) > 0 else None,
            end_date=equity_series.index[-1] if len(equity_series) > 0 else None,
        )


# =============================================================================
# Robustness Testing
# =============================================================================

def run_robustness_tests(
    data: pd.DataFrame,
    model_factory: Callable[[], ProbabilityModel],
    feature_cols: list[str],
    base_config: dict,
    tests: list[str] = None,
) -> dict[str, BacktestResult]:
    """
    Run multiple robustness tests on the strategy.
    
    Args:
        data: Full dataset
        model_factory: Function to create model instances
        feature_cols: Feature column names
        base_config: Base backtest configuration
        tests: List of test names to run
        
    Returns:
        Dict mapping test name to BacktestResult
    """
    if tests is None:
        tests = [
            "baseline",
            "exclude_first_month",
            "varying_kelly_0.1",
            "varying_kelly_0.5",
            "edge_threshold_0.03",
            "edge_threshold_0.05",
        ]
    
    results = {}
    
    for test_name in tests:
        logger.info("running_robustness_test", test=test_name)
        
        test_data = data.copy()
        config = base_config.copy()
        
        if test_name == "baseline":
            pass  # Use base config
        
        elif test_name == "exclude_first_month":
            # Remove first 30 days
            test_data["_date"] = pd.to_datetime(test_data["timestamp"]).dt.date
            cutoff = test_data["_date"].min() + timedelta(days=30)
            test_data = test_data[test_data["_date"] >= cutoff]
        
        elif test_name.startswith("varying_kelly_"):
            kelly_frac = float(test_name.split("_")[-1])
            config["edge_config"] = EdgeConfig(kelly_fraction=kelly_frac)
        
        elif test_name.startswith("edge_threshold_"):
            threshold = float(test_name.split("_")[-1])
            config["min_edge_threshold"] = threshold
        
        try:
            engine = BacktestEngine(**config)
            result = engine.run_walk_forward(
                test_data,
                model_factory,
                feature_cols,
            )
            results[test_name] = result
        except Exception as e:
            logger.error("robustness_test_failed", test=test_name, error=str(e))
    
    return results


def compare_backtest_results(results: dict[str, BacktestResult]) -> pd.DataFrame:
    """
    Create comparison table of backtest results.
    
    Args:
        results: Dict mapping names to BacktestResult
        
    Returns:
        DataFrame with metrics for each backtest
    """
    rows = []
    
    for name, result in results.items():
        row = {"name": name}
        row.update(result.metrics.to_dict())
        rows.append(row)
    
    return pd.DataFrame(rows).set_index("name")
