"""
Feature engineering for Polymarket prediction models.

Transforms raw market data into features suitable for ML models.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional

import numpy as np
import pandas as pd
import structlog

from src.data.models import Market, Outcome, PriceSnapshot, Trade

logger = structlog.get_logger(__name__)


@dataclass
class FeatureSet:
    """Container for engineered features."""
    
    outcome_id: str
    market_id: str
    timestamp: datetime
    
    # Market-derived features
    implied_prob: float
    spread_bps: float
    depth_imbalance: float
    liquidity_score: float
    
    # Time features
    time_to_resolution_hours: float
    market_age_days: float
    hour_of_day: int
    day_of_week: int
    
    # Momentum features
    price_momentum_1h: Optional[float] = None
    price_momentum_24h: Optional[float] = None
    price_volatility_24h: Optional[float] = None
    volume_zscore: Optional[float] = None
    
    # Cross-market features
    category_avg_price: Optional[float] = None
    overround: Optional[float] = None
    
    # Trade flow features
    buy_sell_ratio_1h: Optional[float] = None
    large_trade_indicator: Optional[float] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary for DataFrame creation."""
        return {
            "outcome_id": self.outcome_id,
            "market_id": self.market_id,
            "timestamp": self.timestamp,
            "implied_prob": self.implied_prob,
            "spread_bps": self.spread_bps,
            "depth_imbalance": self.depth_imbalance,
            "liquidity_score": self.liquidity_score,
            "time_to_resolution_hours": self.time_to_resolution_hours,
            "market_age_days": self.market_age_days,
            "hour_of_day": self.hour_of_day,
            "day_of_week": self.day_of_week,
            "price_momentum_1h": self.price_momentum_1h,
            "price_momentum_24h": self.price_momentum_24h,
            "price_volatility_24h": self.price_volatility_24h,
            "volume_zscore": self.volume_zscore,
            "category_avg_price": self.category_avg_price,
            "overround": self.overround,
            "buy_sell_ratio_1h": self.buy_sell_ratio_1h,
            "large_trade_indicator": self.large_trade_indicator,
        }
    
    @classmethod
    def feature_names(cls) -> list[str]:
        """Get list of feature names for model training."""
        return [
            "implied_prob",
            "spread_bps",
            "depth_imbalance",
            "liquidity_score",
            "time_to_resolution_hours",
            "market_age_days",
            "hour_of_day",
            "day_of_week",
            "price_momentum_1h",
            "price_momentum_24h",
            "price_volatility_24h",
            "volume_zscore",
            "category_avg_price",
            "overround",
            "buy_sell_ratio_1h",
            "large_trade_indicator",
        ]


class FeatureEngineer:
    """
    Transforms raw market data into ML features.
    
    Usage:
        engineer = FeatureEngineer()
        features = engineer.compute_features(
            market=market,
            outcome=outcome,
            current_price=price_snapshot,
            price_history=historical_prices,
            trades=recent_trades,
        )
    """
    
    def __init__(
        self,
        volume_lookback_days: int = 30,
        momentum_windows: list[int] = None,
    ):
        self.volume_lookback_days = volume_lookback_days
        self.momentum_windows = momentum_windows or [1, 24]  # hours
        
        # Running statistics for z-score calculations
        self._volume_stats: dict[str, tuple[float, float]] = {}  # market_id -> (mean, std)
    
    def compute_features(
        self,
        market: Market,
        outcome: Outcome,
        current_price: PriceSnapshot,
        price_history: Optional[list[PriceSnapshot]] = None,
        trades: Optional[list[Trade]] = None,
        all_outcome_prices: Optional[dict[str, PriceSnapshot]] = None,
    ) -> FeatureSet:
        """
        Compute full feature set for an outcome.
        
        Args:
            market: The parent market
            outcome: The outcome/token
            current_price: Current price snapshot
            price_history: Historical price snapshots (ordered oldest to newest)
            trades: Recent trades
            all_outcome_prices: Prices of all outcomes in the market (for overround)
            
        Returns:
            FeatureSet with all computed features
        """
        now = current_price.ts
        
        # Basic features from current price
        implied_prob = float(current_price.mid_price)
        spread_bps = current_price.spread_bps
        depth_imbalance = current_price.depth_imbalance
        
        # Liquidity score
        liquidity_score = self._compute_liquidity_score(current_price)
        
        # Time features
        time_to_resolution = market.time_to_resolution_hours
        market_age = market.market_age_days
        hour_of_day = now.hour
        day_of_week = now.weekday()
        
        # Initialize optional features
        price_momentum_1h = None
        price_momentum_24h = None
        price_volatility_24h = None
        volume_zscore = None
        buy_sell_ratio_1h = None
        large_trade_indicator = None
        
        # Momentum and volatility from price history
        if price_history and len(price_history) > 1:
            price_df = self._prices_to_dataframe(price_history)
            
            price_momentum_1h = self._compute_momentum(price_df, hours=1)
            price_momentum_24h = self._compute_momentum(price_df, hours=24)
            price_volatility_24h = self._compute_volatility(price_df, hours=24)
        
        # Volume z-score
        if current_price.volume_24h > 0:
            volume_zscore = self._compute_volume_zscore(
                market.market_id,
                float(current_price.volume_24h),
            )
        
        # Trade flow features
        if trades:
            buy_sell_ratio_1h = self._compute_buy_sell_ratio(trades, hours=1)
            large_trade_indicator = self._compute_large_trade_indicator(trades)
        
        # Cross-market features
        overround = None
        if all_outcome_prices:
            overround = sum(float(p.mid_price) for p in all_outcome_prices.values())
        
        return FeatureSet(
            outcome_id=outcome.outcome_id,
            market_id=market.market_id,
            timestamp=now,
            implied_prob=implied_prob,
            spread_bps=spread_bps,
            depth_imbalance=depth_imbalance,
            liquidity_score=liquidity_score,
            time_to_resolution_hours=time_to_resolution,
            market_age_days=market_age,
            hour_of_day=hour_of_day,
            day_of_week=day_of_week,
            price_momentum_1h=price_momentum_1h,
            price_momentum_24h=price_momentum_24h,
            price_volatility_24h=price_volatility_24h,
            volume_zscore=volume_zscore,
            overround=overround,
            buy_sell_ratio_1h=buy_sell_ratio_1h,
            large_trade_indicator=large_trade_indicator,
        )
    
    def _compute_liquidity_score(self, price: PriceSnapshot) -> float:
        """
        Compute liquidity score from volume and depth.
        
        Score = log(volume_24h * avg_depth + 1)
        """
        avg_depth = (float(price.bid_depth_1pct) + float(price.ask_depth_1pct)) / 2
        volume = float(price.volume_24h)
        
        # Avoid log(0)
        raw_score = volume * max(avg_depth, 1)
        return np.log1p(raw_score)
    
    def _prices_to_dataframe(self, prices: list[PriceSnapshot]) -> pd.DataFrame:
        """Convert price snapshots to DataFrame."""
        data = [
            {
                "ts": p.ts,
                "mid_price": float(p.mid_price),
                "volume_24h": float(p.volume_24h),
            }
            for p in prices
        ]
        df = pd.DataFrame(data)
        df = df.set_index("ts").sort_index()
        return df
    
    def _compute_momentum(
        self,
        price_df: pd.DataFrame,
        hours: int,
    ) -> Optional[float]:
        """
        Compute price momentum over specified hours.
        
        Momentum = (current_price - past_price) / past_price
        """
        if len(price_df) < 2:
            return None
        
        current_price = price_df["mid_price"].iloc[-1]
        cutoff_time = price_df.index[-1] - timedelta(hours=hours)
        
        # Find price closest to cutoff
        past_prices = price_df[price_df.index <= cutoff_time]
        if past_prices.empty:
            past_prices = price_df.iloc[:1]
        
        past_price = past_prices["mid_price"].iloc[-1]
        
        if past_price == 0:
            return 0.0
        
        return (current_price - past_price) / past_price
    
    def _compute_volatility(
        self,
        price_df: pd.DataFrame,
        hours: int,
    ) -> Optional[float]:
        """
        Compute price volatility (std of returns) over specified hours.
        """
        cutoff_time = price_df.index[-1] - timedelta(hours=hours)
        recent_df = price_df[price_df.index >= cutoff_time]
        
        if len(recent_df) < 3:
            return None
        
        # Calculate returns
        returns = recent_df["mid_price"].pct_change().dropna()
        
        if len(returns) < 2:
            return None
        
        return float(returns.std())
    
    def _compute_volume_zscore(
        self,
        market_id: str,
        current_volume: float,
    ) -> float:
        """
        Compute z-score of current volume relative to historical.
        
        Uses running statistics that should be updated periodically.
        """
        if market_id not in self._volume_stats:
            # Initialize with current volume (z-score = 0)
            self._volume_stats[market_id] = (current_volume, max(current_volume * 0.5, 1000))
        
        mean, std = self._volume_stats[market_id]
        
        if std == 0:
            return 0.0
        
        return (current_volume - mean) / std
    
    def update_volume_stats(
        self,
        market_id: str,
        historical_volumes: list[float],
    ):
        """Update running volume statistics for a market."""
        if not historical_volumes:
            return
        
        mean = np.mean(historical_volumes)
        std = np.std(historical_volumes)
        
        self._volume_stats[market_id] = (mean, max(std, 1.0))
    
    def _compute_buy_sell_ratio(
        self,
        trades: list[Trade],
        hours: int,
    ) -> float:
        """
        Compute ratio of buy volume to total volume in recent window.
        
        Returns value in [0, 1], where 0.5 is balanced.
        """
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        recent_trades = [t for t in trades if t.ts >= cutoff]
        
        if not recent_trades:
            return 0.5  # Neutral
        
        buy_volume = sum(
            float(t.size) for t in recent_trades
            if t.side.value == "BUY"
        )
        total_volume = sum(float(t.size) for t in recent_trades)
        
        if total_volume == 0:
            return 0.5
        
        return buy_volume / total_volume
    
    def _compute_large_trade_indicator(
        self,
        trades: list[Trade],
        threshold_percentile: float = 90,
    ) -> float:
        """
        Indicator for presence of large trades.
        
        Returns fraction of volume from trades above threshold.
        """
        if not trades:
            return 0.0
        
        sizes = [float(t.size) for t in trades]
        threshold = np.percentile(sizes, threshold_percentile)
        
        large_volume = sum(s for s in sizes if s >= threshold)
        total_volume = sum(sizes)
        
        if total_volume == 0:
            return 0.0
        
        return large_volume / total_volume


def create_training_dataset(
    features_list: list[FeatureSet],
    outcomes: dict[str, bool],  # outcome_id -> resolved_yes
) -> tuple[pd.DataFrame, pd.Series]:
    """
    Create training dataset from features and outcomes.
    
    Args:
        features_list: List of FeatureSet objects
        outcomes: Dict mapping outcome_id to whether it resolved YES
        
    Returns:
        X (features DataFrame), y (labels Series)
    """
    # Convert features to DataFrame
    data = [f.to_dict() for f in features_list]
    df = pd.DataFrame(data)
    
    # Add labels
    df["y"] = df["outcome_id"].map(outcomes).astype(float)
    
    # Drop rows without labels
    df = df.dropna(subset=["y"])
    
    # Select feature columns
    feature_cols = FeatureSet.feature_names()
    X = df[feature_cols].copy()
    y = df["y"].copy()
    
    # Handle missing values
    X = X.fillna(X.median())
    
    return X, y


def prepare_inference_features(
    features: FeatureSet,
) -> pd.DataFrame:
    """
    Prepare features for model inference.
    
    Args:
        features: Single FeatureSet
        
    Returns:
        DataFrame with one row, ready for model.predict()
    """
    data = features.to_dict()
    df = pd.DataFrame([data])
    
    feature_cols = FeatureSet.feature_names()
    X = df[feature_cols].copy()
    
    # Fill missing with 0 (or could use stored medians)
    X = X.fillna(0)
    
    return X
