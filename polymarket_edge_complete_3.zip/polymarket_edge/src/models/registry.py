"""
Model Registry for Polymarket Edge System.

Provides:
- Model versioning and storage
- A/B testing support
- Model performance tracking
- Automatic model promotion/rollback
"""

import json
import hashlib
import pickle
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Any, Protocol
from dataclasses import dataclass, field
from enum import Enum
import shutil

import numpy as np
from pydantic import BaseModel, Field


# =============================================================================
# Enums and Types
# =============================================================================

class ModelStatus(str, Enum):
    """Model deployment status."""
    DEVELOPMENT = "development"  # Being trained/tested
    STAGING = "staging"          # Ready for A/B testing
    PRODUCTION = "production"    # Active in production
    DEPRECATED = "deprecated"    # Old version, still available
    ARCHIVED = "archived"        # No longer active


class ModelType(str, Enum):
    """Type of model."""
    PROBABILITY = "probability"     # Probability calibration
    ENSEMBLE = "ensemble"           # Ensemble of models
    FEATURE = "feature"             # Feature engineering
    SENTIMENT = "sentiment"         # Sentiment analysis
    

# =============================================================================
# Model Metadata
# =============================================================================

class ModelMetadata(BaseModel):
    """Metadata for a registered model."""
    model_id: str
    name: str
    version: str
    model_type: ModelType
    status: ModelStatus = ModelStatus.DEVELOPMENT
    
    # Training info
    trained_at: datetime
    training_data_start: Optional[datetime] = None
    training_data_end: Optional[datetime] = None
    training_samples: int = 0
    
    # Model details
    algorithm: str
    hyperparameters: dict = Field(default_factory=dict)
    features_used: list[str] = Field(default_factory=list)
    
    # Performance metrics
    metrics: dict = Field(default_factory=dict)
    # e.g., {"brier_score": 0.18, "log_loss": 0.45, "calibration_error": 0.02}
    
    # Hashes for integrity
    model_hash: str = ""
    config_hash: str = ""
    
    # Tracking
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    promoted_at: Optional[datetime] = None
    deprecated_at: Optional[datetime] = None
    
    # A/B testing
    traffic_percentage: float = 0.0  # Percentage of traffic this model handles
    
    # Notes
    description: str = ""
    change_log: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)


class ModelPerformanceLog(BaseModel):
    """Performance tracking over time."""
    model_id: str
    timestamp: datetime
    predictions_count: int
    avg_confidence: float
    
    # Outcome tracking (after resolution)
    resolved_predictions: int = 0
    correct_predictions: int = 0
    accuracy: float = 0.0
    
    # Calibration
    brier_score: Optional[float] = None
    log_loss: Optional[float] = None
    calibration_error: Optional[float] = None
    
    # Edge metrics
    avg_edge: float = 0.0
    edge_hit_rate: float = 0.0  # % of edges that were correct
    realized_pnl: float = 0.0


# =============================================================================
# Model Interface
# =============================================================================

class PredictionModel(Protocol):
    """Protocol for prediction models."""
    
    def predict(self, features: Any) -> Any:
        """Make a prediction."""
        ...
    
    def predict_proba(self, features: Any) -> np.ndarray:
        """Get probability predictions."""
        ...


# =============================================================================
# Model Registry
# =============================================================================

class ModelRegistry:
    """
    Central registry for model versioning and management.
    """
    
    def __init__(
        self,
        storage_path: str = "./models",
        metadata_file: str = "registry.json",
    ):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.metadata_file = self.storage_path / metadata_file
        
        # In-memory cache
        self._models: dict[str, Any] = {}
        self._metadata: dict[str, ModelMetadata] = {}
        
        # Load existing metadata
        self._load_metadata()
    
    def _load_metadata(self):
        """Load metadata from disk."""
        if self.metadata_file.exists():
            with open(self.metadata_file) as f:
                data = json.load(f)
                for model_id, meta_dict in data.items():
                    self._metadata[model_id] = ModelMetadata(**meta_dict)
    
    def _save_metadata(self):
        """Save metadata to disk."""
        data = {
            model_id: meta.model_dump(mode="json")
            for model_id, meta in self._metadata.items()
        }
        with open(self.metadata_file, "w") as f:
            json.dump(data, f, indent=2, default=str)
    
    def _compute_model_hash(self, model: Any) -> str:
        """Compute hash of model for integrity checking."""
        model_bytes = pickle.dumps(model)
        return hashlib.sha256(model_bytes).hexdigest()[:16]
    
    def _compute_config_hash(self, config: dict) -> str:
        """Compute hash of configuration."""
        config_str = json.dumps(config, sort_keys=True)
        return hashlib.sha256(config_str.encode()).hexdigest()[:16]
    
    def _get_model_path(self, model_id: str) -> Path:
        """Get path for model storage."""
        return self.storage_path / f"{model_id}.pkl"
    
    # -------------------------------------------------------------------------
    # Registration
    # -------------------------------------------------------------------------
    
    def register(
        self,
        model: Any,
        name: str,
        version: str,
        model_type: ModelType,
        algorithm: str,
        hyperparameters: dict = None,
        features_used: list[str] = None,
        metrics: dict = None,
        training_samples: int = 0,
        training_data_start: datetime = None,
        training_data_end: datetime = None,
        description: str = "",
        tags: list[str] = None,
    ) -> ModelMetadata:
        """
        Register a new model version.
        
        Args:
            model: The trained model object
            name: Model name (e.g., "ensemble_calibrator")
            version: Semantic version (e.g., "1.2.0")
            model_type: Type of model
            algorithm: Algorithm used (e.g., "lightgbm", "isotonic")
            hyperparameters: Training hyperparameters
            features_used: List of feature names
            metrics: Performance metrics from training
            training_samples: Number of training samples
            training_data_start: Start of training period
            training_data_end: End of training period
            description: Human-readable description
            tags: Tags for filtering
            
        Returns:
            ModelMetadata for the registered model
        """
        # Generate model ID
        model_id = f"{name}_{version}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
        
        # Compute hashes
        model_hash = self._compute_model_hash(model)
        config_hash = self._compute_config_hash(hyperparameters or {})
        
        # Create metadata
        metadata = ModelMetadata(
            model_id=model_id,
            name=name,
            version=version,
            model_type=model_type,
            algorithm=algorithm,
            hyperparameters=hyperparameters or {},
            features_used=features_used or [],
            metrics=metrics or {},
            training_samples=training_samples,
            training_data_start=training_data_start,
            training_data_end=training_data_end,
            trained_at=datetime.utcnow(),
            model_hash=model_hash,
            config_hash=config_hash,
            description=description,
            tags=tags or [],
            change_log=[f"Initial registration: {description}"],
        )
        
        # Save model to disk
        model_path = self._get_model_path(model_id)
        with open(model_path, "wb") as f:
            pickle.dump(model, f)
        
        # Update registry
        self._models[model_id] = model
        self._metadata[model_id] = metadata
        self._save_metadata()
        
        return metadata
    
    # -------------------------------------------------------------------------
    # Retrieval
    # -------------------------------------------------------------------------
    
    def get(self, model_id: str) -> tuple[Any, ModelMetadata]:
        """Get a model and its metadata by ID."""
        if model_id not in self._metadata:
            raise KeyError(f"Model {model_id} not found in registry")
        
        metadata = self._metadata[model_id]
        
        # Load from cache or disk
        if model_id not in self._models:
            model_path = self._get_model_path(model_id)
            if not model_path.exists():
                raise FileNotFoundError(f"Model file not found: {model_path}")
            with open(model_path, "rb") as f:
                self._models[model_id] = pickle.load(f)
        
        return self._models[model_id], metadata
    
    def get_latest(
        self,
        name: str,
        model_type: Optional[ModelType] = None,
        status: ModelStatus = ModelStatus.PRODUCTION,
    ) -> tuple[Any, ModelMetadata]:
        """Get the latest model version by name."""
        candidates = [
            meta for meta in self._metadata.values()
            if meta.name == name
            and meta.status == status
            and (model_type is None or meta.model_type == model_type)
        ]
        
        if not candidates:
            raise KeyError(f"No {status.value} model found with name {name}")
        
        # Sort by version (semantic versioning)
        latest = max(candidates, key=lambda m: self._parse_version(m.version))
        return self.get(latest.model_id)
    
    def get_production_models(self) -> list[tuple[Any, ModelMetadata]]:
        """Get all production models."""
        production = [
            meta for meta in self._metadata.values()
            if meta.status == ModelStatus.PRODUCTION
        ]
        return [self.get(meta.model_id) for meta in production]
    
    def _parse_version(self, version: str) -> tuple:
        """Parse semantic version string."""
        parts = version.split(".")
        return tuple(int(p) for p in parts if p.isdigit())
    
    # -------------------------------------------------------------------------
    # Lifecycle Management
    # -------------------------------------------------------------------------
    
    def promote(
        self,
        model_id: str,
        to_status: ModelStatus,
        traffic_percentage: float = 100.0,
        change_note: str = "",
    ) -> ModelMetadata:
        """Promote a model to a new status."""
        if model_id not in self._metadata:
            raise KeyError(f"Model {model_id} not found")
        
        metadata = self._metadata[model_id]
        old_status = metadata.status
        
        # Validation
        valid_transitions = {
            ModelStatus.DEVELOPMENT: [ModelStatus.STAGING, ModelStatus.DEPRECATED],
            ModelStatus.STAGING: [ModelStatus.PRODUCTION, ModelStatus.DEPRECATED],
            ModelStatus.PRODUCTION: [ModelStatus.DEPRECATED],
            ModelStatus.DEPRECATED: [ModelStatus.ARCHIVED],
        }
        
        if to_status not in valid_transitions.get(old_status, []):
            raise ValueError(
                f"Invalid transition: {old_status.value} -> {to_status.value}"
            )
        
        # If promoting to production, demote current production model
        if to_status == ModelStatus.PRODUCTION:
            current_prod = [
                m for m in self._metadata.values()
                if m.name == metadata.name
                and m.status == ModelStatus.PRODUCTION
                and m.model_id != model_id
            ]
            for prod in current_prod:
                prod.status = ModelStatus.DEPRECATED
                prod.deprecated_at = datetime.utcnow()
                prod.traffic_percentage = 0.0
                prod.change_log.append(
                    f"Deprecated: replaced by {model_id}"
                )
        
        # Update metadata
        metadata.status = to_status
        metadata.updated_at = datetime.utcnow()
        metadata.traffic_percentage = traffic_percentage
        
        if to_status == ModelStatus.PRODUCTION:
            metadata.promoted_at = datetime.utcnow()
        elif to_status == ModelStatus.DEPRECATED:
            metadata.deprecated_at = datetime.utcnow()
        
        metadata.change_log.append(
            f"Promoted from {old_status.value} to {to_status.value}: {change_note}"
        )
        
        self._save_metadata()
        return metadata
    
    def rollback(
        self,
        name: str,
        to_version: Optional[str] = None,
    ) -> ModelMetadata:
        """
        Rollback to a previous model version.
        
        If to_version is None, rolls back to the previous production version.
        """
        # Find current production
        current_prod = next(
            (m for m in self._metadata.values()
             if m.name == name and m.status == ModelStatus.PRODUCTION),
            None
        )
        
        if to_version:
            # Find specific version
            target = next(
                (m for m in self._metadata.values()
                 if m.name == name and m.version == to_version),
                None
            )
        else:
            # Find previous production (most recent deprecated)
            deprecated = [
                m for m in self._metadata.values()
                if m.name == name and m.status == ModelStatus.DEPRECATED
            ]
            target = max(deprecated, key=lambda m: m.deprecated_at) if deprecated else None
        
        if not target:
            raise KeyError(f"No rollback target found for {name}")
        
        # Demote current, promote target
        if current_prod:
            current_prod.status = ModelStatus.DEPRECATED
            current_prod.deprecated_at = datetime.utcnow()
            current_prod.traffic_percentage = 0.0
            current_prod.change_log.append(
                f"Deprecated: rolled back to {target.version}"
            )
        
        target.status = ModelStatus.PRODUCTION
        target.promoted_at = datetime.utcnow()
        target.traffic_percentage = 100.0
        target.change_log.append(
            f"Restored to production via rollback"
        )
        
        self._save_metadata()
        return target
    
    # -------------------------------------------------------------------------
    # A/B Testing
    # -------------------------------------------------------------------------
    
    def setup_ab_test(
        self,
        control_model_id: str,
        treatment_model_id: str,
        treatment_traffic_pct: float = 10.0,
    ) -> dict:
        """
        Set up an A/B test between two models.
        
        Args:
            control_model_id: Current production model
            treatment_model_id: New model to test
            treatment_traffic_pct: Percentage of traffic for treatment
            
        Returns:
            Test configuration
        """
        control = self._metadata.get(control_model_id)
        treatment = self._metadata.get(treatment_model_id)
        
        if not control or not treatment:
            raise KeyError("Model not found")
        
        # Update traffic allocation
        control.traffic_percentage = 100.0 - treatment_traffic_pct
        treatment.traffic_percentage = treatment_traffic_pct
        treatment.status = ModelStatus.STAGING
        
        control.change_log.append(
            f"A/B test started: {control.traffic_percentage}% traffic"
        )
        treatment.change_log.append(
            f"A/B test started: {treatment.traffic_percentage}% traffic"
        )
        
        self._save_metadata()
        
        return {
            "control": {
                "model_id": control_model_id,
                "traffic_pct": control.traffic_percentage,
            },
            "treatment": {
                "model_id": treatment_model_id,
                "traffic_pct": treatment.traffic_percentage,
            },
        }
    
    def get_model_for_request(
        self,
        name: str,
        request_id: str,
    ) -> tuple[Any, ModelMetadata]:
        """
        Get model for a request, respecting A/B test allocation.
        
        Uses request_id for deterministic bucketing.
        """
        # Find active models (production + staging)
        active = [
            m for m in self._metadata.values()
            if m.name == name
            and m.status in [ModelStatus.PRODUCTION, ModelStatus.STAGING]
            and m.traffic_percentage > 0
        ]
        
        if not active:
            raise KeyError(f"No active model found for {name}")
        
        if len(active) == 1:
            return self.get(active[0].model_id)
        
        # Deterministic bucketing based on request_id
        bucket = int(hashlib.md5(request_id.encode()).hexdigest(), 16) % 100
        
        cumulative = 0.0
        for meta in sorted(active, key=lambda m: m.traffic_percentage, reverse=True):
            cumulative += meta.traffic_percentage
            if bucket < cumulative:
                return self.get(meta.model_id)
        
        # Fallback to production
        production = next(m for m in active if m.status == ModelStatus.PRODUCTION)
        return self.get(production.model_id)
    
    # -------------------------------------------------------------------------
    # Performance Tracking
    # -------------------------------------------------------------------------
    
    def log_performance(
        self,
        model_id: str,
        log: ModelPerformanceLog,
    ):
        """Log model performance metrics."""
        if model_id not in self._metadata:
            raise KeyError(f"Model {model_id} not found")
        
        # Store in metadata (simplified - would use separate storage in production)
        metadata = self._metadata[model_id]
        if "performance_logs" not in metadata.metrics:
            metadata.metrics["performance_logs"] = []
        
        metadata.metrics["performance_logs"].append(log.model_dump(mode="json"))
        metadata.updated_at = datetime.utcnow()
        self._save_metadata()
    
    def get_performance_history(
        self,
        model_id: str,
        since: Optional[datetime] = None,
    ) -> list[ModelPerformanceLog]:
        """Get performance history for a model."""
        metadata = self._metadata.get(model_id)
        if not metadata:
            return []
        
        logs = metadata.metrics.get("performance_logs", [])
        result = [ModelPerformanceLog(**log) for log in logs]
        
        if since:
            result = [log for log in result if log.timestamp >= since]
        
        return result
    
    def compare_models(
        self,
        model_ids: list[str],
        metric: str = "brier_score",
    ) -> dict:
        """Compare performance metrics across models."""
        comparison = {}
        
        for model_id in model_ids:
            metadata = self._metadata.get(model_id)
            if not metadata:
                continue
            
            history = self.get_performance_history(model_id)
            if history:
                values = [
                    getattr(log, metric, None) 
                    for log in history 
                    if getattr(log, metric, None) is not None
                ]
                if values:
                    comparison[model_id] = {
                        "name": metadata.name,
                        "version": metadata.version,
                        "metric": metric,
                        "mean": np.mean(values),
                        "std": np.std(values),
                        "min": np.min(values),
                        "max": np.max(values),
                        "count": len(values),
                    }
        
        return comparison
    
    # -------------------------------------------------------------------------
    # Listing and Search
    # -------------------------------------------------------------------------
    
    def list_models(
        self,
        name: Optional[str] = None,
        model_type: Optional[ModelType] = None,
        status: Optional[ModelStatus] = None,
        tags: Optional[list[str]] = None,
    ) -> list[ModelMetadata]:
        """List models with filtering."""
        results = list(self._metadata.values())
        
        if name:
            results = [m for m in results if m.name == name]
        if model_type:
            results = [m for m in results if m.model_type == model_type]
        if status:
            results = [m for m in results if m.status == status]
        if tags:
            results = [m for m in results if any(t in m.tags for t in tags)]
        
        return sorted(results, key=lambda m: (m.name, m.trained_at), reverse=True)
    
    def search(self, query: str) -> list[ModelMetadata]:
        """Search models by description, name, or tags."""
        query_lower = query.lower()
        results = []
        
        for meta in self._metadata.values():
            if (query_lower in meta.name.lower() or
                query_lower in meta.description.lower() or
                any(query_lower in tag.lower() for tag in meta.tags)):
                results.append(meta)
        
        return results
    
    # -------------------------------------------------------------------------
    # Cleanup
    # -------------------------------------------------------------------------
    
    def cleanup_old_models(
        self,
        keep_versions: int = 5,
        older_than_days: int = 90,
    ) -> list[str]:
        """Archive old model versions to free up space."""
        archived = []
        cutoff = datetime.utcnow() - timedelta(days=older_than_days)
        
        # Group by name
        by_name: dict[str, list[ModelMetadata]] = {}
        for meta in self._metadata.values():
            if meta.name not in by_name:
                by_name[meta.name] = []
            by_name[meta.name].append(meta)
        
        for name, models in by_name.items():
            # Sort by version descending
            sorted_models = sorted(
                models, 
                key=lambda m: self._parse_version(m.version),
                reverse=True
            )
            
            # Keep recent versions and production
            to_archive = []
            for i, meta in enumerate(sorted_models):
                if (i >= keep_versions and 
                    meta.status not in [ModelStatus.PRODUCTION, ModelStatus.STAGING] and
                    meta.trained_at < cutoff):
                    to_archive.append(meta)
            
            # Archive
            for meta in to_archive:
                meta.status = ModelStatus.ARCHIVED
                meta.change_log.append("Archived during cleanup")
                
                # Delete model file
                model_path = self._get_model_path(meta.model_id)
                if model_path.exists():
                    model_path.unlink()
                
                # Remove from cache
                self._models.pop(meta.model_id, None)
                archived.append(meta.model_id)
        
        self._save_metadata()
        return archived
    
    def export_model(
        self,
        model_id: str,
        export_path: str,
    ) -> str:
        """Export a model and its metadata to a directory."""
        model, metadata = self.get(model_id)
        
        export_dir = Path(export_path)
        export_dir.mkdir(parents=True, exist_ok=True)
        
        # Save model
        model_file = export_dir / f"{model_id}.pkl"
        with open(model_file, "wb") as f:
            pickle.dump(model, f)
        
        # Save metadata
        meta_file = export_dir / f"{model_id}_metadata.json"
        with open(meta_file, "w") as f:
            json.dump(metadata.model_dump(mode="json"), f, indent=2, default=str)
        
        return str(export_dir)
    
    def import_model(
        self,
        import_path: str,
    ) -> ModelMetadata:
        """Import a model from an export directory."""
        import_dir = Path(import_path)
        
        # Find metadata file
        meta_files = list(import_dir.glob("*_metadata.json"))
        if not meta_files:
            raise FileNotFoundError("No metadata file found")
        
        meta_file = meta_files[0]
        model_id = meta_file.stem.replace("_metadata", "")
        
        # Load metadata
        with open(meta_file) as f:
            meta_dict = json.load(f)
        
        metadata = ModelMetadata(**meta_dict)
        
        # Load model
        model_file = import_dir / f"{model_id}.pkl"
        if not model_file.exists():
            raise FileNotFoundError(f"Model file not found: {model_file}")
        
        with open(model_file, "rb") as f:
            model = pickle.load(f)
        
        # Copy to registry storage
        dest_path = self._get_model_path(model_id)
        shutil.copy(model_file, dest_path)
        
        # Register
        self._models[model_id] = model
        self._metadata[model_id] = metadata
        self._save_metadata()
        
        return metadata


# =============================================================================
# Model Serving
# =============================================================================

class ModelServer:
    """
    Serves models from the registry with caching and routing.
    """
    
    def __init__(self, registry: ModelRegistry):
        self.registry = registry
        self._cache: dict[str, tuple[Any, ModelMetadata]] = {}
        self._cache_ttl = timedelta(minutes=5)
        self._cache_times: dict[str, datetime] = {}
    
    def get_model(
        self,
        name: str,
        request_id: Optional[str] = None,
    ) -> tuple[Any, ModelMetadata]:
        """
        Get a model for serving.
        
        Uses caching and respects A/B test allocation if request_id provided.
        """
        cache_key = f"{name}_{request_id or 'default'}"
        
        # Check cache
        if cache_key in self._cache:
            cache_time = self._cache_times.get(cache_key)
            if cache_time and datetime.utcnow() - cache_time < self._cache_ttl:
                return self._cache[cache_key]
        
        # Get from registry
        if request_id:
            model, metadata = self.registry.get_model_for_request(name, request_id)
        else:
            model, metadata = self.registry.get_latest(name)
        
        # Update cache
        self._cache[cache_key] = (model, metadata)
        self._cache_times[cache_key] = datetime.utcnow()
        
        return model, metadata
    
    def predict(
        self,
        name: str,
        features: Any,
        request_id: Optional[str] = None,
    ) -> tuple[Any, str]:
        """
        Make a prediction using the appropriate model.
        
        Returns (prediction, model_id) for tracking.
        """
        model, metadata = self.get_model(name, request_id)
        
        # Call predict method
        if hasattr(model, "predict"):
            prediction = model.predict(features)
        elif hasattr(model, "predict_proba"):
            prediction = model.predict_proba(features)
        else:
            raise ValueError(f"Model {metadata.model_id} has no predict method")
        
        return prediction, metadata.model_id
    
    def clear_cache(self):
        """Clear the model cache."""
        self._cache.clear()
        self._cache_times.clear()
