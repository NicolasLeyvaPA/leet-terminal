"""
Machine learning models for probability prediction.

Includes:
- Calibration models (isotonic, Platt scaling)
- Gradient boosting (LightGBM, XGBoost)
- Ensemble methods
- Evaluation metrics
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Any
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.calibration import CalibratedClassifierCV
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_predict
import structlog

logger = structlog.get_logger(__name__)


# =============================================================================
# Evaluation Metrics
# =============================================================================

@dataclass
class CalibrationMetrics:
    """Metrics for evaluating probability calibration."""
    
    brier_score: float
    log_loss: float
    calibration_error: float  # ECE
    resolution: float
    reliability: float
    n_samples: int
    
    def to_dict(self) -> dict:
        return {
            "brier_score": self.brier_score,
            "log_loss": self.log_loss,
            "calibration_error": self.calibration_error,
            "resolution": self.resolution,
            "reliability": self.reliability,
            "n_samples": self.n_samples,
        }


def brier_score(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """
    Brier score: mean squared error of probability predictions.
    
    Lower is better. Perfect = 0, uninformed (always 0.5) = 0.25
    """
    return float(np.mean((y_prob - y_true) ** 2))


def log_loss_score(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    eps: float = 1e-15,
) -> float:
    """
    Log loss (binary cross-entropy).
    
    Lower is better. Heavily penalizes confident wrong predictions.
    """
    y_prob = np.clip(y_prob, eps, 1 - eps)
    return float(-np.mean(
        y_true * np.log(y_prob) + (1 - y_true) * np.log(1 - y_prob)
    ))


def expected_calibration_error(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    n_bins: int = 10,
) -> float:
    """
    Expected Calibration Error (ECE).
    
    Measures how well predicted probabilities match observed frequencies.
    """
    bin_edges = np.linspace(0, 1, n_bins + 1)
    ece = 0.0
    
    for i in range(n_bins):
        mask = (y_prob >= bin_edges[i]) & (y_prob < bin_edges[i + 1])
        if mask.sum() > 0:
            bin_acc = y_true[mask].mean()
            bin_conf = y_prob[mask].mean()
            ece += mask.sum() * abs(bin_acc - bin_conf)
    
    return ece / len(y_true)


def compute_calibration_metrics(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    n_bins: int = 10,
) -> CalibrationMetrics:
    """Compute all calibration metrics."""
    y_true = np.array(y_true)
    y_prob = np.array(y_prob)
    
    bs = brier_score(y_true, y_prob)
    ll = log_loss_score(y_true, y_prob)
    ece = expected_calibration_error(y_true, y_prob, n_bins)
    
    # Resolution: variance of predictions (higher = more decisive)
    resolution = float(np.var(y_prob))
    
    # Reliability: how well calibrated (lower variance of errors in bins)
    reliability = bs - resolution + y_true.mean() * (1 - y_true.mean())
    
    return CalibrationMetrics(
        brier_score=bs,
        log_loss=ll,
        calibration_error=ece,
        resolution=resolution,
        reliability=reliability,
        n_samples=len(y_true),
    )


def calibration_curve(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    n_bins: int = 10,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute calibration curve data.
    
    Returns:
        bin_centers: Center of each bin
        true_freq: Observed frequency in each bin
        bin_counts: Number of samples in each bin
    """
    bin_edges = np.linspace(0, 1, n_bins + 1)
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
    
    true_freq = np.zeros(n_bins)
    bin_counts = np.zeros(n_bins)
    
    for i in range(n_bins):
        mask = (y_prob >= bin_edges[i]) & (y_prob < bin_edges[i + 1])
        if mask.sum() > 0:
            true_freq[i] = y_true[mask].mean()
            bin_counts[i] = mask.sum()
    
    return bin_centers, true_freq, bin_counts


# =============================================================================
# Base Model Interface
# =============================================================================

class ProbabilityModel(ABC):
    """Abstract base class for probability prediction models."""
    
    @abstractmethod
    def fit(self, X: pd.DataFrame, y: pd.Series) -> "ProbabilityModel":
        """Train the model."""
        pass
    
    @abstractmethod
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Predict probabilities for positive class."""
        pass
    
    @abstractmethod
    def get_confidence_interval(
        self,
        X: pd.DataFrame,
        alpha: float = 0.1,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Get confidence intervals for predictions."""
        pass
    
    def save(self, path: Path):
        """Save model to disk."""
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(self, f)
    
    @classmethod
    def load(cls, path: Path) -> "ProbabilityModel":
        """Load model from disk."""
        with open(path, "rb") as f:
            return pickle.load(f)


# =============================================================================
# Calibration Models
# =============================================================================

class IsotonicCalibrator(ProbabilityModel):
    """
    Isotonic regression calibrator.
    
    Takes raw probability estimates and calibrates them to match
    observed frequencies. Non-parametric, monotonic.
    """
    
    def __init__(self):
        self.calibrator = IsotonicRegression(
            out_of_bounds="clip",
            y_min=0.001,
            y_max=0.999,
        )
        self._fitted = False
    
    def fit(self, X: pd.DataFrame, y: pd.Series) -> "IsotonicCalibrator":
        """
        Fit calibrator on predicted probabilities vs actual outcomes.
        
        X should contain a column 'implied_prob' with raw predictions.
        """
        raw_probs = X["implied_prob"].values if "implied_prob" in X.columns else X.iloc[:, 0].values
        self.calibrator.fit(raw_probs, y.values)
        self._fitted = True
        return self
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Calibrate probabilities."""
        if not self._fitted:
            raise ValueError("Model not fitted")
        
        raw_probs = X["implied_prob"].values if "implied_prob" in X.columns else X.iloc[:, 0].values
        return self.calibrator.predict(raw_probs)
    
    def get_confidence_interval(
        self,
        X: pd.DataFrame,
        alpha: float = 0.1,
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Approximate confidence interval using bootstrap-style estimation.
        """
        probs = self.predict_proba(X)
        # Simple heuristic: wider CI for probabilities near 0.5
        uncertainty = 0.1 * (1 - np.abs(probs - 0.5) * 2)
        
        lower = np.clip(probs - uncertainty, 0.001, 0.999)
        upper = np.clip(probs + uncertainty, 0.001, 0.999)
        
        return lower, upper


class PlattCalibrator(ProbabilityModel):
    """
    Platt scaling calibrator.
    
    Fits a logistic regression on raw probabilities to calibrate them.
    """
    
    def __init__(self):
        self.calibrator = LogisticRegression(
            C=1.0,
            solver="lbfgs",
            max_iter=1000,
        )
        self._fitted = False
    
    def fit(self, X: pd.DataFrame, y: pd.Series) -> "PlattCalibrator":
        """Fit Platt scaling."""
        raw_probs = X["implied_prob"].values if "implied_prob" in X.columns else X.iloc[:, 0].values
        # Transform to log-odds for logistic regression
        raw_probs = np.clip(raw_probs, 0.001, 0.999)
        log_odds = np.log(raw_probs / (1 - raw_probs)).reshape(-1, 1)
        
        self.calibrator.fit(log_odds, y.values)
        self._fitted = True
        return self
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Calibrate probabilities."""
        if not self._fitted:
            raise ValueError("Model not fitted")
        
        raw_probs = X["implied_prob"].values if "implied_prob" in X.columns else X.iloc[:, 0].values
        raw_probs = np.clip(raw_probs, 0.001, 0.999)
        log_odds = np.log(raw_probs / (1 - raw_probs)).reshape(-1, 1)
        
        return self.calibrator.predict_proba(log_odds)[:, 1]
    
    def get_confidence_interval(
        self,
        X: pd.DataFrame,
        alpha: float = 0.1,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Approximate confidence interval."""
        probs = self.predict_proba(X)
        uncertainty = 0.08 * (1 - np.abs(probs - 0.5) * 2)
        
        lower = np.clip(probs - uncertainty, 0.001, 0.999)
        upper = np.clip(probs + uncertainty, 0.001, 0.999)
        
        return lower, upper


# =============================================================================
# Gradient Boosting Models
# =============================================================================

class LightGBMModel(ProbabilityModel):
    """LightGBM gradient boosting model."""
    
    def __init__(
        self,
        n_estimators: int = 100,
        max_depth: int = 6,
        learning_rate: float = 0.1,
        min_samples_leaf: int = 20,
        **kwargs,
    ):
        self.params = {
            "n_estimators": n_estimators,
            "max_depth": max_depth,
            "learning_rate": learning_rate,
            "min_child_samples": min_samples_leaf,
            "objective": "binary",
            "metric": "binary_logloss",
            "verbosity": -1,
            "random_state": 42,
            **kwargs,
        }
        self.model = None
        self._fitted = False
    
    def fit(self, X: pd.DataFrame, y: pd.Series) -> "LightGBMModel":
        """Train LightGBM model."""
        try:
            import lightgbm as lgb
        except ImportError:
            raise ImportError("lightgbm not installed. Run: pip install lightgbm")
        
        self.model = lgb.LGBMClassifier(**self.params)
        self.model.fit(X, y)
        self._fitted = True
        
        # Store feature importances
        self.feature_importances_ = dict(zip(
            X.columns,
            self.model.feature_importances_,
        ))
        
        return self
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Predict probabilities."""
        if not self._fitted:
            raise ValueError("Model not fitted")
        return self.model.predict_proba(X)[:, 1]
    
    def get_confidence_interval(
        self,
        X: pd.DataFrame,
        alpha: float = 0.1,
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Approximate CI using prediction variance across trees.
        """
        # Use leaf indices variance as uncertainty proxy
        probs = self.predict_proba(X)
        
        # Heuristic: more uncertain near decision boundary
        uncertainty = 0.12 * (1 - np.abs(probs - 0.5) * 2)
        
        lower = np.clip(probs - uncertainty, 0.001, 0.999)
        upper = np.clip(probs + uncertainty, 0.001, 0.999)
        
        return lower, upper


class XGBoostModel(ProbabilityModel):
    """XGBoost gradient boosting model."""
    
    def __init__(
        self,
        n_estimators: int = 100,
        max_depth: int = 6,
        learning_rate: float = 0.1,
        **kwargs,
    ):
        self.params = {
            "n_estimators": n_estimators,
            "max_depth": max_depth,
            "learning_rate": learning_rate,
            "objective": "binary:logistic",
            "eval_metric": "logloss",
            "use_label_encoder": False,
            "random_state": 42,
            **kwargs,
        }
        self.model = None
        self._fitted = False
    
    def fit(self, X: pd.DataFrame, y: pd.Series) -> "XGBoostModel":
        """Train XGBoost model."""
        try:
            import xgboost as xgb
        except ImportError:
            raise ImportError("xgboost not installed. Run: pip install xgboost")
        
        self.model = xgb.XGBClassifier(**self.params)
        self.model.fit(X, y)
        self._fitted = True
        
        return self
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Predict probabilities."""
        if not self._fitted:
            raise ValueError("Model not fitted")
        return self.model.predict_proba(X)[:, 1]
    
    def get_confidence_interval(
        self,
        X: pd.DataFrame,
        alpha: float = 0.1,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Approximate confidence interval."""
        probs = self.predict_proba(X)
        uncertainty = 0.12 * (1 - np.abs(probs - 0.5) * 2)
        
        lower = np.clip(probs - uncertainty, 0.001, 0.999)
        upper = np.clip(probs + uncertainty, 0.001, 0.999)
        
        return lower, upper


# =============================================================================
# Ensemble Model
# =============================================================================

class EnsembleModel(ProbabilityModel):
    """
    Ensemble of multiple models with weighted averaging.
    
    Combines predictions from multiple models for more robust estimates.
    """
    
    def __init__(
        self,
        models: Optional[dict[str, ProbabilityModel]] = None,
        weights: Optional[dict[str, float]] = None,
    ):
        self.models = models or {}
        self.weights = weights or {}
        self._fitted = False
    
    def add_model(self, name: str, model: ProbabilityModel, weight: float = 1.0):
        """Add a model to the ensemble."""
        self.models[name] = model
        self.weights[name] = weight
    
    def fit(self, X: pd.DataFrame, y: pd.Series) -> "EnsembleModel":
        """Train all models in the ensemble."""
        for name, model in self.models.items():
            logger.info("training_model", model=name)
            model.fit(X, y)
        
        self._fitted = True
        
        # Normalize weights
        total_weight = sum(self.weights.values())
        self.weights = {k: v / total_weight for k, v in self.weights.items()}
        
        return self
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Weighted average of model predictions."""
        if not self._fitted:
            raise ValueError("Model not fitted")
        
        predictions = np.zeros(len(X))
        
        for name, model in self.models.items():
            weight = self.weights.get(name, 1.0 / len(self.models))
            predictions += weight * model.predict_proba(X)
        
        return predictions
    
    def predict_proba_by_model(
        self,
        X: pd.DataFrame,
    ) -> dict[str, np.ndarray]:
        """Get predictions from each model separately."""
        return {
            name: model.predict_proba(X)
            for name, model in self.models.items()
        }
    
    def get_confidence_interval(
        self,
        X: pd.DataFrame,
        alpha: float = 0.1,
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Confidence interval from model disagreement.
        """
        all_preds = self.predict_proba_by_model(X)
        
        # Stack predictions
        pred_matrix = np.column_stack(list(all_preds.values()))
        
        # Use percentiles across models
        lower = np.percentile(pred_matrix, alpha / 2 * 100, axis=1)
        upper = np.percentile(pred_matrix, (1 - alpha / 2) * 100, axis=1)
        
        return lower, upper
    
    def model_agreement(self, X: pd.DataFrame) -> np.ndarray:
        """
        Measure agreement between models (0 to 1).
        
        Higher = models agree on prediction.
        """
        all_preds = self.predict_proba_by_model(X)
        pred_matrix = np.column_stack(list(all_preds.values()))
        
        # Agreement = 1 - normalized std
        stds = pred_matrix.std(axis=1)
        max_possible_std = 0.5  # Max std for binary predictions
        
        return 1 - (stds / max_possible_std)


# =============================================================================
# Model Factory
# =============================================================================

def create_default_ensemble() -> EnsembleModel:
    """
    Create default ensemble with recommended models and weights.
    """
    ensemble = EnsembleModel()
    
    # Add calibration models (for market-implied probs)
    ensemble.add_model("isotonic", IsotonicCalibrator(), weight=0.15)
    ensemble.add_model("platt", PlattCalibrator(), weight=0.10)
    
    # Add ML models
    ensemble.add_model(
        "lightgbm",
        LightGBMModel(n_estimators=100, max_depth=5),
        weight=0.40,
    )
    ensemble.add_model(
        "xgboost",
        XGBoostModel(n_estimators=100, max_depth=5),
        weight=0.35,
    )
    
    return ensemble
