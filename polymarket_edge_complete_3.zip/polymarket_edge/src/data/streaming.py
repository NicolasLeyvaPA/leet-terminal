"""
WebSocket streaming client for real-time Polymarket data.

Provides real-time price updates, order book changes, and trade notifications.
"""

import asyncio
import json
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional, Callable, Awaitable, Any
from dataclasses import dataclass, field

import structlog
import websockets
from websockets.client import WebSocketClientProtocol
from websockets.exceptions import (
    ConnectionClosed,
    ConnectionClosedError,
    ConnectionClosedOK,
)

from src.data.models import PriceSnapshot, Trade

logger = structlog.get_logger(__name__)


class StreamEventType(Enum):
    """Types of streaming events."""
    PRICE_UPDATE = "price_update"
    ORDER_BOOK_UPDATE = "order_book_update"
    TRADE = "trade"
    MARKET_STATUS = "market_status"
    HEARTBEAT = "heartbeat"
    ERROR = "error"
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    SUBSCRIBED = "subscribed"
    UNSUBSCRIBED = "unsubscribed"


@dataclass
class StreamEvent:
    """
    A streaming event from the WebSocket connection.
    
    Attributes:
        event_type: Type of the event
        timestamp: When the event occurred
        data: Event-specific data payload
        market_id: Associated market ID (if applicable)
        token_id: Associated token ID (if applicable)
    """
    event_type: StreamEventType
    timestamp: datetime
    data: dict[str, Any] = field(default_factory=dict)
    market_id: Optional[str] = None
    token_id: Optional[str] = None
    
    def as_price_snapshot(self) -> Optional[PriceSnapshot]:
        """Convert to PriceSnapshot if this is a price event."""
        if self.event_type != StreamEventType.PRICE_UPDATE:
            return None
        
        return PriceSnapshot(
            outcome_id=self.token_id or "",
            timestamp=self.timestamp,
            mid_price=Decimal(str(self.data.get("mid_price", 0))),
            bid_price=Decimal(str(self.data.get("bid_price", 0))) if self.data.get("bid_price") else None,
            ask_price=Decimal(str(self.data.get("ask_price", 0))) if self.data.get("ask_price") else None,
            spread_bps=Decimal(str(self.data.get("spread_bps", 0))) if self.data.get("spread_bps") else None,
            depth_imbalance=Decimal(str(self.data.get("depth_imbalance", 0))) if self.data.get("depth_imbalance") else None,
            volume_24h=Decimal(str(self.data.get("volume_24h", 0))) if self.data.get("volume_24h") else None,
        )
    
    def as_trade(self) -> Optional[Trade]:
        """Convert to Trade if this is a trade event."""
        if self.event_type != StreamEventType.TRADE:
            return None
        
        return Trade(
            trade_id=self.data.get("trade_id", ""),
            outcome_id=self.token_id or "",
            timestamp=self.timestamp,
            side=self.data.get("side", ""),
            price=Decimal(str(self.data.get("price", 0))),
            size=Decimal(str(self.data.get("size", 0))),
            maker_address=self.data.get("maker"),
            taker_address=self.data.get("taker"),
        )


# Type alias for event handlers
EventHandler = Callable[[StreamEvent], Awaitable[None]]


class StreamingClient:
    """
    WebSocket client for real-time Polymarket data streaming.
    
    Features:
    - Automatic reconnection with exponential backoff
    - Subscription management for multiple token IDs
    - Event callbacks for different event types
    - Heartbeat monitoring for connection health
    
    Example:
        async with StreamingClient() as client:
            await client.subscribe_prices(["token_id_1", "token_id_2"])
            
            @client.on_price_update
            async def handle_price(event: StreamEvent):
                print(f"Price update: {event.data}")
            
            await client.run_forever()
    """
    
    # Polymarket WebSocket endpoints
    WS_URL = "wss://ws-subscriptions-clob.polymarket.com/ws/market"
    
    def __init__(
        self,
        ws_url: Optional[str] = None,
        reconnect_delay: float = 1.0,
        max_reconnect_delay: float = 60.0,
        heartbeat_interval: float = 30.0,
        heartbeat_timeout: float = 10.0,
    ):
        """
        Initialize streaming client.
        
        Args:
            ws_url: WebSocket URL (uses default if not provided)
            reconnect_delay: Initial delay before reconnection attempt
            max_reconnect_delay: Maximum reconnection delay (exponential backoff cap)
            heartbeat_interval: Interval between heartbeat pings
            heartbeat_timeout: Timeout for heartbeat response
        """
        self.ws_url = ws_url or self.WS_URL
        self.reconnect_delay = reconnect_delay
        self.max_reconnect_delay = max_reconnect_delay
        self.heartbeat_interval = heartbeat_interval
        self.heartbeat_timeout = heartbeat_timeout
        
        # Connection state
        self._ws: Optional[WebSocketClientProtocol] = None
        self._connected = False
        self._running = False
        self._reconnect_count = 0
        
        # Subscriptions
        self._subscribed_tokens: set[str] = set()
        self._subscribed_markets: set[str] = set()
        
        # Event handlers
        self._handlers: dict[StreamEventType, list[EventHandler]] = {
            event_type: [] for event_type in StreamEventType
        }
        
        # Background tasks
        self._tasks: list[asyncio.Task] = []
        
        # Metrics
        self._events_received = 0
        self._last_event_time: Optional[datetime] = None
    
    async def __aenter__(self) -> "StreamingClient":
        """Async context manager entry."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.disconnect()
    
    # =========================================================================
    # Connection Management
    # =========================================================================
    
    async def connect(self) -> None:
        """Establish WebSocket connection."""
        if self._connected:
            logger.warning("already_connected")
            return
        
        try:
            logger.info("connecting", url=self.ws_url)
            
            self._ws = await websockets.connect(
                self.ws_url,
                ping_interval=self.heartbeat_interval,
                ping_timeout=self.heartbeat_timeout,
            )
            
            self._connected = True
            self._reconnect_count = 0
            
            # Emit connected event
            await self._emit_event(StreamEvent(
                event_type=StreamEventType.CONNECTED,
                timestamp=datetime.utcnow(),
            ))
            
            logger.info("connected")
            
            # Resubscribe to previously subscribed channels
            if self._subscribed_tokens:
                await self._send_subscribe("price", list(self._subscribed_tokens))
            
        except Exception as e:
            logger.error("connection_failed", error=str(e))
            raise
    
    async def disconnect(self) -> None:
        """Close WebSocket connection."""
        self._running = False
        
        # Cancel background tasks
        for task in self._tasks:
            task.cancel()
        self._tasks.clear()
        
        if self._ws:
            await self._ws.close()
            self._ws = None
        
        self._connected = False
        
        # Emit disconnected event
        await self._emit_event(StreamEvent(
            event_type=StreamEventType.DISCONNECTED,
            timestamp=datetime.utcnow(),
        ))
        
        logger.info("disconnected")
    
    async def _reconnect(self) -> None:
        """Attempt to reconnect with exponential backoff."""
        self._connected = False
        
        delay = min(
            self.reconnect_delay * (2 ** self._reconnect_count),
            self.max_reconnect_delay
        )
        
        self._reconnect_count += 1
        
        logger.info("reconnecting", delay=delay, attempt=self._reconnect_count)
        
        await asyncio.sleep(delay)
        
        try:
            await self.connect()
        except Exception as e:
            logger.error("reconnect_failed", error=str(e))
    
    # =========================================================================
    # Subscription Management
    # =========================================================================
    
    async def subscribe_prices(self, token_ids: list[str]) -> None:
        """
        Subscribe to price updates for specific tokens.
        
        Args:
            token_ids: List of token IDs to subscribe to
        """
        new_tokens = set(token_ids) - self._subscribed_tokens
        
        if not new_tokens:
            return
        
        self._subscribed_tokens.update(new_tokens)
        
        if self._connected:
            await self._send_subscribe("price", list(new_tokens))
        
        logger.info("subscribed_prices", token_count=len(new_tokens))
    
    async def subscribe_trades(self, token_ids: list[str]) -> None:
        """
        Subscribe to trade notifications for specific tokens.
        
        Args:
            token_ids: List of token IDs to subscribe to
        """
        if self._connected:
            await self._send_subscribe("trade", token_ids)
        
        logger.info("subscribed_trades", token_count=len(token_ids))
    
    async def subscribe_order_book(self, token_ids: list[str]) -> None:
        """
        Subscribe to order book updates for specific tokens.
        
        Args:
            token_ids: List of token IDs to subscribe to
        """
        if self._connected:
            await self._send_subscribe("book", token_ids)
        
        logger.info("subscribed_order_book", token_count=len(token_ids))
    
    async def unsubscribe(self, token_ids: list[str]) -> None:
        """
        Unsubscribe from all updates for specific tokens.
        
        Args:
            token_ids: List of token IDs to unsubscribe from
        """
        self._subscribed_tokens -= set(token_ids)
        
        if self._connected and self._ws:
            message = {
                "type": "unsubscribe",
                "assets": token_ids,
            }
            await self._ws.send(json.dumps(message))
        
        logger.info("unsubscribed", token_count=len(token_ids))
    
    async def _send_subscribe(self, channel: str, token_ids: list[str]) -> None:
        """Send subscription message."""
        if not self._ws:
            return
        
        # Polymarket uses asset-based subscriptions
        message = {
            "type": "subscribe",
            "channel": channel,
            "assets": token_ids,
        }
        
        await self._ws.send(json.dumps(message))
    
    # =========================================================================
    # Event Handling
    # =========================================================================
    
    def on(self, event_type: StreamEventType) -> Callable[[EventHandler], EventHandler]:
        """
        Decorator to register an event handler.
        
        Example:
            @client.on(StreamEventType.PRICE_UPDATE)
            async def handle_price(event: StreamEvent):
                print(f"Price: {event.data}")
        """
        def decorator(handler: EventHandler) -> EventHandler:
            self._handlers[event_type].append(handler)
            return handler
        return decorator
    
    def on_price_update(self, handler: EventHandler) -> EventHandler:
        """Decorator for price update handlers."""
        return self.on(StreamEventType.PRICE_UPDATE)(handler)
    
    def on_trade(self, handler: EventHandler) -> EventHandler:
        """Decorator for trade handlers."""
        return self.on(StreamEventType.TRADE)(handler)
    
    def on_order_book_update(self, handler: EventHandler) -> EventHandler:
        """Decorator for order book update handlers."""
        return self.on(StreamEventType.ORDER_BOOK_UPDATE)(handler)
    
    def add_handler(self, event_type: StreamEventType, handler: EventHandler) -> None:
        """Add an event handler programmatically."""
        self._handlers[event_type].append(handler)
    
    def remove_handler(self, event_type: StreamEventType, handler: EventHandler) -> None:
        """Remove an event handler."""
        if handler in self._handlers[event_type]:
            self._handlers[event_type].remove(handler)
    
    async def _emit_event(self, event: StreamEvent) -> None:
        """Emit event to all registered handlers."""
        self._events_received += 1
        self._last_event_time = event.timestamp
        
        handlers = self._handlers.get(event.event_type, [])
        
        for handler in handlers:
            try:
                await handler(event)
            except Exception as e:
                logger.error(
                    "handler_error",
                    event_type=event.event_type.value,
                    error=str(e),
                )
    
    # =========================================================================
    # Message Processing
    # =========================================================================
    
    async def _process_message(self, raw_message: str) -> None:
        """Process incoming WebSocket message."""
        try:
            message = json.loads(raw_message)
            
            msg_type = message.get("type", "")
            
            if msg_type == "price_change":
                event = self._parse_price_update(message)
            elif msg_type == "trade":
                event = self._parse_trade(message)
            elif msg_type == "book":
                event = self._parse_order_book_update(message)
            elif msg_type == "heartbeat":
                event = StreamEvent(
                    event_type=StreamEventType.HEARTBEAT,
                    timestamp=datetime.utcnow(),
                )
            elif msg_type == "subscribed":
                event = StreamEvent(
                    event_type=StreamEventType.SUBSCRIBED,
                    timestamp=datetime.utcnow(),
                    data=message,
                )
            elif msg_type == "error":
                event = StreamEvent(
                    event_type=StreamEventType.ERROR,
                    timestamp=datetime.utcnow(),
                    data={"error": message.get("message", "Unknown error")},
                )
                logger.error("stream_error", error=message.get("message"))
            else:
                # Unknown message type
                logger.debug("unknown_message_type", type=msg_type)
                return
            
            await self._emit_event(event)
            
        except json.JSONDecodeError as e:
            logger.error("invalid_json", error=str(e))
        except Exception as e:
            logger.error("message_processing_error", error=str(e))
    
    def _parse_price_update(self, message: dict) -> StreamEvent:
        """Parse price update message."""
        return StreamEvent(
            event_type=StreamEventType.PRICE_UPDATE,
            timestamp=datetime.utcnow(),
            token_id=message.get("asset_id"),
            data={
                "mid_price": message.get("price"),
                "bid_price": message.get("best_bid"),
                "ask_price": message.get("best_ask"),
                "spread_bps": self._calculate_spread_bps(
                    message.get("best_bid"),
                    message.get("best_ask"),
                ),
            },
        )
    
    def _parse_trade(self, message: dict) -> StreamEvent:
        """Parse trade message."""
        return StreamEvent(
            event_type=StreamEventType.TRADE,
            timestamp=datetime.fromisoformat(
                message.get("timestamp", datetime.utcnow().isoformat())
            ),
            token_id=message.get("asset_id"),
            data={
                "trade_id": message.get("trade_id"),
                "side": message.get("side"),
                "price": message.get("price"),
                "size": message.get("size"),
                "maker": message.get("maker"),
                "taker": message.get("taker"),
            },
        )
    
    def _parse_order_book_update(self, message: dict) -> StreamEvent:
        """Parse order book update message."""
        return StreamEvent(
            event_type=StreamEventType.ORDER_BOOK_UPDATE,
            timestamp=datetime.utcnow(),
            token_id=message.get("asset_id"),
            data={
                "bids": message.get("bids", []),
                "asks": message.get("asks", []),
                "sequence": message.get("sequence"),
            },
        )
    
    @staticmethod
    def _calculate_spread_bps(bid: Optional[float], ask: Optional[float]) -> Optional[float]:
        """Calculate spread in basis points."""
        if bid is None or ask is None or bid == 0:
            return None
        
        mid = (bid + ask) / 2
        if mid == 0:
            return None
        
        return ((ask - bid) / mid) * 10000
    
    # =========================================================================
    # Main Loop
    # =========================================================================
    
    async def run_forever(self) -> None:
        """
        Run the streaming client indefinitely.
        
        Handles reconnection on connection loss.
        """
        self._running = True
        
        while self._running:
            try:
                if not self._connected:
                    await self.connect()
                
                if not self._ws:
                    await asyncio.sleep(1)
                    continue
                
                async for message in self._ws:
                    if not self._running:
                        break
                    await self._process_message(message)
                    
            except ConnectionClosedOK:
                logger.info("connection_closed_ok")
                break
                
            except ConnectionClosedError as e:
                logger.warning("connection_closed_error", code=e.code, reason=e.reason)
                self._connected = False
                
                if self._running:
                    await self._reconnect()
                    
            except Exception as e:
                logger.error("stream_error", error=str(e))
                self._connected = False
                
                if self._running:
                    await self._reconnect()
    
    async def run_with_timeout(self, timeout_seconds: float) -> None:
        """
        Run the streaming client for a specified duration.
        
        Args:
            timeout_seconds: Duration to run in seconds
        """
        try:
            await asyncio.wait_for(self.run_forever(), timeout=timeout_seconds)
        except asyncio.TimeoutError:
            logger.info("stream_timeout", duration=timeout_seconds)
        finally:
            await self.disconnect()
    
    # =========================================================================
    # Metrics and Status
    # =========================================================================
    
    @property
    def is_connected(self) -> bool:
        """Check if currently connected."""
        return self._connected
    
    @property
    def subscribed_tokens(self) -> set[str]:
        """Get set of subscribed token IDs."""
        return self._subscribed_tokens.copy()
    
    @property
    def events_received(self) -> int:
        """Total number of events received."""
        return self._events_received
    
    @property
    def last_event_time(self) -> Optional[datetime]:
        """Timestamp of last received event."""
        return self._last_event_time
    
    def get_stats(self) -> dict[str, Any]:
        """Get streaming client statistics."""
        return {
            "connected": self._connected,
            "subscribed_tokens": len(self._subscribed_tokens),
            "events_received": self._events_received,
            "last_event_time": self._last_event_time.isoformat() if self._last_event_time else None,
            "reconnect_count": self._reconnect_count,
        }


# =============================================================================
# High-Level Streaming Functions
# =============================================================================

async def stream_prices(
    token_ids: list[str],
    handler: EventHandler,
    duration_seconds: Optional[float] = None,
) -> None:
    """
    Stream price updates for specified tokens.
    
    Convenience function for simple streaming use cases.
    
    Args:
        token_ids: List of token IDs to stream
        handler: Async function to handle price events
        duration_seconds: Optional duration limit (runs forever if None)
    
    Example:
        async def print_price(event):
            print(f"{event.token_id}: {event.data['mid_price']}")
        
        await stream_prices(["token1", "token2"], print_price, duration_seconds=60)
    """
    async with StreamingClient() as client:
        client.add_handler(StreamEventType.PRICE_UPDATE, handler)
        await client.subscribe_prices(token_ids)
        
        if duration_seconds:
            await client.run_with_timeout(duration_seconds)
        else:
            await client.run_forever()


async def stream_trades(
    token_ids: list[str],
    handler: EventHandler,
    duration_seconds: Optional[float] = None,
) -> None:
    """
    Stream trade notifications for specified tokens.
    
    Args:
        token_ids: List of token IDs to stream
        handler: Async function to handle trade events
        duration_seconds: Optional duration limit
    """
    async with StreamingClient() as client:
        client.add_handler(StreamEventType.TRADE, handler)
        await client.subscribe_trades(token_ids)
        
        if duration_seconds:
            await client.run_with_timeout(duration_seconds)
        else:
            await client.run_forever()


# =============================================================================
# Price Aggregator
# =============================================================================

class PriceAggregator:
    """
    Aggregates streaming prices into time-based snapshots.
    
    Useful for building OHLCV candles or computing rolling statistics.
    """
    
    def __init__(self, interval_seconds: int = 60):
        """
        Initialize price aggregator.
        
        Args:
            interval_seconds: Aggregation interval in seconds
        """
        self.interval = interval_seconds
        self._prices: dict[str, list[tuple[datetime, Decimal]]] = {}
        self._current_interval: dict[str, dict] = {}
    
    def add_price(self, token_id: str, timestamp: datetime, price: Decimal) -> None:
        """Add a price observation."""
        if token_id not in self._prices:
            self._prices[token_id] = []
            self._current_interval[token_id] = {
                "open": price,
                "high": price,
                "low": price,
                "close": price,
                "volume": 0,
                "count": 1,
                "start_time": timestamp,
            }
        
        interval = self._current_interval[token_id]
        interval["high"] = max(interval["high"], price)
        interval["low"] = min(interval["low"], price)
        interval["close"] = price
        interval["count"] += 1
        
        self._prices[token_id].append((timestamp, price))
    
    def get_ohlcv(self, token_id: str) -> Optional[dict]:
        """Get current interval OHLCV data."""
        if token_id not in self._current_interval:
            return None
        return self._current_interval[token_id].copy()
    
    def get_vwap(self, token_id: str) -> Optional[Decimal]:
        """Calculate volume-weighted average price."""
        if token_id not in self._prices or not self._prices[token_id]:
            return None
        
        prices = self._prices[token_id]
        total = sum(p for _, p in prices)
        return total / len(prices)
    
    def close_interval(self, token_id: str) -> Optional[dict]:
        """Close current interval and start a new one."""
        if token_id not in self._current_interval:
            return None
        
        result = self._current_interval[token_id].copy()
        result["vwap"] = self.get_vwap(token_id)
        
        # Reset
        self._prices[token_id] = []
        if self._prices.get(token_id):
            last_price = result["close"]
            self._current_interval[token_id] = {
                "open": last_price,
                "high": last_price,
                "low": last_price,
                "close": last_price,
                "volume": 0,
                "count": 0,
                "start_time": datetime.utcnow(),
            }
        
        return result


if __name__ == "__main__":
    # Demo usage
    async def demo():
        print("Starting streaming client demo...")
        
        client = StreamingClient()
        
        @client.on_price_update
        async def handle_price(event: StreamEvent):
            print(f"Price update: {event.token_id} = {event.data.get('mid_price')}")
        
        @client.on_trade
        async def handle_trade(event: StreamEvent):
            print(f"Trade: {event.data.get('side')} {event.data.get('size')} @ {event.data.get('price')}")
        
        # Note: Replace with actual token IDs
        demo_tokens = ["demo_token_1", "demo_token_2"]
        
        async with client:
            await client.subscribe_prices(demo_tokens)
            await client.subscribe_trades(demo_tokens)
            
            print(f"Subscribed to {len(demo_tokens)} tokens")
            print("Streaming for 30 seconds...")
            
            await client.run_with_timeout(30)
        
        print(f"Stats: {client.get_stats()}")
    
    asyncio.run(demo())
