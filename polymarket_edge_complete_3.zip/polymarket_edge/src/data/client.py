"""
Polymarket API client for fetching market data.

Supports both the CLOB (Central Limit Order Book) API and the Gamma API.
Implements rate limiting, retries, and circuit breaker patterns.
"""

import asyncio
import hashlib
import time
from datetime import datetime
from decimal import Decimal
from typing import Any, Optional

import httpx
import structlog
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
)

from src.data.models import (
    Market,
    Outcome,
    OrderBook,
    OrderBookLevel,
    PriceSnapshot,
    Trade,
    TradeSide,
    MarketStatus,
)

logger = structlog.get_logger(__name__)


class RateLimiter:
    """Token bucket rate limiter."""
    
    def __init__(self, rate: float, burst: int):
        """
        Args:
            rate: Requests per second
            burst: Maximum burst size
        """
        self.rate = rate
        self.burst = burst
        self.tokens = burst
        self.last_update = time.monotonic()
        self._lock = asyncio.Lock()
    
    async def acquire(self):
        """Acquire a token, waiting if necessary."""
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_update
            self.tokens = min(self.burst, self.tokens + elapsed * self.rate)
            self.last_update = now
            
            if self.tokens < 1:
                wait_time = (1 - self.tokens) / self.rate
                await asyncio.sleep(wait_time)
                self.tokens = 0
            else:
                self.tokens -= 1


class CircuitBreaker:
    """Circuit breaker for handling API failures."""
    
    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        half_open_requests: int = 3,
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_requests = half_open_requests
        
        self.failures = 0
        self.last_failure_time: Optional[float] = None
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
        self._lock = asyncio.Lock()
    
    async def call(self, func, *args, **kwargs):
        """Execute function with circuit breaker protection."""
        async with self._lock:
            if self.state == "OPEN":
                if time.monotonic() - self.last_failure_time > self.recovery_timeout:
                    self.state = "HALF_OPEN"
                    self.failures = 0
                else:
                    raise CircuitBreakerOpen("Circuit breaker is open")
        
        try:
            result = await func(*args, **kwargs)
            async with self._lock:
                if self.state == "HALF_OPEN":
                    self.failures = 0
                    self.state = "CLOSED"
            return result
        except Exception as e:
            async with self._lock:
                self.failures += 1
                self.last_failure_time = time.monotonic()
                if self.failures >= self.failure_threshold:
                    self.state = "OPEN"
                    logger.warning("circuit_breaker_opened", failures=self.failures)
            raise


class CircuitBreakerOpen(Exception):
    """Raised when circuit breaker is open."""
    pass


class PolymarketAPIError(Exception):
    """Base exception for Polymarket API errors."""
    pass


class PolymarketClient:
    """
    Async client for Polymarket APIs.
    
    Supports:
    - CLOB API: Order books, trades, market data
    - Gamma API: Market metadata, historical data
    
    Usage:
        async with PolymarketClient() as client:
            markets = await client.get_markets()
            for market in markets:
                book = await client.get_order_book(market.outcomes[0].token_id)
    """
    
    # API endpoints
    CLOB_BASE_URL = "https://clob.polymarket.com"
    GAMMA_BASE_URL = "https://gamma-api.polymarket.com"
    
    def __init__(
        self,
        rate_limit: float = 5.0,
        burst_limit: int = 10,
        timeout: float = 30.0,
    ):
        self.rate_limiter = RateLimiter(rate_limit, burst_limit)
        self.circuit_breaker = CircuitBreaker()
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None
    
    async def __aenter__(self):
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(self.timeout),
            headers={
                "User-Agent": "PolymarketEdge/0.1.0",
                "Accept": "application/json",
            },
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._client:
            await self._client.aclose()
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=60),
        retry=retry_if_exception_type((httpx.HTTPError, httpx.TimeoutException)),
    )
    async def _request(
        self,
        method: str,
        url: str,
        params: Optional[dict] = None,
        json_data: Optional[dict] = None,
    ) -> dict[str, Any]:
        """Make an API request with rate limiting and retries."""
        await self.rate_limiter.acquire()
        
        async def _do_request():
            response = await self._client.request(
                method,
                url,
                params=params,
                json=json_data,
            )
            response.raise_for_status()
            return response.json()
        
        try:
            return await self.circuit_breaker.call(_do_request)
        except httpx.HTTPStatusError as e:
            logger.error(
                "api_error",
                url=url,
                status_code=e.response.status_code,
                response=e.response.text[:500],
            )
            raise PolymarketAPIError(f"HTTP {e.response.status_code}: {e.response.text[:200]}")
    
    # =========================================================================
    # Gamma API Methods (Market Metadata)
    # =========================================================================
    
    async def get_markets(
        self,
        limit: int = 100,
        offset: int = 0,
        closed: bool = False,
        category: Optional[str] = None,
    ) -> list[Market]:
        """
        Fetch list of markets from Gamma API.
        
        Args:
            limit: Maximum markets to return
            offset: Pagination offset
            closed: Include closed markets
            category: Filter by category
            
        Returns:
            List of Market objects
        """
        params = {
            "limit": limit,
            "offset": offset,
            "closed": str(closed).lower(),
        }
        if category:
            params["tag"] = category
        
        data = await self._request(
            "GET",
            f"{self.GAMMA_BASE_URL}/markets",
            params=params,
        )
        
        markets = []
        for item in data:
            try:
                market = self._parse_gamma_market(item)
                markets.append(market)
            except Exception as e:
                logger.warning("parse_market_failed", market_id=item.get("id"), error=str(e))
        
        return markets
    
    async def get_market(self, market_id: str) -> Market:
        """Fetch a single market by ID."""
        data = await self._request(
            "GET",
            f"{self.GAMMA_BASE_URL}/markets/{market_id}",
        )
        return self._parse_gamma_market(data)
    
    def _parse_gamma_market(self, data: dict) -> Market:
        """Parse Gamma API market response into Market model."""
        # Parse end date
        end_date_str = data.get("endDate") or data.get("end_date_iso")
        if end_date_str:
            end_date = datetime.fromisoformat(end_date_str.replace("Z", "+00:00"))
        else:
            # Default to far future if not set
            end_date = datetime(2099, 12, 31)
        
        # Parse created date
        created_str = data.get("createdAt") or data.get("created_at")
        if created_str:
            created_at = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
        else:
            created_at = datetime.utcnow()
        
        # Determine status
        status = MarketStatus.ACTIVE
        if data.get("closed"):
            status = MarketStatus.CLOSED
        if data.get("resolved"):
            status = MarketStatus.RESOLVED
        
        return Market(
            market_id=str(data["id"]),
            condition_id=data.get("conditionId", data.get("condition_id", "")),
            question=data.get("question", data.get("title", "")),
            description=data.get("description"),
            category=data.get("category", data.get("groupItemTitle", "Other")),
            end_date=end_date,
            resolution_source=data.get("resolutionSource"),
            status=status,
            created_at=created_at,
            resolved_at=None,  # Parse if available
            resolution=data.get("outcome"),
            tags=data.get("tags", []),
        )
    
    async def get_market_outcomes(self, market_id: str) -> list[Outcome]:
        """Fetch outcomes/tokens for a market."""
        data = await self._request(
            "GET",
            f"{self.GAMMA_BASE_URL}/markets/{market_id}",
        )
        
        outcomes = []
        tokens = data.get("tokens", data.get("outcomes", []))
        
        # Handle different API response formats
        for i, token in enumerate(tokens):
            # If token is a string (just token ID), create minimal outcome
            if isinstance(token, str):
                outcome = Outcome(
                    outcome_id=token,
                    market_id=market_id,
                    token_id=token,
                    outcome_name=f"Outcome {i+1}",
                    resolved_price=None,
                )
            # If token is a dict with full data
            elif isinstance(token, dict):
                outcome = Outcome(
                    outcome_id=token.get("token_id", token.get("id", str(i))),
                    market_id=market_id,
                    token_id=token.get("token_id", token.get("id", str(i))),
                    outcome_name=token.get("outcome", token.get("name", f"Outcome {i+1}")),
                    resolved_price=Decimal(str(token["price"])) if token.get("winner") else None,
                )
            else:
                continue
            outcomes.append(outcome)
        
        return outcomes
    
    # =========================================================================
    # CLOB API Methods (Order Book & Trading)
    # =========================================================================
    
    async def get_order_book(self, token_id: str) -> OrderBook:
        """
        Fetch order book for a token.
        
        Args:
            token_id: The token/outcome ID
            
        Returns:
            OrderBook with bids and asks
        """
        data = await self._request(
            "GET",
            f"{self.CLOB_BASE_URL}/book",
            params={"token_id": token_id},
        )
        
        bids = [
            OrderBookLevel(
                price=Decimal(str(level["price"])),
                size=Decimal(str(level["size"])),
            )
            for level in data.get("bids", [])
        ]
        
        asks = [
            OrderBookLevel(
                price=Decimal(str(level["price"])),
                size=Decimal(str(level["size"])),
            )
            for level in data.get("asks", [])
        ]
        
        return OrderBook(
            outcome_id=token_id,
            ts=datetime.utcnow(),
            bids=sorted(bids, key=lambda x: x.price, reverse=True),
            asks=sorted(asks, key=lambda x: x.price),
        )
    
    async def get_price(self, token_id: str) -> PriceSnapshot:
        """
        Fetch current price snapshot for a token.
        
        Args:
            token_id: The token/outcome ID
            
        Returns:
            PriceSnapshot with current market data
        """
        # Get order book
        book = await self.get_order_book(token_id)
        
        # Calculate metrics
        mid_price = book.mid_price or Decimal("0.5")
        best_bid = book.best_bid or Decimal("0")
        best_ask = book.best_ask or Decimal("1")
        spread = best_ask - best_bid
        
        bid_depth, ask_depth = book.depth_at_distance(0.01)
        
        return PriceSnapshot(
            ts=datetime.utcnow(),
            outcome_id=token_id,
            mid_price=mid_price,
            bid_price=best_bid,
            ask_price=best_ask,
            spread=spread,
            bid_depth_1pct=bid_depth,
            ask_depth_1pct=ask_depth,
            volume_24h=Decimal("0"),  # Would need separate API call
            open_interest=Decimal("0"),  # Would need separate API call
        )
    
    async def get_trades(
        self,
        token_id: str,
        limit: int = 100,
        before_id: Optional[str] = None,
    ) -> list[Trade]:
        """
        Fetch recent trades for a token.
        
        Args:
            token_id: The token/outcome ID
            limit: Maximum trades to return
            before_id: Pagination cursor
            
        Returns:
            List of Trade objects
        """
        params = {"token_id": token_id, "limit": limit}
        if before_id:
            params["before"] = before_id
        
        data = await self._request(
            "GET",
            f"{self.CLOB_BASE_URL}/trades",
            params=params,
        )
        
        trades = []
        for item in data:
            try:
                trade = Trade(
                    trade_id=item.get("id", hashlib.md5(str(item).encode()).hexdigest()[:16]),
                    outcome_id=token_id,
                    ts=datetime.fromisoformat(item["timestamp"].replace("Z", "+00:00")),
                    side=TradeSide.BUY if item.get("side", "").upper() == "BUY" else TradeSide.SELL,
                    price=Decimal(str(item["price"])),
                    size=Decimal(str(item["size"])),
                    maker_address=item.get("maker"),
                    taker_address=item.get("taker"),
                )
                trades.append(trade)
            except Exception as e:
                logger.warning("parse_trade_failed", error=str(e))
        
        return trades
    
    async def get_market_prices(self) -> dict[str, Decimal]:
        """
        Fetch all market prices at once (more efficient).
        
        Returns:
            Dict mapping token_id to mid price
        """
        data = await self._request(
            "GET",
            f"{self.CLOB_BASE_URL}/prices",
        )
        
        return {
            token_id: Decimal(str(price))
            for token_id, price in data.items()
        }
    
    # =========================================================================
    # Convenience Methods
    # =========================================================================
    
    async def get_active_markets_with_prices(
        self,
        min_volume: float = 1000,
        limit: int = 50,
    ) -> list[tuple[Market, list[Outcome], dict[str, PriceSnapshot]]]:
        """
        Fetch active markets with their outcomes and current prices.
        
        This is the main entry point for getting tradeable markets.
        
        Args:
            min_volume: Minimum 24h volume filter
            limit: Maximum markets to return
            
        Returns:
            List of (Market, Outcomes, Prices) tuples
        """
        # Get markets
        markets = await self.get_markets(limit=limit, closed=False)
        
        results = []
        for market in markets:
            try:
                # Get outcomes
                outcomes = await self.get_market_outcomes(market.market_id)
                
                # Get prices for each outcome
                prices = {}
                for outcome in outcomes:
                    try:
                        price = await self.get_price(outcome.token_id)
                        prices[outcome.outcome_id] = price
                    except Exception as e:
                        logger.warning(
                            "get_price_failed",
                            outcome_id=outcome.outcome_id,
                            error=str(e),
                        )
                
                if prices:
                    results.append((market, outcomes, prices))
                    
            except Exception as e:
                logger.warning(
                    "get_market_details_failed",
                    market_id=market.market_id,
                    error=str(e),
                )
        
        return results


# =============================================================================
# Utility Functions
# =============================================================================

async def fetch_all_market_data(
    client: PolymarketClient,
    max_markets: int = 100,
) -> list[dict]:
    """
    Fetch comprehensive data for all active markets.
    
    Returns list of dicts with market, outcomes, prices, and recent trades.
    """
    results = []
    
    markets_data = await client.get_active_markets_with_prices(limit=max_markets)
    
    for market, outcomes, prices in markets_data:
        market_data = {
            "market": market,
            "outcomes": outcomes,
            "prices": prices,
            "trades": {},
        }
        
        # Fetch recent trades for each outcome
        for outcome in outcomes:
            try:
                trades = await client.get_trades(outcome.token_id, limit=50)
                market_data["trades"][outcome.outcome_id] = trades
            except Exception as e:
                logger.warning(
                    "fetch_trades_failed",
                    outcome_id=outcome.outcome_id,
                    error=str(e),
                )
        
        results.append(market_data)
    
    return results
