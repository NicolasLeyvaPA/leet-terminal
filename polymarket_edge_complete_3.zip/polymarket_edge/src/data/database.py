"""
Database ORM models and session management for Polymarket Edge.

Provides persistence layer for markets, prices, trades, predictions, and signals.
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional
from enum import Enum as PyEnum

from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
    Numeric,
    Boolean,
    ForeignKey,
    Index,
    Text,
    JSON,
    Enum,
    create_engine,
    event,
)
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, relationship, Mapped, mapped_column
from sqlalchemy.dialects.postgresql import JSONB, ARRAY
from sqlalchemy.sql import func

from config.settings import settings


class Base(DeclarativeBase):
    """Base class for all ORM models."""
    pass


class MarketStatus(PyEnum):
    """Market status enumeration."""
    ACTIVE = "active"
    RESOLVED = "resolved"
    CANCELLED = "cancelled"
    PAUSED = "paused"


class SignalStrength(PyEnum):
    """Signal strength classification."""
    STRONG = "strong"
    MODERATE = "moderate"
    WEAK = "weak"
    NONE = "none"


# =============================================================================
# Core Market Data Models
# =============================================================================

class MarketDB(Base):
    """
    Represents a Polymarket prediction market.
    
    Contains metadata and resolution information.
    """
    __tablename__ = "markets"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    market_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    condition_id: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    question: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    category: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    
    # Timing
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), onupdate=func.now())
    start_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    end_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    resolution_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    
    # Status
    status: Mapped[MarketStatus] = mapped_column(
        Enum(MarketStatus), 
        default=MarketStatus.ACTIVE, 
        nullable=False,
        index=True
    )
    
    # Resolution
    resolution_source: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    
    # Relationships
    outcomes: Mapped[list["OutcomeDB"]] = relationship(back_populates="market", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index("ix_markets_category_status", "category", "status"),
        Index("ix_markets_end_date_status", "end_date", "status"),
    )
    
    def __repr__(self) -> str:
        return f"<Market(id={self.market_id}, question={self.question[:50]}...)>"


class OutcomeDB(Base):
    """
    Represents an outcome within a market.
    
    Each market typically has 2+ outcomes (e.g., Yes/No).
    """
    __tablename__ = "outcomes"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    outcome_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    market_id: Mapped[int] = mapped_column(ForeignKey("markets.id"), nullable=False)
    token_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    
    outcome_name: Mapped[str] = mapped_column(String(255), nullable=False)
    
    # Resolution
    resolved_price: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 6), nullable=True)
    
    # Relationships
    market: Mapped["MarketDB"] = relationship(back_populates="outcomes")
    price_snapshots: Mapped[list["PriceSnapshotDB"]] = relationship(
        back_populates="outcome", 
        cascade="all, delete-orphan"
    )
    trades: Mapped[list["TradeDB"]] = relationship(back_populates="outcome", cascade="all, delete-orphan")
    predictions: Mapped[list["PredictionDB"]] = relationship(
        back_populates="outcome", 
        cascade="all, delete-orphan"
    )
    signals: Mapped[list["SignalDB"]] = relationship(back_populates="outcome", cascade="all, delete-orphan")


class PriceSnapshotDB(Base):
    """
    Time-series price data for an outcome.
    
    Captures order book state at a point in time.
    """
    __tablename__ = "price_snapshots"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    outcome_id: Mapped[int] = mapped_column(ForeignKey("outcomes.id"), nullable=False)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    
    # Prices
    mid_price: Mapped[Decimal] = mapped_column(Numeric(10, 6), nullable=False)
    bid_price: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 6), nullable=True)
    ask_price: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 6), nullable=True)
    
    # Derived metrics
    spread_bps: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2), nullable=True)
    depth_imbalance: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 4), nullable=True)
    
    # Volume
    volume_24h: Mapped[Optional[Decimal]] = mapped_column(Numeric(20, 4), nullable=True)
    open_interest: Mapped[Optional[Decimal]] = mapped_column(Numeric(20, 4), nullable=True)
    
    # Relationships
    outcome: Mapped["OutcomeDB"] = relationship(back_populates="price_snapshots")
    
    __table_args__ = (
        Index("ix_prices_outcome_timestamp", "outcome_id", "timestamp"),
    )


class TradeDB(Base):
    """
    Individual trade records.
    
    Used for trade flow analysis and smart money detection.
    """
    __tablename__ = "trades"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    trade_id: Mapped[str] = mapped_column(String(128), unique=True, nullable=False, index=True)
    outcome_id: Mapped[int] = mapped_column(ForeignKey("outcomes.id"), nullable=False)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    
    # Trade details
    side: Mapped[str] = mapped_column(String(4), nullable=False)  # BUY or SELL
    price: Mapped[Decimal] = mapped_column(Numeric(10, 6), nullable=False)
    size: Mapped[Decimal] = mapped_column(Numeric(20, 4), nullable=False)
    
    # Participants (anonymized addresses)
    maker_address: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)
    taker_address: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)
    
    # Relationships
    outcome: Mapped["OutcomeDB"] = relationship(back_populates="trades")
    
    __table_args__ = (
        Index("ix_trades_outcome_timestamp", "outcome_id", "timestamp"),
        Index("ix_trades_maker", "maker_address"),
    )


# =============================================================================
# Model Predictions and Signals
# =============================================================================

class PredictionDB(Base):
    """
    Model probability predictions.
    
    Stores predictions from different models for comparison.
    """
    __tablename__ = "predictions"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    outcome_id: Mapped[int] = mapped_column(ForeignKey("outcomes.id"), nullable=False)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    
    # Model info
    model_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    model_version: Mapped[str] = mapped_column(String(50), nullable=False)
    
    # Prediction
    predicted_prob: Mapped[Decimal] = mapped_column(Numeric(10, 6), nullable=False)
    confidence_lower: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 6), nullable=True)
    confidence_upper: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 6), nullable=True)
    
    # Features used (for reproducibility)
    feature_snapshot: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    
    # Relationships
    outcome: Mapped["OutcomeDB"] = relationship(back_populates="predictions")
    
    __table_args__ = (
        Index("ix_predictions_outcome_model_time", "outcome_id", "model_name", "timestamp"),
    )


class SignalDB(Base):
    """
    Trading signals generated by the system.
    
    Represents actionable opportunities with edge calculation.
    """
    __tablename__ = "signals"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    signal_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    outcome_id: Mapped[int] = mapped_column(ForeignKey("outcomes.id"), nullable=False)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    
    # Probabilities
    market_prob: Mapped[Decimal] = mapped_column(Numeric(10, 6), nullable=False)
    model_prob: Mapped[Decimal] = mapped_column(Numeric(10, 6), nullable=False)
    
    # Edge calculation
    edge: Mapped[Decimal] = mapped_column(Numeric(10, 6), nullable=False)
    kelly_fraction: Mapped[Decimal] = mapped_column(Numeric(10, 6), nullable=False)
    confluence_score: Mapped[Decimal] = mapped_column(Numeric(10, 4), nullable=False)
    
    # Classification
    signal_strength: Mapped[SignalStrength] = mapped_column(
        Enum(SignalStrength), 
        nullable=False,
        index=True
    )
    direction: Mapped[str] = mapped_column(String(4), nullable=False)  # YES or NO
    is_actionable: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    
    # Metadata
    metadata: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    
    # Relationships
    outcome: Mapped["OutcomeDB"] = relationship(back_populates="signals")
    
    __table_args__ = (
        Index("ix_signals_strength_actionable", "signal_strength", "is_actionable"),
    )


# =============================================================================
# External Data Sources
# =============================================================================

class NewsArticleDB(Base):
    """
    News articles related to markets.
    
    Used for sentiment analysis and event detection.
    """
    __tablename__ = "news_articles"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    article_id: Mapped[str] = mapped_column(String(128), unique=True, nullable=False, index=True)
    
    # Content
    title: Mapped[str] = mapped_column(Text, nullable=False)
    summary: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    url: Mapped[str] = mapped_column(String(512), nullable=False)
    source: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    
    # Timing
    published_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    
    # Analysis
    sentiment_score: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 4), nullable=True)  # -1 to 1
    relevance_score: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 4), nullable=True)  # 0 to 1
    
    # Entity extraction
    entities: Mapped[Optional[list]] = mapped_column(ARRAY(String), nullable=True)
    categories: Mapped[Optional[list]] = mapped_column(ARRAY(String), nullable=True)
    
    # Market associations
    related_market_ids: Mapped[Optional[list]] = mapped_column(ARRAY(String), nullable=True)


class SocialMentionDB(Base):
    """
    Social media mentions related to markets.
    
    Tracks discussion volume and sentiment on social platforms.
    """
    __tablename__ = "social_mentions"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    mention_id: Mapped[str] = mapped_column(String(128), unique=True, nullable=False, index=True)
    
    # Source
    platform: Mapped[str] = mapped_column(String(50), nullable=False, index=True)  # twitter, reddit, etc.
    author_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    author_followers: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    
    # Content
    text: Mapped[str] = mapped_column(Text, nullable=False)
    url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    
    # Timing
    posted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    
    # Engagement
    likes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    shares: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    comments: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    
    # Analysis
    sentiment_score: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 4), nullable=True)
    
    # Market associations
    related_market_ids: Mapped[Optional[list]] = mapped_column(ARRAY(String), nullable=True)


# =============================================================================
# Backtesting and Performance Tracking
# =============================================================================

class BacktestRunDB(Base):
    """
    Records of backtest runs for analysis and comparison.
    """
    __tablename__ = "backtest_runs"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    
    # Configuration
    start_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    end_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    initial_capital: Mapped[Decimal] = mapped_column(Numeric(20, 4), nullable=False)
    
    # Model info
    model_name: Mapped[str] = mapped_column(String(100), nullable=False)
    model_config: Mapped[dict] = mapped_column(JSONB, nullable=False)
    
    # Results
    total_return: Mapped[Decimal] = mapped_column(Numeric(10, 6), nullable=False)
    annualized_return: Mapped[Decimal] = mapped_column(Numeric(10, 6), nullable=False)
    sharpe_ratio: Mapped[Decimal] = mapped_column(Numeric(10, 4), nullable=False)
    sortino_ratio: Mapped[Decimal] = mapped_column(Numeric(10, 4), nullable=False)
    max_drawdown: Mapped[Decimal] = mapped_column(Numeric(10, 6), nullable=False)
    
    # Trading stats
    total_trades: Mapped[int] = mapped_column(Integer, nullable=False)
    win_rate: Mapped[Decimal] = mapped_column(Numeric(5, 4), nullable=False)
    profit_factor: Mapped[Decimal] = mapped_column(Numeric(10, 4), nullable=False)
    
    # Metadata
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Full results (for detailed analysis)
    full_results: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)


# =============================================================================
# Database Session Management
# =============================================================================

class Database:
    """
    Database connection and session management.
    
    Provides both sync and async interfaces.
    """
    
    def __init__(self, database_url: Optional[str] = None):
        """
        Initialize database connection.
        
        Args:
            database_url: Database connection URL. If not provided, uses settings.
        """
        self.database_url = database_url or settings.database.url
        self.async_url = database_url or settings.database.async_url
        
        # Sync engine (for migrations, simple operations)
        self.engine = create_engine(
            self.database_url,
            echo=settings.debug,
            pool_pre_ping=True,
        )
        
        # Async engine (for application use)
        self.async_engine = create_async_engine(
            self.async_url,
            echo=settings.debug,
            pool_pre_ping=True,
        )
        
        # Session factories
        self.async_session_factory = async_sessionmaker(
            self.async_engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )
    
    async def create_tables(self) -> None:
        """Create all database tables."""
        async with self.async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    
    async def drop_tables(self) -> None:
        """Drop all database tables. Use with caution!"""
        async with self.async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
    
    def get_session(self) -> AsyncSession:
        """Get a new async database session."""
        return self.async_session_factory()
    
    async def close(self) -> None:
        """Close database connections."""
        await self.async_engine.dispose()


# =============================================================================
# Repository Pattern for Data Access
# =============================================================================

class MarketRepository:
    """
    Repository for market-related database operations.
    """
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def get_by_market_id(self, market_id: str) -> Optional[MarketDB]:
        """Get market by Polymarket ID."""
        from sqlalchemy import select
        result = await self.session.execute(
            select(MarketDB).where(MarketDB.market_id == market_id)
        )
        return result.scalar_one_or_none()
    
    async def get_active_markets(
        self, 
        category: Optional[str] = None,
        limit: int = 100
    ) -> list[MarketDB]:
        """Get active markets, optionally filtered by category."""
        from sqlalchemy import select
        
        query = select(MarketDB).where(MarketDB.status == MarketStatus.ACTIVE)
        
        if category:
            query = query.where(MarketDB.category == category)
        
        query = query.order_by(MarketDB.end_date).limit(limit)
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def upsert(self, market: MarketDB) -> MarketDB:
        """Insert or update a market."""
        existing = await self.get_by_market_id(market.market_id)
        
        if existing:
            # Update existing
            for key, value in market.__dict__.items():
                if not key.startswith("_") and key != "id":
                    setattr(existing, key, value)
            return existing
        else:
            self.session.add(market)
            return market
    
    async def bulk_upsert(self, markets: list[MarketDB]) -> int:
        """Bulk insert or update markets."""
        count = 0
        for market in markets:
            await self.upsert(market)
            count += 1
        return count


class SignalRepository:
    """
    Repository for signal-related database operations.
    """
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def get_actionable_signals(
        self,
        min_strength: SignalStrength = SignalStrength.WEAK,
        limit: int = 50
    ) -> list[SignalDB]:
        """Get actionable signals above minimum strength."""
        from sqlalchemy import select
        
        strength_order = {
            SignalStrength.STRONG: 3,
            SignalStrength.MODERATE: 2,
            SignalStrength.WEAK: 1,
            SignalStrength.NONE: 0,
        }
        
        query = (
            select(SignalDB)
            .where(SignalDB.is_actionable == True)
            .order_by(SignalDB.timestamp.desc())
            .limit(limit)
        )
        
        result = await self.session.execute(query)
        signals = list(result.scalars().all())
        
        # Filter by strength
        return [
            s for s in signals 
            if strength_order[s.signal_strength] >= strength_order[min_strength]
        ]
    
    async def create(self, signal: SignalDB) -> SignalDB:
        """Create a new signal."""
        self.session.add(signal)
        return signal
    
    async def get_signals_for_outcome(
        self,
        outcome_id: int,
        hours: int = 24
    ) -> list[SignalDB]:
        """Get recent signals for an outcome."""
        from sqlalchemy import select
        from datetime import timedelta
        
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        
        query = (
            select(SignalDB)
            .where(SignalDB.outcome_id == outcome_id)
            .where(SignalDB.timestamp >= cutoff)
            .order_by(SignalDB.timestamp.desc())
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())


# Initialize default database instance
db = Database()
