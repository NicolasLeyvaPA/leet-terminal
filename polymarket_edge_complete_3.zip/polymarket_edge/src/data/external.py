"""
External data sources for enriching market analysis.

Provides integrations with news APIs, social media, and sentiment analysis.
"""

import asyncio
import hashlib
import re
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional, Any
from dataclasses import dataclass, field
from enum import Enum

import httpx
import structlog

logger = structlog.get_logger(__name__)


# =============================================================================
# Data Models
# =============================================================================

class SentimentLabel(Enum):
    """Sentiment classification labels."""
    VERY_NEGATIVE = "very_negative"
    NEGATIVE = "negative"
    NEUTRAL = "neutral"
    POSITIVE = "positive"
    VERY_POSITIVE = "very_positive"


@dataclass
class NewsArticle:
    """
    A news article from an external source.
    
    Attributes:
        article_id: Unique identifier
        title: Article headline
        summary: Brief summary or first paragraph
        url: Link to full article
        source: News source name
        published_at: Publication timestamp
        sentiment_score: Computed sentiment (-1 to 1)
        relevance_score: Relevance to target topic (0 to 1)
        entities: Extracted named entities
        categories: Topic categories
    """
    article_id: str
    title: str
    url: str
    source: str
    published_at: datetime
    summary: Optional[str] = None
    sentiment_score: Optional[float] = None
    sentiment_label: Optional[SentimentLabel] = None
    relevance_score: Optional[float] = None
    entities: list[str] = field(default_factory=list)
    categories: list[str] = field(default_factory=list)
    raw_content: Optional[str] = None
    
    @classmethod
    def generate_id(cls, url: str) -> str:
        """Generate unique ID from URL."""
        return hashlib.sha256(url.encode()).hexdigest()[:32]


@dataclass
class SocialMention:
    """
    A social media mention or post.
    
    Attributes:
        mention_id: Unique identifier
        platform: Social platform (twitter, reddit, etc.)
        text: Post content
        posted_at: When posted
        author_id: Author identifier
        author_followers: Number of followers
        engagement: Total engagement score
        sentiment_score: Computed sentiment
    """
    mention_id: str
    platform: str
    text: str
    posted_at: datetime
    url: Optional[str] = None
    author_id: Optional[str] = None
    author_followers: Optional[int] = None
    likes: int = 0
    shares: int = 0
    comments: int = 0
    sentiment_score: Optional[float] = None
    sentiment_label: Optional[SentimentLabel] = None
    
    @property
    def engagement(self) -> int:
        """Total engagement score."""
        return self.likes + self.shares * 2 + self.comments * 3
    
    @property
    def weighted_sentiment(self) -> Optional[float]:
        """Sentiment weighted by engagement and followers."""
        if self.sentiment_score is None:
            return None
        
        # Weight by log of engagement + followers
        import math
        weight = math.log1p(self.engagement) + math.log1p(self.author_followers or 1)
        return self.sentiment_score * weight


@dataclass
class SentimentAggregate:
    """
    Aggregated sentiment metrics over a time period.
    
    Attributes:
        topic: Topic being analyzed
        period_start: Start of analysis period
        period_end: End of analysis period
        article_count: Number of articles
        mention_count: Number of social mentions
        avg_sentiment: Average sentiment score
        weighted_sentiment: Engagement-weighted sentiment
        sentiment_trend: Change in sentiment over period
        volume_trend: Change in mention volume
    """
    topic: str
    period_start: datetime
    period_end: datetime
    article_count: int = 0
    mention_count: int = 0
    avg_sentiment: float = 0.0
    weighted_sentiment: float = 0.0
    sentiment_std: float = 0.0
    sentiment_trend: float = 0.0  # Change over period
    volume_trend: float = 0.0
    top_entities: list[str] = field(default_factory=list)
    bullish_ratio: float = 0.5  # Ratio of positive mentions


# =============================================================================
# Abstract Base Classes
# =============================================================================

class NewsSource(ABC):
    """Abstract base class for news data sources."""
    
    @abstractmethod
    async def search(
        self,
        query: str,
        from_date: Optional[datetime] = None,
        to_date: Optional[datetime] = None,
        limit: int = 50,
    ) -> list[NewsArticle]:
        """Search for news articles."""
        pass
    
    @abstractmethod
    async def get_trending(
        self,
        category: Optional[str] = None,
        limit: int = 20,
    ) -> list[NewsArticle]:
        """Get trending news articles."""
        pass


class SocialSource(ABC):
    """Abstract base class for social media data sources."""
    
    @abstractmethod
    async def search(
        self,
        query: str,
        from_date: Optional[datetime] = None,
        limit: int = 100,
    ) -> list[SocialMention]:
        """Search for social mentions."""
        pass
    
    @abstractmethod
    async def get_trending_topics(
        self,
        limit: int = 10,
    ) -> list[str]:
        """Get trending topics."""
        pass


# =============================================================================
# News API Implementations
# =============================================================================

class NewsAPIClient(NewsSource):
    """
    Client for NewsAPI.org service.
    
    Provides access to news articles from thousands of sources.
    
    Requires API key from https://newsapi.org
    """
    
    BASE_URL = "https://newsapi.org/v2"
    
    def __init__(self, api_key: str):
        """
        Initialize NewsAPI client.
        
        Args:
            api_key: NewsAPI.org API key
        """
        self.api_key = api_key
        self._client = httpx.AsyncClient(timeout=30.0)
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, *args):
        await self._client.aclose()
    
    async def search(
        self,
        query: str,
        from_date: Optional[datetime] = None,
        to_date: Optional[datetime] = None,
        limit: int = 50,
        language: str = "en",
    ) -> list[NewsArticle]:
        """
        Search for news articles.
        
        Args:
            query: Search keywords
            from_date: Start date for search
            to_date: End date for search
            limit: Maximum results
            language: Language filter
        """
        params = {
            "q": query,
            "language": language,
            "pageSize": min(limit, 100),
            "sortBy": "relevancy",
            "apiKey": self.api_key,
        }
        
        if from_date:
            params["from"] = from_date.isoformat()
        if to_date:
            params["to"] = to_date.isoformat()
        
        try:
            response = await self._client.get(
                f"{self.BASE_URL}/everything",
                params=params,
            )
            response.raise_for_status()
            data = response.json()
            
            articles = []
            for article in data.get("articles", []):
                articles.append(NewsArticle(
                    article_id=NewsArticle.generate_id(article.get("url", "")),
                    title=article.get("title", ""),
                    summary=article.get("description"),
                    url=article.get("url", ""),
                    source=article.get("source", {}).get("name", "Unknown"),
                    published_at=datetime.fromisoformat(
                        article.get("publishedAt", "").replace("Z", "+00:00")
                    ) if article.get("publishedAt") else datetime.utcnow(),
                    raw_content=article.get("content"),
                ))
            
            return articles
            
        except Exception as e:
            logger.error("newsapi_search_failed", error=str(e))
            return []
    
    async def get_trending(
        self,
        category: Optional[str] = None,
        country: str = "us",
        limit: int = 20,
    ) -> list[NewsArticle]:
        """
        Get top headlines.
        
        Args:
            category: Category filter (business, technology, politics, etc.)
            country: Country code
            limit: Maximum results
        """
        params = {
            "country": country,
            "pageSize": min(limit, 100),
            "apiKey": self.api_key,
        }
        
        if category:
            params["category"] = category
        
        try:
            response = await self._client.get(
                f"{self.BASE_URL}/top-headlines",
                params=params,
            )
            response.raise_for_status()
            data = response.json()
            
            articles = []
            for article in data.get("articles", []):
                articles.append(NewsArticle(
                    article_id=NewsArticle.generate_id(article.get("url", "")),
                    title=article.get("title", ""),
                    summary=article.get("description"),
                    url=article.get("url", ""),
                    source=article.get("source", {}).get("name", "Unknown"),
                    published_at=datetime.fromisoformat(
                        article.get("publishedAt", "").replace("Z", "+00:00")
                    ) if article.get("publishedAt") else datetime.utcnow(),
                    categories=[category] if category else [],
                ))
            
            return articles
            
        except Exception as e:
            logger.error("newsapi_trending_failed", error=str(e))
            return []


class GDELTClient(NewsSource):
    """
    Client for GDELT Project API.
    
    GDELT monitors the world's broadcast, print, and web news in over 100 languages.
    Free to use, no API key required.
    """
    
    BASE_URL = "https://api.gdeltproject.org/api/v2"
    
    def __init__(self):
        self._client = httpx.AsyncClient(timeout=60.0)
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, *args):
        await self._client.aclose()
    
    async def search(
        self,
        query: str,
        from_date: Optional[datetime] = None,
        to_date: Optional[datetime] = None,
        limit: int = 50,
    ) -> list[NewsArticle]:
        """Search GDELT for news articles."""
        # Build date range
        if from_date:
            start = from_date.strftime("%Y%m%d%H%M%S")
        else:
            start = (datetime.utcnow() - timedelta(days=7)).strftime("%Y%m%d%H%M%S")
        
        if to_date:
            end = to_date.strftime("%Y%m%d%H%M%S")
        else:
            end = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        
        params = {
            "query": query,
            "mode": "ArtList",
            "maxrecords": min(limit, 250),
            "format": "json",
            "startdatetime": start,
            "enddatetime": end,
        }
        
        try:
            response = await self._client.get(
                f"{self.BASE_URL}/doc/doc",
                params=params,
            )
            response.raise_for_status()
            data = response.json()
            
            articles = []
            for article in data.get("articles", []):
                articles.append(NewsArticle(
                    article_id=NewsArticle.generate_id(article.get("url", "")),
                    title=article.get("title", ""),
                    url=article.get("url", ""),
                    source=article.get("domain", "Unknown"),
                    published_at=datetime.strptime(
                        article.get("seendate", "")[:14],
                        "%Y%m%d%H%M%S"
                    ) if article.get("seendate") else datetime.utcnow(),
                    entities=article.get("persons", []) + article.get("organizations", []),
                ))
            
            return articles
            
        except Exception as e:
            logger.error("gdelt_search_failed", error=str(e))
            return []
    
    async def get_trending(
        self,
        category: Optional[str] = None,
        limit: int = 20,
    ) -> list[NewsArticle]:
        """Get trending news from GDELT."""
        # Use TV API for trending
        params = {
            "mode": "TimelineVolInfo",
            "format": "json",
            "query": category or "politics OR economics OR technology",
        }
        
        try:
            response = await self._client.get(
                f"{self.BASE_URL}/doc/doc",
                params=params,
            )
            response.raise_for_status()
            data = response.json()
            
            # GDELT trending returns different format
            # This is a simplified implementation
            return await self.search(category or "breaking news", limit=limit)
            
        except Exception as e:
            logger.error("gdelt_trending_failed", error=str(e))
            return []


# =============================================================================
# Social Media Implementations
# =============================================================================

class RedditClient(SocialSource):
    """
    Client for Reddit API.
    
    Accesses Reddit posts and comments for social sentiment analysis.
    Uses public JSON endpoints (no API key required for basic access).
    """
    
    BASE_URL = "https://www.reddit.com"
    
    def __init__(self, user_agent: str = "PolymarketEdge/1.0"):
        self._client = httpx.AsyncClient(
            timeout=30.0,
            headers={"User-Agent": user_agent}
        )
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, *args):
        await self._client.aclose()
    
    async def search(
        self,
        query: str,
        from_date: Optional[datetime] = None,
        limit: int = 100,
        subreddit: Optional[str] = None,
        sort: str = "relevance",
    ) -> list[SocialMention]:
        """
        Search Reddit for posts.
        
        Args:
            query: Search terms
            from_date: Start date
            limit: Maximum results
            subreddit: Specific subreddit to search
            sort: Sort order (relevance, hot, new, top)
        """
        url = f"{self.BASE_URL}/search.json"
        if subreddit:
            url = f"{self.BASE_URL}/r/{subreddit}/search.json"
        
        params = {
            "q": query,
            "sort": sort,
            "limit": min(limit, 100),
            "t": "week",  # Time filter
            "restrict_sr": "true" if subreddit else "false",
        }
        
        try:
            response = await self._client.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            
            mentions = []
            for post in data.get("data", {}).get("children", []):
                post_data = post.get("data", {})
                
                created = datetime.fromtimestamp(post_data.get("created_utc", 0))
                
                # Skip if before from_date
                if from_date and created < from_date:
                    continue
                
                mentions.append(SocialMention(
                    mention_id=post_data.get("id", ""),
                    platform="reddit",
                    text=f"{post_data.get('title', '')} {post_data.get('selftext', '')}",
                    posted_at=created,
                    url=f"https://reddit.com{post_data.get('permalink', '')}",
                    author_id=post_data.get("author"),
                    likes=post_data.get("ups", 0),
                    comments=post_data.get("num_comments", 0),
                ))
            
            return mentions
            
        except Exception as e:
            logger.error("reddit_search_failed", error=str(e))
            return []
    
    async def get_trending_topics(
        self,
        limit: int = 10,
    ) -> list[str]:
        """Get trending topics from popular subreddits."""
        try:
            response = await self._client.get(
                f"{self.BASE_URL}/r/popular.json",
                params={"limit": limit * 2}
            )
            response.raise_for_status()
            data = response.json()
            
            topics = []
            for post in data.get("data", {}).get("children", []):
                title = post.get("data", {}).get("title", "")
                # Extract key phrases (simplified)
                words = title.split()[:5]
                if words:
                    topics.append(" ".join(words))
            
            return topics[:limit]
            
        except Exception as e:
            logger.error("reddit_trending_failed", error=str(e))
            return []
    
    async def get_subreddit_sentiment(
        self,
        subreddit: str,
        limit: int = 50,
    ) -> list[SocialMention]:
        """Get recent posts from a specific subreddit."""
        try:
            response = await self._client.get(
                f"{self.BASE_URL}/r/{subreddit}/new.json",
                params={"limit": min(limit, 100)}
            )
            response.raise_for_status()
            data = response.json()
            
            mentions = []
            for post in data.get("data", {}).get("children", []):
                post_data = post.get("data", {})
                mentions.append(SocialMention(
                    mention_id=post_data.get("id", ""),
                    platform="reddit",
                    text=f"{post_data.get('title', '')} {post_data.get('selftext', '')}",
                    posted_at=datetime.fromtimestamp(post_data.get("created_utc", 0)),
                    url=f"https://reddit.com{post_data.get('permalink', '')}",
                    author_id=post_data.get("author"),
                    likes=post_data.get("ups", 0),
                    comments=post_data.get("num_comments", 0),
                ))
            
            return mentions
            
        except Exception as e:
            logger.error("reddit_subreddit_failed", error=str(e), subreddit=subreddit)
            return []


# =============================================================================
# Sentiment Analysis
# =============================================================================

class SentimentAnalyzer:
    """
    Sentiment analysis for text content.
    
    Uses rule-based analysis with financial/prediction market lexicon.
    For production, consider integrating ML models (BERT, FinBERT).
    """
    
    # Financial/prediction market sentiment lexicon
    POSITIVE_WORDS = {
        "bullish", "optimistic", "confident", "surge", "rally", "gain",
        "strong", "positive", "growth", "increase", "rise", "up",
        "win", "winning", "victory", "success", "breakthrough", "approved",
        "likely", "probable", "expected", "confirmed", "boost", "advance",
    }
    
    NEGATIVE_WORDS = {
        "bearish", "pessimistic", "uncertain", "crash", "plunge", "loss",
        "weak", "negative", "decline", "decrease", "fall", "down",
        "lose", "losing", "defeat", "failure", "rejected", "denied",
        "unlikely", "improbable", "unexpected", "doubt", "concern", "risk",
    }
    
    INTENSIFIERS = {
        "very", "extremely", "highly", "significantly", "strongly",
        "absolutely", "completely", "totally", "definitely",
    }
    
    NEGATORS = {
        "not", "no", "never", "neither", "none", "nobody",
        "nothing", "nowhere", "hardly", "barely", "scarcely",
    }
    
    def __init__(self):
        self._positive_pattern = re.compile(
            r"\b(" + "|".join(self.POSITIVE_WORDS) + r")\b",
            re.IGNORECASE
        )
        self._negative_pattern = re.compile(
            r"\b(" + "|".join(self.NEGATIVE_WORDS) + r")\b",
            re.IGNORECASE
        )
    
    def analyze(self, text: str) -> tuple[float, SentimentLabel]:
        """
        Analyze sentiment of text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Tuple of (score, label) where score is -1 to 1
        """
        if not text:
            return 0.0, SentimentLabel.NEUTRAL
        
        text_lower = text.lower()
        words = text_lower.split()
        
        positive_count = len(self._positive_pattern.findall(text_lower))
        negative_count = len(self._negative_pattern.findall(text_lower))
        
        # Check for negation (simplified)
        for i, word in enumerate(words):
            if word in self.NEGATORS:
                # Flip sentiment of next few words
                window = words[i+1:i+4]
                for w in window:
                    if w in self.POSITIVE_WORDS:
                        positive_count -= 1
                        negative_count += 1
                    elif w in self.NEGATIVE_WORDS:
                        negative_count -= 1
                        positive_count += 1
        
        # Check for intensifiers
        intensifier_count = sum(1 for w in words if w in self.INTENSIFIERS)
        intensity_multiplier = 1 + (intensifier_count * 0.2)
        
        # Calculate score
        total = positive_count + negative_count
        if total == 0:
            score = 0.0
        else:
            raw_score = (positive_count - negative_count) / total
            score = max(-1, min(1, raw_score * intensity_multiplier))
        
        # Determine label
        if score >= 0.5:
            label = SentimentLabel.VERY_POSITIVE
        elif score >= 0.2:
            label = SentimentLabel.POSITIVE
        elif score <= -0.5:
            label = SentimentLabel.VERY_NEGATIVE
        elif score <= -0.2:
            label = SentimentLabel.NEGATIVE
        else:
            label = SentimentLabel.NEUTRAL
        
        return score, label
    
    def analyze_batch(
        self,
        texts: list[str]
    ) -> list[tuple[float, SentimentLabel]]:
        """Analyze sentiment of multiple texts."""
        return [self.analyze(text) for text in texts]


# =============================================================================
# Aggregation and Integration
# =============================================================================

class ExternalDataAggregator:
    """
    Aggregates data from multiple external sources.
    
    Provides unified interface for sentiment analysis across news and social media.
    """
    
    def __init__(
        self,
        news_api_key: Optional[str] = None,
    ):
        """
        Initialize aggregator with data sources.
        
        Args:
            news_api_key: NewsAPI.org API key (optional)
        """
        self.news_sources: list[NewsSource] = []
        self.social_sources: list[SocialSource] = []
        self.sentiment_analyzer = SentimentAnalyzer()
        
        # Add available sources
        if news_api_key:
            self.news_sources.append(NewsAPIClient(news_api_key))
        
        # GDELT is free
        self.news_sources.append(GDELTClient())
        
        # Reddit is free
        self.social_sources.append(RedditClient())
    
    async def get_sentiment_for_topic(
        self,
        topic: str,
        hours_back: int = 24,
    ) -> SentimentAggregate:
        """
        Get aggregated sentiment for a topic.
        
        Args:
            topic: Topic/keywords to search
            hours_back: How many hours to look back
            
        Returns:
            Aggregated sentiment metrics
        """
        from_date = datetime.utcnow() - timedelta(hours=hours_back)
        to_date = datetime.utcnow()
        
        all_articles: list[NewsArticle] = []
        all_mentions: list[SocialMention] = []
        
        # Gather from all sources
        tasks = []
        
        for source in self.news_sources:
            tasks.append(source.search(topic, from_date=from_date, to_date=to_date))
        
        for source in self.social_sources:
            tasks.append(source.search(topic, from_date=from_date))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.warning("source_failed", index=i, error=str(result))
                continue
            
            if i < len(self.news_sources):
                all_articles.extend(result)
            else:
                all_mentions.extend(result)
        
        # Analyze sentiment
        article_sentiments = []
        for article in all_articles:
            text = f"{article.title} {article.summary or ''}"
            score, label = self.sentiment_analyzer.analyze(text)
            article.sentiment_score = score
            article.sentiment_label = label
            article_sentiments.append(score)
        
        mention_sentiments = []
        mention_weighted = []
        for mention in all_mentions:
            score, label = self.sentiment_analyzer.analyze(mention.text)
            mention.sentiment_score = score
            mention.sentiment_label = label
            mention_sentiments.append(score)
            
            # Weight by engagement
            weight = mention.weighted_sentiment
            if weight is not None:
                mention_weighted.append(weight)
        
        # Calculate aggregate metrics
        all_sentiments = article_sentiments + mention_sentiments
        
        avg_sentiment = sum(all_sentiments) / len(all_sentiments) if all_sentiments else 0.0
        weighted_sentiment = (
            sum(mention_weighted) / len(mention_weighted) 
            if mention_weighted else avg_sentiment
        )
        
        # Standard deviation
        if len(all_sentiments) > 1:
            mean = avg_sentiment
            variance = sum((x - mean) ** 2 for x in all_sentiments) / len(all_sentiments)
            sentiment_std = variance ** 0.5
        else:
            sentiment_std = 0.0
        
        # Bullish ratio
        bullish_count = sum(1 for s in all_sentiments if s > 0.1)
        bullish_ratio = bullish_count / len(all_sentiments) if all_sentiments else 0.5
        
        # Extract top entities
        entity_counts: dict[str, int] = {}
        for article in all_articles:
            for entity in article.entities:
                entity_counts[entity] = entity_counts.get(entity, 0) + 1
        
        top_entities = sorted(entity_counts.keys(), key=lambda x: entity_counts[x], reverse=True)[:10]
        
        return SentimentAggregate(
            topic=topic,
            period_start=from_date,
            period_end=to_date,
            article_count=len(all_articles),
            mention_count=len(all_mentions),
            avg_sentiment=avg_sentiment,
            weighted_sentiment=weighted_sentiment,
            sentiment_std=sentiment_std,
            bullish_ratio=bullish_ratio,
            top_entities=top_entities,
        )
    
    async def get_market_sentiment(
        self,
        market_question: str,
        category: str,
        hours_back: int = 24,
    ) -> dict[str, Any]:
        """
        Get sentiment analysis relevant to a specific market.
        
        Args:
            market_question: The market's question
            category: Market category
            hours_back: Hours to analyze
            
        Returns:
            Dictionary with sentiment metrics and signals
        """
        # Extract key terms from question
        key_terms = self._extract_key_terms(market_question)
        
        # Get sentiment for main topic
        main_sentiment = await self.get_sentiment_for_topic(
            " ".join(key_terms[:3]),
            hours_back=hours_back,
        )
        
        # Get category sentiment
        category_sentiment = await self.get_sentiment_for_topic(
            category,
            hours_back=hours_back,
        )
        
        return {
            "main_topic": {
                "sentiment_score": main_sentiment.avg_sentiment,
                "weighted_sentiment": main_sentiment.weighted_sentiment,
                "bullish_ratio": main_sentiment.bullish_ratio,
                "article_count": main_sentiment.article_count,
                "mention_count": main_sentiment.mention_count,
                "top_entities": main_sentiment.top_entities,
            },
            "category": {
                "sentiment_score": category_sentiment.avg_sentiment,
                "weighted_sentiment": category_sentiment.weighted_sentiment,
                "bullish_ratio": category_sentiment.bullish_ratio,
            },
            "signals": {
                "news_signal": self._interpret_sentiment(main_sentiment.avg_sentiment),
                "social_signal": self._interpret_sentiment(main_sentiment.weighted_sentiment),
                "volume_signal": "high" if main_sentiment.mention_count > 50 else "normal",
            },
        }
    
    def _extract_key_terms(self, text: str) -> list[str]:
        """Extract key terms from text."""
        # Remove common words
        stop_words = {
            "will", "the", "a", "an", "is", "are", "was", "were", "be", "been",
            "to", "of", "in", "for", "on", "with", "at", "by", "from", "or",
            "and", "but", "if", "than", "this", "that", "what", "which", "who",
        }
        
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
        key_terms = [w for w in words if w not in stop_words]
        
        return key_terms[:5]
    
    def _interpret_sentiment(self, score: float) -> str:
        """Interpret sentiment score as trading signal."""
        if score >= 0.3:
            return "bullish"
        elif score <= -0.3:
            return "bearish"
        else:
            return "neutral"


if __name__ == "__main__":
    async def demo():
        print("External Data Sources Demo")
        print("=" * 50)
        
        # Test sentiment analyzer
        analyzer = SentimentAnalyzer()
        
        test_texts = [
            "Bitcoin is surging as optimism grows around ETF approval",
            "Market crash likely as economic uncertainty deepens",
            "Trading remains neutral with no clear direction",
            "This is definitely not good news for investors",
        ]
        
        print("\nSentiment Analysis:")
        for text in test_texts:
            score, label = analyzer.analyze(text)
            print(f"  [{label.value:15}] ({score:+.2f}) {text[:50]}...")
        
        # Test aggregator
        print("\nTesting External Data Aggregator...")
        aggregator = ExternalDataAggregator()
        
        try:
            sentiment = await aggregator.get_sentiment_for_topic(
                "prediction markets",
                hours_back=24,
            )
            
            print(f"\nSentiment for 'prediction markets':")
            print(f"  Articles: {sentiment.article_count}")
            print(f"  Mentions: {sentiment.mention_count}")
            print(f"  Avg Sentiment: {sentiment.avg_sentiment:+.3f}")
            print(f"  Bullish Ratio: {sentiment.bullish_ratio:.1%}")
            
        except Exception as e:
            print(f"  Error: {e}")
        
        print("\nDemo complete!")
    
    asyncio.run(demo())
