"""
Data models for Polymarket entities.
Uses Pydantic for validation and serialization.
"""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, computed_field


class MarketStatus(str, Enum):
    """Market status enumeration."""
    ACTIVE = "active"
    CLOSED = "closed"
    RESOLVED = "resolved"
    CANCELLED = "cancelled"


class OutcomeResolution(str, Enum):
    """Outcome resolution status."""
    YES = "YES"
    NO = "NO"
    UNRESOLVED = "UNRESOLVED"


class TradeSide(str, Enum):
    """Trade side (buy/sell)."""
    BUY = "BUY"
    SELL = "SELL"


class SignalStrength(str, Enum):
    """Signal strength classification."""
    STRONG = "STRONG"
    MODERATE = "MODERATE"
    WEAK = "WEAK"
    NONE = "NONE"


# =============================================================================
# Core Market Models
# =============================================================================

class Market(BaseModel):
    """Represents a Polymarket prediction market."""
    
    market_id: str = Field(..., description="Unique market identifier")
    condition_id: str = Field(..., description="Condition ID from the contract")
    question: str = Field(..., description="The market question")
    description: Optional[str] = Field(None, description="Detailed description")
    category: str = Field(..., description="Market category (e.g., Politics, Sports)")
    
    end_date: datetime = Field(..., description="When the market closes")
    resolution_source: Optional[str] = Field(None, description="Source for resolution")
    
    status: MarketStatus = Field(MarketStatus.ACTIVE)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    resolved_at: Optional[datetime] = Field(None)
    resolution: Optional[str] = Field(None)
    
    tags: list[str] = Field(default_factory=list)
    
    @computed_field
    @property
    def time_to_resolution_hours(self) -> float:
        """Hours until market resolution."""
        delta = self.end_date - datetime.utcnow()
        return max(0, delta.total_seconds() / 3600)
    
    @computed_field
    @property
    def market_age_days(self) -> float:
        """Days since market creation."""
        delta = datetime.utcnow() - self.created_at
        return delta.total_seconds() / 86400


class Outcome(BaseModel):
    """Represents an outcome/token within a market."""
    
    outcome_id: str = Field(..., description="Unique outcome identifier")
    market_id: str = Field(..., description="Parent market ID")
    token_id: str = Field(..., description="Token contract address")
    outcome_name: str = Field(..., description="Name of the outcome (e.g., 'Yes', 'Trump')")
    
    resolved_price: Optional[Decimal] = Field(None, description="1.0 if won, 0.0 if lost")
    
    class Config:
        json_encoders = {Decimal: str}


class PriceSnapshot(BaseModel):
    """Point-in-time price and liquidity data for an outcome."""
    
    ts: datetime = Field(..., description="Timestamp of snapshot")
    outcome_id: str = Field(..., description="Outcome this price is for")
    
    # Prices
    mid_price: Decimal = Field(..., ge=0, le=1, description="Mid price (implied prob)")
    bid_price: Decimal = Field(..., ge=0, le=1, description="Best bid")
    ask_price: Decimal = Field(..., ge=0, le=1, description="Best ask")
    
    # Liquidity metrics
    spread: Decimal = Field(..., ge=0, description="Bid-ask spread")
    bid_depth_1pct: Decimal = Field(Decimal("0"), description="Bid liquidity within 1%")
    ask_depth_1pct: Decimal = Field(Decimal("0"), description="Ask liquidity within 1%")
    
    # Volume
    volume_24h: Decimal = Field(Decimal("0"), description="24h trading volume USD")
    open_interest: Decimal = Field(Decimal("0"), description="Total open interest")
    
    @computed_field
    @property
    def spread_bps(self) -> float:
        """Spread in basis points."""
        if self.mid_price == 0:
            return 0
        return float(self.spread / self.mid_price * 10000)
    
    @computed_field
    @property
    def depth_imbalance(self) -> float:
        """Order book imbalance (-1 to 1, positive = more bids)."""
        total = self.bid_depth_1pct + self.ask_depth_1pct
        if total == 0:
            return 0
        return float((self.bid_depth_1pct - self.ask_depth_1pct) / total)
    
    class Config:
        json_encoders = {Decimal: str}


class Trade(BaseModel):
    """Individual trade execution."""
    
    trade_id: str = Field(..., description="Unique trade identifier")
    outcome_id: str = Field(..., description="Outcome traded")
    ts: datetime = Field(..., description="Trade timestamp")
    
    side: TradeSide = Field(..., description="BUY or SELL")
    price: Decimal = Field(..., ge=0, le=1, description="Execution price")
    size: Decimal = Field(..., gt=0, description="Trade size in USD")
    
    maker_address: Optional[str] = Field(None, description="Maker wallet")
    taker_address: Optional[str] = Field(None, description="Taker wallet")
    
    class Config:
        json_encoders = {Decimal: str}


# =============================================================================
# Prediction & Signal Models
# =============================================================================

class Prediction(BaseModel):
    """Model prediction for an outcome."""
    
    prediction_id: Optional[int] = Field(None, description="Database ID")
    outcome_id: str = Field(..., description="Outcome being predicted")
    model_name: str = Field(..., description="Name of the model")
    
    predicted_prob: Decimal = Field(..., ge=0, le=1, description="Predicted probability")
    confidence_lower: Decimal = Field(..., ge=0, le=1, description="Lower CI bound")
    confidence_upper: Decimal = Field(..., ge=0, le=1, description="Upper CI bound")
    
    features_hash: Optional[str] = Field(None, description="Hash of input features")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    @computed_field
    @property
    def confidence_width(self) -> float:
        """Width of confidence interval."""
        return float(self.confidence_upper - self.confidence_lower)
    
    class Config:
        json_encoders = {Decimal: str}


class Signal(BaseModel):
    """Trading signal with edge calculation."""
    
    signal_id: Optional[int] = Field(None, description="Database ID")
    outcome_id: str = Field(..., description="Outcome for this signal")
    ts: datetime = Field(default_factory=datetime.utcnow)
    
    # Probabilities
    market_prob: Decimal = Field(..., ge=0, le=1, description="Current market price")
    model_prob: Decimal = Field(..., ge=0, le=1, description="Model prediction")
    
    # Edge metrics
    edge: Decimal = Field(..., description="Expected edge (can be negative)")
    kelly_fraction: Decimal = Field(..., ge=0, description="Kelly bet fraction")
    confluence_score: Decimal = Field(..., ge=0, le=1, description="Signal confluence")
    
    # Classification
    signal_strength: SignalStrength = Field(SignalStrength.NONE)
    direction: Optional[str] = Field(None, description="YES or NO")
    
    # Metadata
    metadata: dict = Field(default_factory=dict)
    
    @computed_field
    @property
    def is_actionable(self) -> bool:
        """Whether this signal suggests a trade."""
        return self.signal_strength != SignalStrength.NONE and self.edge > 0
    
    class Config:
        json_encoders = {Decimal: str}


# =============================================================================
# API Response Models
# =============================================================================

class OrderBookLevel(BaseModel):
    """Single level in the order book."""
    
    price: Decimal
    size: Decimal


class OrderBook(BaseModel):
    """Full order book for an outcome."""
    
    outcome_id: str
    ts: datetime = Field(default_factory=datetime.utcnow)
    bids: list[OrderBookLevel] = Field(default_factory=list)
    asks: list[OrderBookLevel] = Field(default_factory=list)
    
    @computed_field
    @property
    def best_bid(self) -> Optional[Decimal]:
        """Best (highest) bid price."""
        return max((b.price for b in self.bids), default=None)
    
    @computed_field
    @property
    def best_ask(self) -> Optional[Decimal]:
        """Best (lowest) ask price."""
        return min((a.price for a in self.asks), default=None)
    
    @computed_field
    @property
    def mid_price(self) -> Optional[Decimal]:
        """Mid price from best bid/ask."""
        if self.best_bid and self.best_ask:
            return (self.best_bid + self.best_ask) / 2
        return None
    
    def depth_at_distance(self, distance_pct: float = 0.01) -> tuple[Decimal, Decimal]:
        """Calculate bid/ask depth within a percentage of mid price."""
        mid = self.mid_price
        if not mid:
            return Decimal("0"), Decimal("0")
        
        bid_depth = sum(
            b.size for b in self.bids
            if b.price >= mid * Decimal(1 - distance_pct)
        )
        ask_depth = sum(
            a.size for a in self.asks
            if a.price <= mid * Decimal(1 + distance_pct)
        )
        return bid_depth, ask_depth


class MarketSummary(BaseModel):
    """Summary of a market with current prices."""
    
    market: Market
    outcomes: list[Outcome]
    current_prices: dict[str, PriceSnapshot]  # outcome_id -> snapshot
    
    @computed_field
    @property
    def total_volume_24h(self) -> Decimal:
        """Total 24h volume across all outcomes."""
        return sum(p.volume_24h for p in self.current_prices.values())
    
    @computed_field
    @property
    def overround(self) -> float:
        """Sum of implied probabilities (>1 means market has edge)."""
        return float(sum(p.mid_price for p in self.current_prices.values()))
