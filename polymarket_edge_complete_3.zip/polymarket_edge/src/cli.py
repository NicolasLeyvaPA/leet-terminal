"""
Command-line interface for Polymarket Edge system.
"""

import asyncio
from datetime import datetime
from pathlib import Path

import click
import structlog
from rich.console import Console
from rich.table import Table
from rich.progress import Progress

# Configure logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer(),
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    context_class=dict,
    logger_factory=structlog.PrintLoggerFactory(),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger(__name__)
console = Console()


@click.group()
@click.option("--debug/--no-debug", default=False)
def cli(debug: bool):
    """Polymarket Edge Detection System."""
    if debug:
        structlog.configure(
            wrapper_class=structlog.stdlib.BoundLogger,
            context_class=dict,
            logger_factory=structlog.PrintLoggerFactory(),
        )


@cli.command()
@click.option("--limit", default=20, help="Number of markets to fetch")
@click.option("--output", type=click.Path(), help="Output file (JSON)")
async def fetch_markets(limit: int, output: str):
    """Fetch active markets from Polymarket."""
    from src.data.client import PolymarketClient
    
    console.print(f"[bold blue]Fetching {limit} active markets...[/bold blue]")
    
    async with PolymarketClient() as client:
        with Progress() as progress:
            task = progress.add_task("Fetching markets...", total=limit)
            
            markets = await client.get_markets(limit=limit)
            progress.update(task, completed=limit)
    
    # Display results
    table = Table(title="Active Markets")
    table.add_column("ID", style="cyan")
    table.add_column("Question", style="white")
    table.add_column("Category", style="green")
    table.add_column("End Date", style="yellow")
    
    for market in markets[:20]:
        table.add_row(
            market.market_id[:8] + "...",
            market.question[:50] + ("..." if len(market.question) > 50 else ""),
            market.category,
            market.end_date.strftime("%Y-%m-%d"),
        )
    
    console.print(table)
    console.print(f"\n[green]Fetched {len(markets)} markets[/green]")
    
    if output:
        import json
        with open(output, "w") as f:
            json.dump([m.model_dump() for m in markets], f, indent=2, default=str)
        console.print(f"[blue]Saved to {output}[/blue]")


@cli.command()
@click.argument("market_id")
async def analyze_market(market_id: str):
    """Analyze a specific market for trading opportunities."""
    from src.data.client import PolymarketClient
    from src.features.engineering import FeatureEngineer
    from src.signals.edge import SignalGenerator, EdgeConfig
    
    console.print(f"[bold blue]Analyzing market {market_id}...[/bold blue]")
    
    async with PolymarketClient() as client:
        # Fetch market data
        market = await client.get_market(market_id)
        outcomes = await client.get_market_outcomes(market_id)
        
        console.print(f"\n[bold]{market.question}[/bold]")
        console.print(f"Category: {market.category}")
        console.print(f"End Date: {market.end_date}")
        console.print()
        
        # Get prices for each outcome
        engineer = FeatureEngineer()
        generator = SignalGenerator()
        
        table = Table(title="Outcome Analysis")
        table.add_column("Outcome", style="cyan")
        table.add_column("Market Price", style="white")
        table.add_column("Spread (bps)", style="yellow")
        table.add_column("Depth Imbalance", style="green")
        
        for outcome in outcomes:
            try:
                price = await client.get_price(outcome.token_id)
                
                table.add_row(
                    outcome.outcome_name,
                    f"{float(price.mid_price):.2%}",
                    f"{price.spread_bps:.1f}",
                    f"{price.depth_imbalance:+.2f}",
                )
            except Exception as e:
                table.add_row(outcome.outcome_name, "Error", "-", "-")
                logger.warning("price_fetch_failed", outcome=outcome.outcome_id, error=str(e))
        
        console.print(table)


@cli.command()
@click.option("--data-file", type=click.Path(exists=True), required=True)
@click.option("--train-days", default=90, help="Training window in days")
@click.option("--test-days", default=7, help="Test window in days")
@click.option("--capital", default=10000.0, help="Initial capital")
def backtest(data_file: str, train_days: int, test_days: int, capital: float):
    """Run backtest on historical data."""
    import pandas as pd
    from src.backtest.engine import BacktestEngine
    from src.models.probability import create_default_ensemble
    from src.features.engineering import FeatureSet
    
    console.print(f"[bold blue]Running backtest...[/bold blue]")
    console.print(f"  Data: {data_file}")
    console.print(f"  Train window: {train_days} days")
    console.print(f"  Test window: {test_days} days")
    console.print(f"  Capital: ${capital:,.2f}")
    console.print()
    
    # Load data
    data = pd.read_csv(data_file)
    console.print(f"Loaded {len(data)} rows")
    
    # Setup backtest
    engine = BacktestEngine(
        initial_capital=capital,
        train_window_days=train_days,
        test_window_days=test_days,
    )
    
    # Run backtest
    result = engine.run_walk_forward(
        data=data,
        model_factory=create_default_ensemble,
        feature_cols=FeatureSet.feature_names(),
    )
    
    # Display results
    metrics = result.metrics
    
    table = Table(title="Backtest Results")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="white")
    
    table.add_row("Total Return", f"{metrics.total_return:.2%}")
    table.add_row("Annualized Return", f"{metrics.annualized_return:.2%}")
    table.add_row("Sharpe Ratio", f"{metrics.sharpe_ratio:.2f}")
    table.add_row("Max Drawdown", f"{metrics.max_drawdown:.2%}")
    table.add_row("Total Trades", str(metrics.total_trades))
    table.add_row("Win Rate", f"{metrics.win_rate:.2%}")
    table.add_row("Profit Factor", f"{metrics.profit_factor:.2f}")
    
    console.print(table)


@cli.command()
@click.option("--min-edge", default=0.03, help="Minimum edge threshold")
@click.option("--limit", default=50, help="Number of markets to scan")
async def scan(min_edge: float, limit: int):
    """Scan for trading opportunities across all markets."""
    from src.data.client import PolymarketClient
    from src.features.engineering import FeatureEngineer
    from src.signals.edge import SignalGenerator, EdgeConfig
    
    console.print(f"[bold blue]Scanning {limit} markets for opportunities...[/bold blue]")
    console.print(f"Minimum edge threshold: {min_edge:.1%}")
    console.print()
    
    config = EdgeConfig(min_edge_weak=min_edge)
    generator = SignalGenerator(config)
    
    opportunities = []
    
    async with PolymarketClient() as client:
        markets = await client.get_markets(limit=limit)
        
        with Progress() as progress:
            task = progress.add_task("Scanning...", total=len(markets))
            
            for market in markets:
                try:
                    outcomes = await client.get_market_outcomes(market.market_id)
                    
                    for outcome in outcomes:
                        try:
                            price = await client.get_price(outcome.token_id)
                            market_prob = float(price.mid_price)
                            
                            # Simple heuristic: use market price as model estimate
                            # In production, this would use actual model predictions
                            model_prob = market_prob  # Placeholder
                            
                            signal = generator.generate_signal(
                                outcome_id=outcome.outcome_id,
                                model_prob=model_prob,
                                market_prob=market_prob,
                            )
                            
                            if signal.is_actionable:
                                opportunities.append({
                                    "market": market.question[:40],
                                    "outcome": outcome.outcome_name,
                                    "market_prob": market_prob,
                                    "edge": float(signal.edge),
                                    "direction": signal.direction,
                                    "strength": signal.signal_strength.value,
                                })
                        except Exception:
                            pass
                except Exception:
                    pass
                
                progress.update(task, advance=1)
    
    if opportunities:
        # Sort by edge
        opportunities.sort(key=lambda x: x["edge"], reverse=True)
        
        table = Table(title=f"Found {len(opportunities)} Opportunities")
        table.add_column("Market", style="cyan")
        table.add_column("Outcome", style="white")
        table.add_column("Direction", style="yellow")
        table.add_column("Edge", style="green")
        table.add_column("Strength", style="magenta")
        
        for opp in opportunities[:20]:
            table.add_row(
                opp["market"][:35] + "...",
                opp["outcome"],
                opp["direction"],
                f"{opp['edge']:.2%}",
                opp["strength"],
            )
        
        console.print(table)
    else:
        console.print("[yellow]No opportunities found above threshold[/yellow]")


@cli.command()
def init():
    """Initialize project directories and configuration."""
    from pathlib import Path
    
    dirs = [
        "data/raw",
        "data/processed",
        "data/features",
        "models/trained",
        "models/checkpoints",
        "logs",
        "reports",
    ]
    
    for dir_path in dirs:
        Path(dir_path).mkdir(parents=True, exist_ok=True)
        console.print(f"[green]Created {dir_path}/[/green]")
    
    # Create .env template
    env_template = """# Polymarket Edge Configuration

# Environment
ENV=development
DEBUG=true
LOG_LEVEL=INFO

# Database (optional - for persistence)
DB_HOST=localhost
DB_PORT=5432
DB_NAME=polymarket_edge
DB_USER=postgres
DB_PASSWORD=

# API Settings
POLYMARKET_REQUESTS_PER_SECOND=5
POLYMARKET_BURST_LIMIT=10

# Risk Settings
RISK_MAX_POSITION_PCT=0.05
RISK_KELLY_FRACTION=0.25
"""
    
    if not Path(".env").exists():
        with open(".env", "w") as f:
            f.write(env_template)
        console.print("[green]Created .env template[/green]")
    else:
        console.print("[yellow].env already exists, skipping[/yellow]")
    
    console.print("\n[bold green]Project initialized![/bold green]")


def main():
    """Entry point for CLI."""
    # Run async commands properly
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] in ["fetch-markets", "analyze-market", "scan"]:
        # These are async commands
        cli_func = cli.main(standalone_mode=False)
    else:
        cli()


if __name__ == "__main__":
    main()
